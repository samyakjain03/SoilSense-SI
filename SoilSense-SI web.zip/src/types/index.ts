export type SoilHealthStatus = 'HEALTHY' | 'DRY' | 'WATERLOGGED' | 'HOT & DRY' | 'WATCH';

export type MoistureStatus = 'OPTIMAL' | 'LOW' | 'CRITICAL_LOW' | 'HIGH' | 'WATERLOGGED';

export type TemperatureStatus = 'OPTIMAL' | 'ELEVATED' | 'HIGH' | 'COLD';

export type WaterRiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export type NutrientSignalStatus = 'AVAILABLE' | 'NOT_AVAILABLE' | 'OPTIONAL_UNCONNECTED';

export type IrrigationAction = 'IRRIGATE_NOW' | 'WAIT' | 'NO_IRRIGATION' | 'CHECK_SOIL';

export type UserRole = 'ADMIN' | 'GARDEN_MANAGER' | 'VIEWER';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  createdAt: string;
  password?: string;
  resetToken?: string;
  resetExpires?: string;
}

export interface Garden {
  id: string;
  name: string;
  location: string;
  createdAt: string;
  status: 'ACTIVE' | 'ARCHIVED';
  totalBeds: number;
  healthyCount: number;
  attentionCount: number;
  criticalCount: number;
}

export interface GardenBed {
  id: string;
  gardenId: string;
  name: string;
  cropType: string;
  area: string;
  deviceId: string;
  status: 'HEALTHY' | 'ATTENTION' | 'CRITICAL';
  healthScore: number;
  currentMoisture: number;
  currentTemp: number;
  notes?: string;
}

export interface DeviceInfo {
  id: string;
  name: string;
  type: 'NODE1_ENVIRONMENT' | 'NODE2_EDGE_ML' | 'CAM_NUTRIENT';
  gardenId: string;
  bedId: string;
  status: 'ONLINE' | 'SIMULATED' | 'OFFLINE';
  lastSeen: string;
  firmwareVersion: string;
  batteryLevel?: number;
}

export interface SensorReading {
  id: string;
  sensorId: string;
  gardenId: string;
  bedId: string;
  timestamp: string;
  moisture: number; // 0 - 100%
  soilTemperature: number; // °C (DS18B20)
  humidity: number; // % (Ambient)
  light: number; // Lux (Ambient photodiode)
  rain: boolean; // Digital rain sensor
  npkNitrogen: number | null; // mg/kg, null if disconnected
  npkPhosphorus: number | null;
  npkPotassium: number | null;
  npkConnected: boolean; // Explicit hardware status
  source: 'SIMULATED' | 'ESP32_HARDWARE';
}

export interface SoilHealthReport {
  id: string;
  gardenId: string;
  bedId: string;
  timestamp: string;
  status: SoilHealthStatus;
  score: number; // 0 - 100
  moistureStatus: MoistureStatus;
  temperatureStatus: TemperatureStatus;
  waterRisk: WaterRiskLevel;
  nutrientStatus: NutrientSignalStatus;
  recommendation: string;
  confidence: number; // 0 - 100%
  reasons: string[];
  calibratedThresholdsNotice: string;
  waterHealthScore: number;
  nutrientHealthScore: number;
  thermalScore: number;
}

export interface IrrigationRecommendation {
  action: IrrigationAction;
  duration: number; // minutes
  priority: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
  reason: string;
  confidence: number;
}

export interface IrrigationState {
  pumpStatus: 'ON' | 'OFF';
  valveStatus: 'OPEN' | 'CLOSED';
  isActive: boolean;
  remainingSeconds: number;
  durationMinutes: number;
  startedAt: string | null;
  reason: string;
  mode: 'AUTOMATED' | 'MANUAL';
  moistureBefore: number;
}

export interface IrrigationEvent {
  id: string;
  gardenId: string;
  bedId: string;
  startedAt: string;
  endedAt: string;
  duration: number; // seconds
  trigger: 'MANUAL' | 'AUTOMATED_THRESHOLD' | 'AI_ASSISTED' | 'DEMO_TRIGGER';
  moistureBefore: number;
  moistureAfter: number;
  mode: 'AUTOMATED' | 'MANUAL';
  pumpStatus: 'ON' | 'OFF';
  valveStatus: 'OPEN' | 'CLOSED';
}

export interface AlertItem {
  id: string;
  severity: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  timestamp: string;
  status: 'active' | 'read' | 'cleared';
  gardenId?: string;
  bedId?: string;
}

export type DemoScenario = 'HEALTHY' | 'DRY_SOIL' | 'WATERLOGGED' | 'HOT_DRY' | 'RECENT_RAIN' | 'SENSOR_FAILURE';

export interface DemoScenarioConfig {
  name: string;
  label: string;
  description: string;
  moistureRange: [number, number];
  temperatureRange: [number, number];
  humidityRange: [number, number];
  lightRange: [number, number];
  rain: boolean;
  npkConnected: boolean;
}

export interface CropScanResult {
  id: string;
  timestamp: string;
  cropName: string;
  canopyCondition: 'HEALTHY' | 'MILD_DEFICIENCY' | 'MODERATE_DEFICIENCY' | 'SEVERE_STRESS';
  suspectedDeficiency: string;
  confidence: number;
  visualObservations: string[];
  soilCorrelation: string;
  recommendations: string[];
  imageUrl?: string;
}
