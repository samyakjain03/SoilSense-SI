import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header.js';
import { Sidebar, NavTab } from './components/Sidebar.js';
import { MobileNav } from './components/MobileNav.js';
import { IrrigationConfirmModal } from './components/IrrigationConfirmModal.js';

// Public Pages
import { LandingPage } from './pages/LandingPage.js';
import { LoginPage } from './pages/LoginPage.js';
import { RegisterPage } from './pages/RegisterPage.js';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage.js';

// Authenticated Pages
import { DashboardPage } from './pages/DashboardPage.js';
import { GardensPage } from './pages/GardensPage.js';
import { SoilHealthPage } from './pages/SoilHealthPage.js';
import { SensorsPage } from './pages/SensorsPage.js';
import { IrrigationPage } from './pages/IrrigationPage.js';
import { AnalyticsPage } from './pages/AnalyticsPage.js';
import { AlertsPage } from './pages/AlertsPage.js';
import { DevicesPage } from './pages/DevicesPage.js';
import { SettingsPage } from './pages/SettingsPage.js';
import { CropScanPage } from './pages/CropScanPage.js';

import { api } from './services/api.js';
import {
  Garden,
  GardenBed,
  UserProfile,
  UserRole,
  SensorReading,
  SoilHealthReport,
  IrrigationRecommendation,
  IrrigationState,
  IrrigationEvent,
  AlertItem,
  DeviceInfo,
  DemoScenario
} from './types/index.js';

export default function App() {
  // Path-based routing: '/', '/login', '/register', '/forgot-password', or '/app/*'
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  // Authenticated user session
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  // Garden selection
  const [gardens, setGardens] = useState<Garden[]>([]);
  const [selectedGarden, setSelectedGarden] = useState<Garden | null>(null);
  const [beds, setBeds] = useState<GardenBed[]>([]);
  const [selectedBed, setSelectedBed] = useState<GardenBed | null>(null);

  // Telemetry state
  const [latestReading, setLatestReading] = useState<SensorReading | null>(null);
  const [soilHealthReport, setSoilHealthReport] = useState<SoilHealthReport | null>(null);
  const [irrigationRec, setIrrigationRec] = useState<IrrigationRecommendation | null>(null);
  const [irrigationState, setIrrigationState] = useState<IrrigationState>({
    pumpStatus: 'OFF',
    valveStatus: 'CLOSED',
    isActive: false,
    remainingSeconds: 0,
    durationMinutes: 6,
    startedAt: null,
    reason: 'Standby',
    mode: 'MANUAL',
    moistureBefore: 41
  });

  const [history, setHistory] = useState<SensorReading[]>([]);
  const [irrigationEvents, setIrrigationEvents] = useState<IrrigationEvent[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [devices, setDevices] = useState<DeviceInfo[]>([]);

  // Simulation mode
  const [isDemo, setIsDemo] = useState<boolean>(true);
  const [activeScenario, setActiveScenario] = useState<DemoScenario>('HEALTHY');

  // Confirmation modal
  const [confirmModalOpen, setConfirmModalOpen] = useState<boolean>(false);

  // Browser navigation helper
  const navigate = useCallback((path: string) => {
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', path);
    }
    setCurrentPath(path);
  }, []);

  // Listen to popstate for back/forward browser arrows
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Check auth session on initial load
  useEffect(() => {
    async function checkAuth() {
      const token = api.getToken();
      if (token) {
        const user = await api.getCurrentUser();
        if (user) {
          setCurrentUser(user);
        } else {
          api.setToken(null);
        }
      }
      setAuthChecked(true);
    }
    checkAuth();
  }, []);

  // Load Station Data when authenticated
  useEffect(() => {
    if (!currentUser) return;

    async function loadStationData() {
      try {
        const gardenData = await api.getGardens();
        if (gardenData.gardens.length > 0) {
          setGardens(gardenData.gardens);
          setSelectedGarden(gardenData.gardens[0]);
        }
        if (gardenData.beds.length > 0) {
          setBeds(gardenData.beds);
          setSelectedBed(gardenData.beds[0]);
        }

        const latest = await api.getLatestSensorData('bed-tomatoes-01');
        setLatestReading(latest.reading);
        setSoilHealthReport(latest.soilHealth);
        setIrrigationRec(latest.irrigationRecommendation);
        setIsDemo(latest.isDemo);
        setActiveScenario(latest.activeScenario);

        const histData = await api.getSensorHistory('bed-tomatoes-01', 36);
        setHistory(histData);

        const irrigStatus = await api.getIrrigationStatus('bed-tomatoes-01');
        setIrrigationState(irrigStatus);

        const irrigHistory = await api.getIrrigationHistory(15);
        setIrrigationEvents(irrigHistory);

        const alertList = await api.getAlerts();
        setAlerts(alertList);

        const devList = await api.getDevices();
        setDevices(devList);
      } catch (err) {
        console.warn('Station data fetch notice:', err);
      }
    }

    loadStationData();
  }, [currentUser]);

  // Periodic Telemetry Poll
  useEffect(() => {
    if (!currentUser) return;

    const interval = setInterval(async () => {
      try {
        const bedId = selectedBed?.id || 'bed-tomatoes-01';
        const latest = await api.getLatestSensorData(bedId);
        setLatestReading(latest.reading);
        setSoilHealthReport(latest.soilHealth);
        setIrrigationRec(latest.irrigationRecommendation);

        setHistory((prev) => {
          const exists = prev.some((p) => p.id === latest.reading.id);
          if (exists) return prev;
          return [...prev, latest.reading].slice(-40);
        });

        const irrigStatus = await api.getIrrigationStatus(bedId);
        setIrrigationState(irrigStatus);

        const alertList = await api.getAlerts();
        setAlerts(alertList);
      } catch {
        // quiet poll
      }
    }, 4500);

    return () => clearInterval(interval);
  }, [currentUser, selectedBed]);

  // Auth Handlers
  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    navigate('/app/dashboard');
  };

  const handleLogout = async () => {
    await api.logout();
    setCurrentUser(null);
    navigate('/');
  };

  // Scenario Switcher (under Settings / Demo Mode)
  const handleSelectScenario = async (scenario: DemoScenario) => {
    setActiveScenario(scenario);
    try {
      const res = await api.setDemoScenario(scenario, selectedBed?.id || 'bed-tomatoes-01', true);
      setLatestReading(res.reading);
      setSoilHealthReport(res.soilHealth);
      setIrrigationRec(res.irrigationRecommendation);
      setHistory((prev) => [...prev, res.reading].slice(-40));

      const freshAlerts = await api.getAlerts();
      setAlerts(freshAlerts);
    } catch (err) {
      console.error('Error applying scenario:', err);
    }
  };

  const handleToggleDemo = async (demo: boolean) => {
    setIsDemo(demo);
    try {
      await api.toggleDemoMode(demo);
    } catch (err) {
      console.error('Error toggling demo mode:', err);
    }
  };

  // Irrigation Controls
  const handleConfirmIrrigate = async (durationMinutes: number, reason: string) => {
    try {
      const res = await api.startIrrigation({
        durationMinutes,
        reason,
        mode: 'MANUAL',
        gardenId: selectedGarden?.id || 'garden-jecrc-01',
        bedId: selectedBed?.id || 'bed-tomatoes-01'
      });
      setIrrigationState(res.state);

      const events = await api.getIrrigationHistory(15);
      setIrrigationEvents(events);

      const alertList = await api.getAlerts();
      setAlerts(alertList);
    } catch (err) {
      console.error('Failed to start irrigation:', err);
    }
  };

  const handleStopIrrigate = async () => {
    try {
      const res = await api.stopIrrigation(
        selectedGarden?.id || 'garden-jecrc-01',
        selectedBed?.id || 'bed-tomatoes-01'
      );
      setIrrigationState(res.state);

      const latest = await api.getLatestSensorData(selectedBed?.id || 'bed-tomatoes-01');
      setLatestReading(latest.reading);
      setSoilHealthReport(latest.soilHealth);

      const events = await api.getIrrigationHistory(15);
      setIrrigationEvents(events);

      const alertList = await api.getAlerts();
      setAlerts(alertList);
    } catch (err) {
      console.error('Failed to stop irrigation:', err);
    }
  };

  // Alert Handlers
  const handleMarkAlertRead = async (alertId: string) => {
    try {
      await api.markAlertRead(alertId);
      setAlerts((prev) => prev.map((a) => (a.id === alertId ? { ...a, status: 'read' as const } : a)));
    } catch (err) {
      console.error('Failed to mark alert read:', err);
    }
  };

  const handleMarkAllAlertsRead = async () => {
    try {
      await api.markAllAlertsRead();
      setAlerts((prev) => prev.map((a) => ({ ...a, status: 'read' as const })));
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  };

  const handleClearAlert = async (alertId: string) => {
    try {
      await api.clearAlert(alertId);
      setAlerts((prev) => prev.filter((a) => a.id !== alertId));
    } catch (err) {
      console.error('Failed to clear alert:', err);
    }
  };

  const handleClearAllAlerts = async () => {
    try {
      await api.clearAllAlerts();
      setAlerts([]);
    } catch (err) {
      console.error('Failed to clear all alerts:', err);
    }
  };

  const unreadAlertsCount = alerts.filter((a) => a.status === 'active').length;

  // Determine active tab from current URL
  const getActiveTabFromPath = (): NavTab => {
    if (currentPath.includes('/app/gardens')) return 'gardens';
    if (currentPath.includes('/app/soil')) return 'soil';
    if (currentPath.includes('/app/irrigation')) return 'irrigation';
    if (currentPath.includes('/app/sensors')) return 'sensors';
    if (currentPath.includes('/app/analytics')) return 'analytics';
    if (currentPath.includes('/app/alerts')) return 'alerts';
    if (currentPath.includes('/app/devices')) return 'devices';
    if (currentPath.includes('/app/settings')) return 'settings';
    if (currentPath.includes('/app/scan')) return 'scan';
    return 'dashboard';
  };

  const activeTab = getActiveTabFromPath();

  const handleSelectTab = (tab: NavTab) => {
    navigate(`/app/${tab}`);
  };

  // 1. PUBLIC ROUTES: If user is not authenticated or visits public pages
  if (currentPath === '/') {
    return <LandingPage onNavigate={navigate} />;
  }

  if (currentPath === '/login') {
    return <LoginPage onSuccess={handleAuthSuccess} onNavigate={navigate} />;
  }

  if (currentPath === '/register') {
    return <RegisterPage onSuccess={handleAuthSuccess} onNavigate={navigate} />;
  }

  if (currentPath === '/forgot-password') {
    return <ForgotPasswordPage onNavigate={navigate} />;
  }

  // 2. PROTECTED AUTHENTICATED AREA: Unauthenticated users are redirected to /login
  if (!currentUser && authChecked) {
    return <LoginPage onSuccess={handleAuthSuccess} onNavigate={navigate} />;
  }

  // Fallback defaults while waiting for initial sensor fetch
  const safeReading: SensorReading = latestReading || {
    id: 'reading-current',
    sensorId: 'ESP32-001',
    gardenId: 'garden-jecrc-01',
    bedId: 'bed-tomatoes-01',
    timestamp: new Date().toISOString(),
    moisture: 41.0,
    soilTemperature: 27.4,
    humidity: 61.0,
    light: 720,
    rain: false,
    npkNitrogen: null,
    npkPhosphorus: null,
    npkPotassium: null,
    npkConnected: false,
    source: 'SIMULATED'
  };

  const safeReport: SoilHealthReport = soilHealthReport || {
    id: 'report-current',
    gardenId: 'garden-jecrc-01',
    bedId: 'bed-tomatoes-01',
    timestamp: new Date().toISOString(),
    status: 'HEALTHY',
    score: 82,
    moistureStatus: 'OPTIMAL',
    temperatureStatus: 'OPTIMAL',
    waterRisk: 'LOW',
    nutrientStatus: 'OPTIONAL_UNCONNECTED',
    recommendation: 'Your soil is currently in good condition. Moisture is within configured range.',
    confidence: 88,
    reasons: ['Moisture is within optimal vegetative range (40% - 75%).', 'Root temperature is nominal.'],
    calibratedThresholdsNotice: 'Demo thresholds — calibrated during field testing.',
    waterHealthScore: 88,
    nutrientHealthScore: 70,
    thermalScore: 92
  };

  const safeRecommendation: IrrigationRecommendation = irrigationRec || {
    action: 'NO_IRRIGATION',
    duration: 0,
    priority: 'NONE',
    reason: 'Moisture is within the configured optimal range.',
    confidence: 94
  };

  return (
    <div className="min-h-screen bg-[#F7FAF8] flex flex-col antialiased">
      {/* Top Header Bar */}
      <Header
        gardens={gardens}
        selectedGarden={selectedGarden}
        onSelectGarden={setSelectedGarden}
        beds={beds}
        selectedBed={selectedBed}
        onSelectBed={setSelectedBed}
        currentUser={currentUser || { id: 'usr-01', name: 'Elena Rostova', email: 'elena@soilsense.garden', role: 'GARDEN_MANAGER', createdAt: '' }}
        unreadAlertsCount={unreadAlertsCount}
        onOpenAlerts={() => navigate('/app/alerts')}
        onLogout={handleLogout}
        onNavigateHome={() => navigate('/app/dashboard')}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Left Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={handleSelectTab}
          unreadAlertsCount={unreadAlertsCount}
          isIrrigating={irrigationState.isActive}
          selectedGarden={selectedGarden}
          selectedBed={selectedBed}
        />

        {/* Main Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto pb-24 lg:pb-12 w-full">
          {activeTab === 'dashboard' && (
            <DashboardPage
              currentUser={currentUser || { id: 'usr-01', name: 'Elena Rostova', email: 'elena@soilsense.garden', role: 'GARDEN_MANAGER', createdAt: '' }}
              selectedGarden={selectedGarden}
              selectedBed={selectedBed}
              latestReading={safeReading}
              soilHealthReport={safeReport}
              irrigationRecommendation={safeRecommendation}
              irrigationState={irrigationState}
              history={history}
              alerts={alerts}
              devices={devices}
              onTriggerIrrigate={() => setConfirmModalOpen(true)}
              onNavigate={(tab) => navigate(`/app/${tab}`)}
            />
          )}

          {activeTab === 'gardens' && (
            <GardensPage
              gardens={gardens}
              beds={beds}
              selectedGarden={selectedGarden}
              onSelectGarden={setSelectedGarden}
              selectedBed={selectedBed}
              onSelectBed={setSelectedBed}
              onNavigateToDashboard={() => navigate('/app/dashboard')}
            />
          )}

          {activeTab === 'soil' && (
            <SoilHealthPage
              report={safeReport}
              reading={safeReading}
              history={history}
            />
          )}

          {activeTab === 'irrigation' && (
            <IrrigationPage
              state={irrigationState}
              events={irrigationEvents}
              recommendation={safeRecommendation}
              currentMoisture={safeReading.moisture}
              onOpenTriggerModal={() => setConfirmModalOpen(true)}
              onStopIrrigate={handleStopIrrigate}
            />
          )}

          {activeTab === 'sensors' && (
            <SensorsPage
              reading={safeReading}
              isDemo={isDemo}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsPage
              history={history}
              irrigationEvents={irrigationEvents}
            />
          )}

          {activeTab === 'alerts' && (
            <AlertsPage
              alerts={alerts}
              onMarkRead={handleMarkAlertRead}
              onMarkAllRead={handleMarkAllAlertsRead}
              onClearAlert={handleClearAlert}
              onClearAll={handleClearAllAlerts}
            />
          )}

          {activeTab === 'devices' && (
            <DevicesPage
              devices={devices}
              onRefreshDevices={async () => {
                const devs = await api.getDevices();
                setDevices(devs);
              }}
              activeScenario={activeScenario}
              onSelectScenario={handleSelectScenario}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsPage
              currentUser={currentUser || { id: 'usr-01', name: 'Elena Rostova', email: 'elena@soilsense.garden', role: 'GARDEN_MANAGER', createdAt: '' }}
              activeScenario={activeScenario}
              onSelectScenario={handleSelectScenario}
              isDemo={isDemo}
              onToggleDemo={handleToggleDemo}
              onSwitchUserRole={(role: UserRole) => {
                if (currentUser) {
                  setCurrentUser({ ...currentUser, role });
                }
              }}
            />
          )}

          {activeTab === 'scan' && (
            <CropScanPage
              latestReading={safeReading}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        unreadAlertsCount={unreadAlertsCount}
        isIrrigating={irrigationState.isActive}
        onLogout={handleLogout}
      />

      {/* Irrigation Confirmation Modal */}
      <IrrigationConfirmModal
        isOpen={confirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={handleConfirmIrrigate}
        currentMoisture={safeReading.moisture}
        recommendedDuration={safeRecommendation.duration || 6}
        bedName={selectedBed?.name || 'Tomato Bed'}
      />
    </div>
  );
}
