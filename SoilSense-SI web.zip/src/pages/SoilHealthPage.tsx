import React from 'react';
import {
  Sprout,
  Droplets,
  Thermometer,
  ShieldCheck,
  AlertTriangle,
  Beaker,
  Info,
  CheckCircle2,
  FileText,
  Sliders
} from 'lucide-react';
import { SoilHealthReport, SensorReading } from '../types/index.js';

interface SoilHealthPageProps {
  report: SoilHealthReport;
  reading: SensorReading;
  history: SensorReading[];
}

export const SoilHealthPage: React.FC<SoilHealthPageProps> = ({
  report,
  reading,
  history
}) => {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Soil Health Diagnostic Analysis</h2>
          <p className="text-xs text-slate-500">
            Multisensor telemetry interpretation for urban community plot optimization.
          </p>
        </div>

        <div className="text-[11px] text-slate-500 bg-white border border-slate-200 px-3 py-1.5 rounded-xl">
          Engine: <span className="font-semibold text-slate-800">Rule-Based Diagnostic v2.4</span>
        </div>
      </div>

      {/* Main Score & Sub-scores */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Overall Score */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Composite Soil Score
            </span>
            <div className="text-3xl font-black text-slate-900 mt-2">
              {report.score}<span className="text-sm font-normal text-slate-400 ml-1">/ 100</span>
            </div>
            <p className="text-xs font-semibold text-emerald-700 mt-1">
              Status: {report.status}
            </p>
          </div>
          <div className="mt-4 pt-2 border-t border-slate-100 text-[10px] text-slate-400">
            Weighted biological balance
          </div>
        </div>

        {/* Water Health Sub-score */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider">Water Health</span>
              <Droplets className="w-3.5 h-3.5 text-blue-600" />
            </div>
            <div className="text-2xl font-black text-slate-900 mt-2">
              {report.waterHealthScore}<span className="text-xs font-normal text-slate-400 ml-1">/ 100</span>
            </div>
            <p className="text-xs font-semibold text-slate-700 mt-1 capitalize">
              {report.moistureStatus.toLowerCase().replace('_', ' ')}
            </p>
          </div>
          <div className="mt-4 pt-2 border-t border-slate-100 text-[10px] text-slate-400">
            Capacitive moisture probe reading
          </div>
        </div>

        {/* Thermal Condition Sub-score */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider">Thermal Condition</span>
              <Thermometer className="w-3.5 h-3.5 text-amber-600" />
            </div>
            <div className="text-2xl font-black text-slate-900 mt-2">
              {report.thermalScore}<span className="text-xs font-normal text-slate-400 ml-1">/ 100</span>
            </div>
            <p className="text-xs font-semibold text-slate-700 mt-1 capitalize">
              {report.temperatureStatus.toLowerCase()} ({reading.soilTemperature}°C)
            </p>
          </div>
          <div className="mt-4 pt-2 border-t border-slate-100 text-[10px] text-slate-400">
            DS18B20 probe at root depth
          </div>
        </div>

        {/* Nutrient Health */}
        <div className="bg-slate-50 rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500">
              <span className="text-[11px] font-semibold uppercase tracking-wider">Nutrient Health</span>
              <Beaker className="w-3.5 h-3.5 text-purple-600" />
            </div>
            <div className="text-2xl font-black text-slate-700 mt-2">
              {report.nutrientHealthScore}<span className="text-xs font-normal text-slate-400 ml-1">/ 100</span>
            </div>
            <p className="text-xs font-semibold text-purple-800 mt-1">
              Estimated (NPK Optional)
            </p>
          </div>
          <div className="mt-4 pt-2 border-t border-slate-200/60 text-[10px] text-slate-500">
            Hardware probe disconnected
          </div>
        </div>
      </div>

      {/* Honest Scientific Classification Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">Sensor Measurement Provenance</h3>
            <p className="text-xs text-slate-500">
              Strict distinction between direct physical telemetry and algorithmic estimates.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 font-medium">
                <th className="pb-3 font-semibold">Parameter</th>
                <th className="pb-3 font-semibold">Sensor Hardware</th>
                <th className="pb-3 font-semibold">Current Value</th>
                <th className="pb-3 font-semibold">Measurement Type</th>
                <th className="pb-3 font-semibold">Diagnostic Target</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              <tr>
                <td className="py-3 font-bold text-slate-900">Soil Moisture</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">Capacitive V1.2 Probe</td>
                <td className="py-3 font-bold">{reading.moisture.toFixed(1)}%</td>
                <td className="py-3"><span className="text-emerald-700 font-semibold">Directly Measured</span></td>
                <td className="py-3 text-slate-500">40% – 75% optimal</td>
              </tr>
              <tr>
                <td className="py-3 font-bold text-slate-900">Soil Temperature</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">DS18B20 Waterproof</td>
                <td className="py-3 font-bold">{reading.soilTemperature.toFixed(1)}°C</td>
                <td className="py-3"><span className="text-emerald-700 font-semibold">Directly Measured</span></td>
                <td className="py-3 text-slate-500">18°C – 28°C biological sweet spot</td>
              </tr>
              <tr>
                <td className="py-3 font-bold text-slate-900">Ambient Humidity</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">DHT22 Digital</td>
                <td className="py-3 font-bold">{reading.humidity.toFixed(0)}%</td>
                <td className="py-3"><span className="text-emerald-700 font-semibold">Directly Measured</span></td>
                <td className="py-3 text-slate-500">50% – 75% relative</td>
              </tr>
              <tr>
                <td className="py-3 font-bold text-slate-900">Solar Irradiance</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">Photodiode Lux Sensor</td>
                <td className="py-3 font-bold">{reading.light} Lux</td>
                <td className="py-3"><span className="text-emerald-700 font-semibold">Directly Measured</span></td>
                <td className="py-3 text-slate-500">Canopy exposure indicator</td>
              </tr>
              <tr>
                <td className="py-3 font-bold text-slate-900">Precipitation</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">Optical Rain Module</td>
                <td className="py-3 font-bold">{reading.rain ? 'Active Rain' : 'Dry'}</td>
                <td className="py-3"><span className="text-emerald-700 font-semibold">Directly Measured</span></td>
                <td className="py-3 text-slate-500">Interrupt irrigation if true</td>
              </tr>
              <tr className="bg-slate-50/50">
                <td className="py-3 font-bold text-slate-900">Water Risk</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">Algorithmic Model</td>
                <td className="py-3 font-bold">{report.waterRisk} Risk</td>
                <td className="py-3"><span className="text-blue-700 font-semibold">Estimated / Modeled</span></td>
                <td className="py-3 text-slate-500">Low hypoxia & desiccation risk</td>
              </tr>
              <tr className="bg-slate-50/50">
                <td className="py-3 font-bold text-slate-900">NPK Macro Nutrients</td>
                <td className="py-3 font-mono text-[11px] text-slate-500">RS485 Probe (Unconnected)</td>
                <td className="py-3 text-slate-400 italic">Not connected</td>
                <td className="py-3"><span className="text-purple-700 font-semibold">Optional / Disconnected</span></td>
                <td className="py-3 text-slate-500">Field calibration required</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <span className="italic">{report.calibratedThresholdsNotice}</span>
          <span className="font-mono text-slate-400">Node: ESP32-001 (Rev 2)</span>
        </div>
      </div>

      {/* Full Explainable Logic Rules */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-3">
        <h3 className="text-base font-bold text-slate-900 tracking-tight">Active Agronomic Diagnosis</h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          {report.recommendation}
        </p>

        <div className="mt-3 space-y-2">
          {report.reasons.map((r, i) => (
            <div key={i} className="flex items-start gap-2.5 text-xs text-slate-700">
              <CheckCircle2 className="w-4 h-4 text-[#0B6B43] mt-0.5 shrink-0" />
              <span>{r}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
