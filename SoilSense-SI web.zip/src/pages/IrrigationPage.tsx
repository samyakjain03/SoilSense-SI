import React, { useState } from 'react';
import {
  Droplets,
  Play,
  Square,
  Clock,
  CheckCircle2,
  AlertCircle,
  Activity,
  History,
  ShieldCheck,
  Calendar
} from 'lucide-react';
import { IrrigationState, IrrigationEvent, IrrigationRecommendation } from '../types/index.js';

interface IrrigationPageProps {
  state: IrrigationState;
  events: IrrigationEvent[];
  recommendation: IrrigationRecommendation;
  currentMoisture: number;
  onOpenTriggerModal: () => void;
  onStopIrrigate: () => void;
}

export const IrrigationPage: React.FC<IrrigationPageProps> = ({
  state,
  events,
  recommendation,
  currentMoisture,
  onOpenTriggerModal,
  onStopIrrigate
}) => {
  const isPumping = state.isActive;

  // Calculate today's total watering duration
  const now = new Date();
  const todayEvents = events.filter((e) => {
    const d = new Date(e.startedAt);
    return (
      d.getDate() === now.getDate() &&
      d.getMonth() === now.getMonth() &&
      d.getFullYear() === now.getFullYear()
    );
  });
  const todaySeconds = todayEvents.reduce((acc, curr) => acc + curr.duration, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Automated Irrigation & Valve Actuators</h2>
          <p className="text-xs text-slate-500">
            Control relay, 12V solenoid valve, and submersible pump for Bed 1 drip lines.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isPumping ? (
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 text-blue-800 border border-blue-200 text-xs font-bold animate-pulse">
              <span className="w-2 h-2 rounded-full bg-blue-600" />
              CYCLE IN PROGRESS ({Math.floor(state.remainingSeconds / 60)}m {state.remainingSeconds % 60}s)
            </span>
          ) : (
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-slate-400" />
              Actuators Idle (Standby)
            </span>
          )}
        </div>
      </div>

      {/* Actuator State Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Submersible Pump */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Submersible Pump</span>
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
              state.pumpStatus === 'ON' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
            }`}>
              <Activity className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {state.pumpStatus}
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            Relay Pin: ESP32 GPIO 23
          </div>
        </div>

        {/* Solenoid Valve */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Solenoid Valve</span>
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
              state.valveStatus === 'OPEN' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
            }`}>
              <Droplets className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {state.valveStatus}
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] text-slate-500 font-mono">
            Relay Pin: ESP32 GPIO 22
          </div>
        </div>

        {/* Today's Watering */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Today's Run Time</span>
            <Clock className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-2xl font-black text-slate-900">
            {Math.round(todaySeconds / 60)} <span className="text-sm font-normal text-slate-400">min</span>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
            {todayEvents.length} cycles executed today
          </div>
        </div>

        {/* Current Moisture Status */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Bed Moisture</span>
            <Droplets className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">
            {currentMoisture.toFixed(1)}%
          </div>
          <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] text-slate-500">
            Target optimal threshold: 40% – 75%
          </div>
        </div>
      </div>

      {/* Manual Actuator Control Card */}
      <div className={`p-6 rounded-2xl border transition-all ${
        isPumping
          ? 'bg-blue-50/70 border-blue-200 shadow-md'
          : 'bg-white border-slate-200/90 shadow-xs'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#0B6B43]">Actuator Interface</span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs text-slate-600">Bed 1 Drip Grid</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-1">Manual & Emergency Override</h3>
            <p className="text-xs text-slate-600 max-w-xl mt-1 leading-relaxed">
              {isPumping
                ? `Actuator is currently energized (${state.reason}). Moisture is gradually recharging in the root zone.`
                : 'Execute on-demand irrigation or test solenoid valve flow. Confirmation required before relay engages.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {isPumping ? (
              <button
                onClick={onStopIrrigate}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-900/15 transition-all cursor-pointer"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Stop Irrigation Now</span>
              </button>
            ) : (
              <button
                onClick={onOpenTriggerModal}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-[#0B6B43] hover:bg-[#095736] text-white text-xs font-bold shadow-md shadow-emerald-900/15 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Start Irrigation Cycle</span>
              </button>
            )}
          </div>
        </div>

        {isPumping && (
          <div className="mt-4 pt-4 border-t border-blue-200/60 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-medium text-blue-950">
            <div>
              <span className="text-[10px] uppercase text-blue-700 font-bold">Remaining Duration</span>
              <p className="text-sm font-black font-mono">
                {Math.floor(state.remainingSeconds / 60)}m {state.remainingSeconds % 60}s
              </p>
            </div>
            <div>
              <span className="text-[10px] uppercase text-blue-700 font-bold">Start Moisture</span>
              <p className="text-sm font-black">{state.moistureBefore.toFixed(1)}%</p>
            </div>
            <div>
              <span className="text-[10px] uppercase text-blue-700 font-bold">Pump Motor</span>
              <p className="text-sm font-black text-emerald-700">ENGAGED (12V DC)</p>
            </div>
            <div>
              <span className="text-[10px] uppercase text-blue-700 font-bold">Valve Solenoid</span>
              <p className="text-sm font-black text-emerald-700">OPEN (Pressurized)</p>
            </div>
          </div>
        )}
      </div>

      {/* Historical Irrigation Log Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">Irrigation Actuation History</h3>
            <p className="text-xs text-slate-500">
              Audit log of all manual and sensor-triggered watering events.
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-400">Total events: {events.length}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 font-medium">
                <th className="pb-3 font-semibold">Timestamp</th>
                <th className="pb-3 font-semibold">Duration</th>
                <th className="pb-3 font-semibold">Trigger Mode</th>
                <th className="pb-3 font-semibold">Before Moisture</th>
                <th className="pb-3 font-semibold">After Moisture</th>
                <th className="pb-3 font-semibold">Hydration Gain</th>
                <th className="pb-3 font-semibold">Valve Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {events.length > 0 ? (
                events.map((ev) => {
                  const d = new Date(ev.startedAt);
                  const dateStr = d.toLocaleDateString([], { month: 'short', day: 'numeric' });
                  const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                  const gain = Math.max(0, ev.moistureAfter - ev.moistureBefore);

                  return (
                    <tr key={ev.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 font-medium text-slate-900">
                        {dateStr} · {timeStr}
                      </td>
                      <td className="py-3 font-mono font-semibold">
                        {Math.floor(ev.duration / 60)}m {ev.duration % 60}s
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          ev.trigger === 'AUTOMATED_THRESHOLD'
                            ? 'bg-blue-50 text-blue-800'
                            : 'bg-emerald-50 text-emerald-800'
                        }`}>
                          {ev.trigger.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 font-medium">{ev.moistureBefore.toFixed(1)}%</td>
                      <td className="py-3 font-bold text-slate-900">{ev.moistureAfter.toFixed(1)}%</td>
                      <td className="py-3 font-bold text-emerald-700">+{gain.toFixed(1)}%</td>
                      <td className="py-3 text-slate-500 font-mono text-[11px]">Normal Close</td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400 text-xs">
                    No past irrigation events recorded.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
