import React, { useState } from 'react';
import {
  Sliders,
  User,
  Layers,
  Droplets,
  Bell,
  Cpu,
  Sparkles,
  Check,
  Save,
  CheckCircle2,
  AlertTriangle,
  Flame,
  CloudRain,
  XCircle,
  ShieldCheck
} from 'lucide-react';
import { UserProfile, UserRole, DemoScenario } from '../types/index.js';

interface SettingsPageProps {
  currentUser: UserProfile;
  activeScenario: DemoScenario;
  onSelectScenario: (sc: DemoScenario) => void;
  isDemo: boolean;
  onToggleDemo: (val: boolean) => void;
  onSwitchUserRole: (role: UserRole) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  currentUser,
  activeScenario,
  onSelectScenario,
  isDemo,
  onToggleDemo,
  onSwitchUserRole
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'garden' | 'thresholds' | 'irrigation' | 'notifications' | 'demo'>('thresholds');
  const [dryThreshold, setDryThreshold] = useState(30);
  const [waterloggedThreshold, setWaterloggedThreshold] = useState(80);
  const [tempStressThreshold, setTempStressThreshold] = useState(35);
  const [autoIrrigation, setAutoIrrigation] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const demoScenarios: {
    id: DemoScenario;
    label: string;
    description: string;
    icon: React.ElementType;
    color: string;
  }[] = [
    {
      id: 'HEALTHY',
      label: 'Healthy Soil',
      description: '55–70% moisture, nominal temperature, no rain.',
      icon: CheckCircle2,
      color: 'text-emerald-700'
    },
    {
      id: 'DRY_SOIL',
      label: 'Dry Soil',
      description: '15–30% moisture, clear skies. Irrigation recommended.',
      icon: Droplets,
      color: 'text-amber-700'
    },
    {
      id: 'WATERLOGGED',
      label: 'Waterlogged Soil',
      description: '80–95% saturation. Hypoxia risk, irrigation locked out.',
      icon: CloudRain,
      color: 'text-blue-700'
    },
    {
      id: 'HOT_DRY',
      label: 'Hot + Dry Stress',
      description: '35–42°C heat wave with depleted moisture (< 30%).',
      icon: Flame,
      color: 'text-rose-700'
    },
    {
      id: 'RECENT_RAIN',
      label: 'Recent Rain',
      description: 'Digital rain sensor triggered. Irrigation withheld.',
      icon: CloudRain,
      color: 'text-indigo-700'
    },
    {
      id: 'SENSOR_FAILURE',
      label: 'Sensor Failure',
      description: 'Analog line disconnected / open circuit alert.',
      icon: XCircle,
      color: 'text-red-700'
    }
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">System Settings & Configuration</h2>
        <p className="text-xs text-slate-500">
          Configure agronomic thresholds, profile settings, and simulation scenarios.
        </p>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-2xl overflow-x-auto">
        {[
          { id: 'thresholds', label: 'Soil Thresholds', icon: Sliders },
          { id: 'irrigation', label: 'Irrigation', icon: Droplets },
          { id: 'demo', label: 'Demo Mode', icon: Sparkles },
          { id: 'profile', label: 'Profile & Role', icon: User },
          { id: 'garden', label: 'Garden Info', icon: Layers },
          { id: 'notifications', label: 'Notifications', icon: Bell }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-white text-[#0B6B43] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Soil Thresholds */}
      {activeTab === 'thresholds' && (
        <form onSubmit={handleSave} className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-5">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Soil Decision Thresholds</h3>
            <p className="text-xs text-slate-500">Configure trigger boundaries for your community garden soil type.</p>
          </div>

          <div className="space-y-4 pt-2">
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-800">Dry Soil Irrigation Threshold</span>
                <span className="font-mono font-bold text-[#0B6B43]">{dryThreshold}%</span>
              </div>
              <input
                type="range"
                min="15"
                max="45"
                value={dryThreshold}
                onChange={(e) => setDryThreshold(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg cursor-pointer accent-[#0B6B43]"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Moisture level below which the system generates a watering recommendation.
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-800">Waterlogged Saturation Boundary</span>
                <span className="font-mono font-bold text-blue-700">{waterloggedThreshold}%</span>
              </div>
              <input
                type="range"
                min="70"
                max="95"
                value={waterloggedThreshold}
                onChange={(e) => setWaterloggedThreshold(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg cursor-pointer accent-[#1769AA]"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Absolute lockout threshold. Suspends pump actuation to protect roots from hypoxia.
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-800">Thermal Heat Stress Threshold</span>
                <span className="font-mono font-bold text-amber-700">{tempStressThreshold}°C</span>
              </div>
              <input
                type="range"
                min="28"
                max="42"
                value={tempStressThreshold}
                onChange={(e) => setTempStressThreshold(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg cursor-pointer accent-[#E88922]"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Root zone temperature triggering heat stress warnings.
              </p>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-400 italic">Demo thresholds — calibrated during field testing.</span>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-xl shadow-xs cursor-pointer"
            >
              {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
              <span>{savedSuccess ? 'Saved' : 'Save Thresholds'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Irrigation Settings */}
      {activeTab === 'irrigation' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Irrigation Controller Settings</h3>
          <p className="text-xs text-slate-500">Configure automated solenoid valve and pump actuation behaviors.</p>

          <div className="space-y-3 pt-2">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900">Automatic Irrigation Mode</p>
                <p className="text-[11px] text-slate-500">Automatically open valve when moisture drops below threshold.</p>
              </div>
              <input
                type="checkbox"
                checked={autoIrrigation}
                onChange={(e) => setAutoIrrigation(e.target.checked)}
                className="w-4 h-4 text-[#0B6B43] rounded cursor-pointer accent-[#0B6B43]"
              />
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900">Rain Sensor Interlock</p>
                <p className="text-[11px] text-slate-500">Immediately inhibit scheduled irrigation if digital rain sensor triggers.</p>
              </div>
              <span className="text-xs font-bold text-emerald-700">Active</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900">Default Watering Cycle Duration</p>
                <p className="text-[11px] text-slate-500">6 minutes per drip cycle for 14.5 m² Tomato Bed.</p>
              </div>
              <span className="text-xs font-bold text-slate-800">6 Minutes</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: DEMO MODE (Section 27) */}
      {activeTab === 'demo' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#0B6B43] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  DEMO MODE ENGINE
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mt-1">Realistic Scenario Simulation</h3>
              <p className="text-xs text-slate-500">
                Pushes simulated microclimate events to the backend decision pipeline.
              </p>
            </div>

            <div className="flex items-center bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => onToggleDemo(true)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg ${isDemo ? 'bg-white text-[#0B6B43] shadow-xs' : 'text-slate-600'}`}
              >
                Simulation On
              </button>
              <button
                onClick={() => onToggleDemo(false)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg ${!isDemo ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600'}`}
              >
                Live Hardware
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
            {demoScenarios.map((sc) => {
              const Icon = sc.icon;
              const isActive = activeScenario === sc.id;
              return (
                <button
                  key={sc.id}
                  onClick={() => onSelectScenario(sc.id)}
                  className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                    isActive
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                      : 'bg-slate-50 hover:bg-white text-slate-800 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <span className="text-xs font-bold">{sc.label}</span>
                    <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : sc.color}`} />
                  </div>
                  <p className={`text-[11px] leading-relaxed ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                    {sc.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 4: Profile & Role */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900">User Profile & Permissions</h3>
          <p className="text-xs text-slate-500">Your account identity in SoilSense AI.</p>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-4">
            <img
              src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
              alt={currentUser.name}
              className="w-12 h-12 rounded-full object-cover border"
            />
            <div>
              <p className="text-sm font-bold text-slate-900">{currentUser.name}</p>
              <p className="text-xs text-slate-500">{currentUser.email}</p>
              <span className="inline-block mt-1 text-[10px] font-bold text-[#0B6B43] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Role: {currentUser.role}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Garden Info */}
      {activeTab === 'garden' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900">JECRC Community Garden Station</h3>
          <p className="text-xs text-slate-500">Primary community plot configuration.</p>
          <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
            <div className="p-3 rounded-xl bg-slate-50">
              <span className="text-slate-400 block text-[10px]">Location</span>
              <span className="font-bold text-slate-900">Block C Plots, Urban Ecological Zone</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50">
              <span className="text-slate-400 block text-[10px]">Bed Count</span>
              <span className="font-bold text-slate-900">12 Raised Beds</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Notifications */}
      {activeTab === 'notifications' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Notification Preferences</h3>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-900">Critical Dry Soil Alerts</p>
              <p className="text-[11px] text-slate-500">Notify immediately when bed moisture drops below threshold.</p>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="w-4 h-4 text-[#0B6B43] rounded cursor-pointer accent-[#0B6B43]"
            />
          </div>
        </div>
      )}
    </div>
  );
};
