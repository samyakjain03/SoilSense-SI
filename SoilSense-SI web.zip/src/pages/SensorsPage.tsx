import React, { useState } from 'react';
import {
  Droplets,
  Thermometer,
  Cloud,
  Sun,
  CloudRain,
  Beaker,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Wifi,
  Cpu,
  ChevronDown,
  ChevronUp,
  Info
} from 'lucide-react';
import { SensorReading } from '../types/index.js';

interface SensorsPageProps {
  reading: SensorReading;
  isDemo: boolean;
}

export const SensorsPage: React.FC<SensorsPageProps> = ({ reading, isDemo }) => {
  const [showAdvancedDetails, setShowAdvancedDetails] = useState(false);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Connected Sensor Nodes</h2>
          <p className="text-xs text-slate-500">
            Real-time telemetry streamed from IoT field probes in JECRC Community Garden.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            ESP32 Node 01: ONLINE
          </span>
        </div>
      </div>

      {/* Main Clean Sensor Card (Section 21) */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0B6B43] flex items-center justify-center">
              <Cpu className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900">ESP32 Node 01</h3>
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded">
                  ONLINE
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">Assigned to: JECRC Community Garden · Tomato Bed</p>
            </div>
          </div>

          <span className="text-xs font-mono text-slate-400">Firmware: v2.4.1-edge</span>
        </div>

        {/* Primary Clean Telemetry Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
          {/* Moisture */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center">
            <span className="text-xs font-bold text-slate-400 uppercase block mb-1">Moisture</span>
            <span className="text-2xl font-black text-slate-900">{reading.moisture.toFixed(0)}%</span>
            <span className="text-[11px] text-[#0B6B43] font-semibold block mt-1">Optimal</span>
          </div>

          {/* Temperature */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center">
            <span className="text-xs font-bold text-slate-400 uppercase block mb-1">Temperature</span>
            <span className="text-2xl font-black text-slate-900">{reading.soilTemperature.toFixed(1)}°C</span>
            <span className="text-[11px] text-slate-500 block mt-1">Root Depth</span>
          </div>

          {/* Humidity */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center">
            <span className="text-xs font-bold text-slate-400 uppercase block mb-1">Humidity</span>
            <span className="text-2xl font-black text-slate-900">{reading.humidity.toFixed(0)}%</span>
            <span className="text-[11px] text-slate-500 block mt-1">Ambient</span>
          </div>

          {/* Light */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center">
            <span className="text-xs font-bold text-slate-400 uppercase block mb-1">Light</span>
            <span className="text-2xl font-black text-slate-900">{reading.light}</span>
            <span className="text-[11px] text-slate-500 block mt-1">Lux</span>
          </div>

          {/* Rain */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-center col-span-2 sm:col-span-1">
            <span className="text-xs font-bold text-slate-400 uppercase block mb-1">Rain</span>
            <span className="text-xl font-black text-slate-900 pt-0.5 block">{reading.rain ? 'Yes' : 'No'}</span>
            <span className="text-[11px] text-slate-500 block mt-1">{reading.rain ? 'Detected' : 'Dry Surface'}</span>
          </div>
        </div>

        {/* View Details Toggle */}
        <div className="pt-2 border-t border-slate-100">
          <button
            onClick={() => setShowAdvancedDetails(!showAdvancedDetails)}
            className="flex items-center gap-1.5 text-xs font-semibold text-[#0B6B43] hover:underline cursor-pointer"
          >
            <span>{showAdvancedDetails ? 'Hide technical pinout details' : 'View details & pinout mappings'}</span>
            {showAdvancedDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showAdvancedDetails && (
            <div className="mt-4 p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3 text-xs text-slate-700 animate-in fade-in duration-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Hardware Probe Specifications:</h4>
                  <ul className="space-y-1.5 text-slate-600">
                    <li>· <strong>Capacitive V1.2 Probe:</strong> Connected to ESP32 GPIO 34 (ADC1_CH6, 12-bit calibration).</li>
                    <li>· <strong>DS18B20 Probe:</strong> Waterproof stainless steel probe on GPIO 4 (Dallas 1-Wire).</li>
                    <li>· <strong>DHT22 Sensor:</strong> Single-bus digital input on GPIO 15.</li>
                    <li>· <strong>Optical Rain Sensor:</strong> Digital interrupt line on GPIO 18.</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Optional Probes:</h4>
                  <p className="text-slate-600 leading-relaxed">
                    <strong>NPK Sensor — Optional Extension:</strong> RS485 Modbus interface is currently unplugged. Soil analysis operates using ground-truth capacitive and thermal data.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
