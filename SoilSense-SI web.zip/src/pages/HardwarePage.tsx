import React, { useState } from 'react';
import {
  Cpu,
  Zap,
  Activity,
  Layers,
  ShieldCheck,
  Code,
  Copy,
  Check,
  Wifi,
  WifiOff,
  Server,
  PlusCircle
} from 'lucide-react';
import { DeviceInfo } from '../types/index.js';
import { api } from '../services/api.js';

interface HardwarePageProps {
  devices: DeviceInfo[];
  onRefreshDevices: () => void;
}

export const HardwarePage: React.FC<HardwarePageProps> = ({
  devices,
  onRefreshDevices
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [newDeviceId, setNewDeviceId] = useState('ESP32-004');
  const [newDeviceName, setNewDeviceName] = useState('ESP32 Node 4 (Bed 2)');
  const [isRegistering, setIsRegistering] = useState(false);

  const sampleArduinoCode = `/*
 * SoilSense AI - ESP32 Field Node Firmware
 * Target: ESP32-WROOM-32 / NodeMCU ESP32
 * Sends capacitive moisture & DS18B20 telemetry to SoilSense API
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ArduinoJson.h>

// Wi-Fi Credentials
const char* ssid     = "UrbanGarden-WiFi";
const char* password = "CommunityCompost2026";

// Server Endpoint
const char* serverUrl = "https://your-soilsense-url/api/devices/ESP32-001/readings";

// Pin Configuration
#define MOISTURE_PIN 34    // Capacitive Soil Moisture (ADC1_CH6)
#define ONE_WIRE_BUS 4     // DS18B20 Temperature Data Pin
#define RAIN_PIN     18    // Optical Rain Sensor Digital Output
#define RELAY_PUMP   23    // Relay for 12V Submersible Pump
#define RELAY_VALVE  22    // Relay for 12V Solenoid Valve

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature tempSensors(&oneWire);

void setup() {
  Serial.begin(115200);
  tempSensors.begin();
  pinMode(RAIN_PIN, INPUT_PULLUP);
  pinMode(RELAY_PUMP, OUTPUT);
  pinMode(RELAY_VALVE, OUTPUT);
  digitalWrite(RELAY_PUMP, LOW);
  digitalWrite(RELAY_VALVE, LOW);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\\nWiFi Connected!");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    // 1. Read Capacitive Moisture (Calibrated analog map)
    int rawMoisture = analogRead(MOISTURE_PIN);
    float moisturePct = map(rawMoisture, 3200, 1400, 0, 100);
    moisturePct = constrain(moisturePct, 0.0, 100.0);

    // 2. Read DS18B20 Soil Temperature
    tempSensors.requestTemperatures();
    float soilTemp = tempSensors.getTempCByIndex(0);

    // 3. Read Rain Sensor
    bool isRaining = (digitalRead(RAIN_PIN) == LOW);

    // 4. Construct JSON Payload
    HTTPClient http;
    http.begin(serverUrl);
    http.addHeader("Content-Type", "application/json");

    StaticJsonDocument<256> doc;
    doc["deviceId"] = "ESP32-001";
    doc["moisture"] = moisturePct;
    doc["soilTemperature"] = soilTemp;
    doc["humidity"] = 62.0;
    doc["light"] = 540;
    doc["rain"] = isRaining;
    doc["timestamp"] = "2026-10-08T11:00:00Z";

    String requestBody;
    serializeJson(doc, requestBody);

    int httpResponseCode = http.POST(requestBody);
    Serial.printf("Telemetry dispatched. HTTP Code: %d\\n", httpResponseCode);
    http.end();
  }

  delay(15000); // Sample every 15 seconds
}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(sampleArduinoCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleRegisterDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeviceId) return;
    setIsRegistering(true);
    try {
      await api.registerDevice({
        id: newDeviceId,
        name: newDeviceName,
        type: 'NODE1_ENVIRONMENT',
        gardenId: 'garden-highland-01',
        bedId: 'bed-greens-02'
      });
      onRefreshDevices();
      setNewDeviceId(`ESP32-00${devices.length + 2}`);
      setNewDeviceName(`ESP32 Node ${devices.length + 2}`);
    } catch (err) {
      console.error('Error registering device:', err);
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">ESP32 Hardware & Edge Architecture</h2>
        <p className="text-xs text-slate-500">
          Edge-first multi-node pipeline connecting physical garden probes to local actuation and cloud synchronization.
        </p>
      </div>

      {/* Visual Edge Pipeline (Section 21) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-[#0B6B43] flex items-center justify-center font-bold">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Edge-Authoritative Pipeline Representation</h3>
              <p className="text-xs text-slate-500">Hardware to actuation data path</p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Autonomous Local Fallback</span>
          </div>
        </div>

        {/* Pipeline Nodes */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400">Layer 1: Probes</span>
            <h4 className="text-xs font-bold text-slate-900">Physical Sensors</h4>
            <p className="text-[11px] text-slate-600 leading-tight">
              Capacitive moisture probe, DS18B20 waterproof thermal probe, optical rain detector, photodiode lux.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400">Layer 2: Edge MCU</span>
            <h4 className="text-xs font-bold text-slate-900">ESP32 Node 1 & 2</h4>
            <p className="text-[11px] text-slate-600 leading-tight">
              Local ADC sampling, moving-average outlier rejection, and TensorFlow Lite Micro edge heuristics.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-slate-400">Layer 3: Actuator</span>
            <h4 className="text-xs font-bold text-slate-900">Relay & Solenoid</h4>
            <p className="text-[11px] text-slate-600 leading-tight">
              Optocoupler relay board driving 12V submersible pump and solenoid valve. Works without internet.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
            <span className="text-[10px] uppercase font-bold text-emerald-700">Layer 4: Cloud</span>
            <h4 className="text-xs font-bold text-slate-900">SoilSense AI API</h4>
            <p className="text-[11px] text-slate-600 leading-tight">
              Longitudinal Firestore/persistent storage, Gemini AI synthesis, audit logs, and community dashboard.
            </p>
          </div>
        </div>
      </div>

      {/* Connected Hardware Devices Registry */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">Active Hardware Registry</h3>
            <p className="text-xs text-slate-500">
              Microcontroller nodes provisioned for community plot telemetry.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {devices.map((dev) => (
            <div key={dev.id} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">{dev.name}</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {dev.status}
                </span>
              </div>
              <p className="text-[11px] font-mono text-slate-500">ID: {dev.id}</p>
              <div className="text-[11px] text-slate-600">
                Firmware: <span className="font-mono text-slate-800">{dev.firmwareVersion}</span>
              </div>
              <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-200/60 flex items-center justify-between">
                <span>Assigned: {dev.bedId}</span>
                <span>{dev.batteryLevel ? `Battery: ${dev.batteryLevel}%` : 'DC Powered'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Provisioning Form */}
        <form onSubmit={handleRegisterDevice} className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-3">
          <div className="text-xs font-semibold text-slate-700">Pair New Node:</div>
          <input
            type="text"
            value={newDeviceId}
            onChange={(e) => setNewDeviceId(e.target.value)}
            placeholder="Node ID (e.g. ESP32-004)"
            className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
          />
          <input
            type="text"
            value={newDeviceName}
            onChange={(e) => setNewDeviceName(e.target.value)}
            placeholder="Node Label"
            className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-white"
          />
          <button
            type="submit"
            disabled={isRegistering}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-lg transition-colors cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Register Node</span>
          </button>
        </form>
      </div>

      {/* Arduino C++ Firmware Code Generator (Section 20 & 30) */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 sm:p-6 shadow-md border border-slate-800">
        <div className="flex items-center justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-emerald-400" />
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Production ESP32 Firmware Source (Arduino C++)
              </h3>
              <p className="text-[11px] text-slate-400">
                Ready to flash to ESP32 board via Arduino IDE or PlatformIO.
              </p>
            </div>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedCode ? 'Copied to Clipboard' : 'Copy Code'}</span>
          </button>
        </div>

        <pre className="p-4 rounded-xl bg-slate-950 font-mono text-[11px] text-emerald-300/90 overflow-x-auto max-h-80 leading-relaxed border border-slate-800/80">
          {sampleArduinoCode}
        </pre>
      </div>
    </div>
  );
};
