import React, { useState } from 'react';
import {
  Bell,
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle2,
  Trash2,
  Check,
  CheckCheck,
  Filter
} from 'lucide-react';
import { AlertItem } from '../types/index.js';

interface AlertsPageProps {
  alerts: AlertItem[];
  onMarkRead: (alertId: string) => void;
  onMarkAllRead: () => void;
  onClearAlert: (alertId: string) => void;
  onClearAll: () => void;
}

export const AlertsPage: React.FC<AlertsPageProps> = ({
  alerts,
  onMarkRead,
  onMarkAllRead,
  onClearAlert,
  onClearAll
}) => {
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'critical' | 'warning' | 'info'>('all');

  const filteredAlerts = alerts.filter((a) => {
    if (filterSeverity === 'all') return true;
    return a.severity === filterSeverity;
  });

  const getSeverityMeta = (sev: AlertItem['severity']) => {
    switch (sev) {
      case 'critical':
        return {
          icon: AlertCircle,
          color: 'text-rose-700',
          bg: 'bg-rose-50 border-rose-200',
          badge: 'Critical'
        };
      case 'warning':
        return {
          icon: AlertTriangle,
          color: 'text-amber-700',
          bg: 'bg-amber-50 border-amber-200',
          badge: 'Warning'
        };
      case 'success':
        return {
          icon: CheckCircle2,
          color: 'text-emerald-700',
          bg: 'bg-emerald-50 border-emerald-200',
          badge: 'Completed'
        };
      case 'info':
      default:
        return {
          icon: Info,
          color: 'text-blue-700',
          bg: 'bg-blue-50 border-blue-200',
          badge: 'Info'
        };
    }
  };

  const unreadCount = alerts.filter(a => a.status === 'active').length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">System & Soil Alerts</h2>
          <p className="text-xs text-slate-500">
            Real-time threshold notifications for JECRC Community Garden beds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={onMarkAllRead}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5 text-[#0B6B43]" />
              <span>Mark all as read</span>
            </button>
          )}

          {alerts.length > 0 && (
            <button
              onClick={onClearAll}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear all</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl self-start max-w-fit">
        {(['all', 'critical', 'warning', 'info'] as const).map((sev) => (
          <button
            key={sev}
            onClick={() => setFilterSeverity(sev)}
            className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize transition-all cursor-pointer ${
              filterSeverity === sev
                ? 'bg-white text-[#0B6B43] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {sev === 'all' ? 'All Alerts' : sev}
          </button>
        ))}
      </div>

      {/* Alerts Feed */}
      <div className="space-y-3">
        {filteredAlerts.length > 0 ? (
          filteredAlerts.map((alert) => {
            const meta = getSeverityMeta(alert.severity);
            const Icon = meta.icon;
            const isRead = alert.status === 'read';
            const d = new Date(alert.timestamp);
            const timeStr = `${d.toLocaleDateString([], { month: 'short', day: 'numeric' })} · ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

            return (
              <div
                key={alert.id}
                className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  isRead ? 'bg-white/80 border-slate-200/60 opacity-80' : 'bg-white border-slate-200 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${meta.bg} ${meta.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${meta.bg} ${meta.color}`}>
                        {meta.badge}
                      </span>
                      <span className="text-xs font-bold text-slate-900">{alert.title}</span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                      {alert.message}
                    </p>

                    <p className="text-[10px] text-slate-400 font-mono pt-0.5">
                      {timeStr} · {alert.bedId || 'JECRC Community Garden'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  {!isRead && (
                    <button
                      onClick={() => onMarkRead(alert.id)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5 text-slate-500" />
                      <span>Mark read</span>
                    </button>
                  )}

                  <button
                    onClick={() => onClearAlert(alert.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    title="Dismiss alert"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200/90 p-12 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-900">No Active Alerts</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Soil conditions in your community plots are currently within nominal thresholds.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
