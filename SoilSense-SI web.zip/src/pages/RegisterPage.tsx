import React, { useState } from 'react';
import { Sprout, ArrowRight, Lock, Mail, User, ShieldCheck, AlertCircle } from 'lucide-react';
import { api } from '../services/api.js';
import { UserProfile } from '../types/index.js';

interface RegisterPageProps {
  onSuccess: (user: UserProfile) => void;
  onNavigate: (route: string) => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({ onSuccess, onNavigate }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      const res = await api.register(name, email, password, confirmPassword);
      onSuccess(res.user);
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7FAF8] flex flex-col justify-center">
      <div className="max-w-4xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[580px]">
          
          {/* Left Hero Branding */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#0B6B43] to-[#084D30] p-8 sm:p-10 text-white flex flex-col justify-between relative overflow-hidden">
            <div>
              <div 
                className="flex items-center gap-2.5 cursor-pointer mb-8"
                onClick={() => onNavigate('/')}
              >
                <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center text-emerald-100 border border-white/20">
                  <Sprout className="w-5 h-5" />
                </div>
                <div>
                  <span className="font-extrabold text-xl tracking-tight">SoilSense</span>
                  <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-emerald-400/20 text-emerald-200 ml-1.5 border border-emerald-300/30">
                    AI
                  </span>
                </div>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
                Join Your Community Garden Network
              </h2>
              <p className="text-emerald-100/80 text-xs sm:text-sm mt-3 leading-relaxed">
                Connect your beds to real-time capacitive moisture probes, waterproof thermal sensors, and automated irrigation.
              </p>
            </div>

            <div className="my-6 p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-200">
                <ShieldCheck className="w-4 h-4" />
                <span>Account Role: Garden Manager</span>
              </div>
              <p className="text-[11px] text-white/80 leading-relaxed">
                Empowers you to manage bed thresholds, view continuous telemetry, receive dry alerts, and trigger irrigation cycles.
              </p>
            </div>

            <div className="text-[11px] text-emerald-100/60 flex items-center justify-between">
              <span>SoilSense AI System</span>
              <button 
                onClick={() => onNavigate('/login')}
                className="text-white font-semibold hover:underline cursor-pointer"
              >
                Already have an account? Sign In &rarr;
              </button>
            </div>
          </div>

          {/* Right Registration Form */}
          <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-center">
            <div className="max-w-md w-full mx-auto space-y-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Create Garden Account</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Enter your details to register as a Garden Manager.
                </p>
              </div>

              {error && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Marcus Vance"
                      className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 text-slate-900 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43] bg-slate-50/50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@communitygarden.org"
                      className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 text-slate-900 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43] bg-slate-50/50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 text-slate-900 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43] bg-slate-50/50"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="password"
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 text-slate-900 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43] bg-slate-50/50"
                      />
                    </div>
                  </div>
                </div>

                {/* Role Note */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-[11px] text-slate-600">
                  <span className="font-semibold text-slate-800">Assigned Role:</span> Garden Manager (Admin privileges are managed securely via station database).
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] shadow-md shadow-emerald-900/15 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>{loading ? 'Creating Account...' : 'Create Account & Open Dashboard'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>

              <div className="pt-2 text-center text-xs text-slate-500">
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => onNavigate('/login')}
                  className="font-bold text-[#0B6B43] hover:underline cursor-pointer ml-1"
                >
                  Sign In
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
