import React, { useState } from 'react';
import {
  Cpu,
  Camera,
  Activity,
  PlusCircle,
  ShieldCheck,
  Code,
  Copy,
  Check,
  Zap,
  Wifi,
  Sparkles
} from 'lucide-react';
import { DeviceInfo, DemoScenario } from '../types/index.js';
import { api } from '../services/api.js';

interface DevicesPageProps {
  devices: DeviceInfo[];
  onRefreshDevices: () => void;
  activeScenario?: DemoScenario;
  onSelectScenario?: (sc: DemoScenario) => void;
}

export const DevicesPage: React.FC<DevicesPageProps> = ({
  devices,
  onRefreshDevices,
  activeScenario,
  onSelectScenario
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [newDeviceId, setNewDeviceId] = useState('ESP32-003');
  const [newDeviceName, setNewDeviceName] = useState('ESP32 Node 03 (Herb Bed)');
  const [isRegistering, setIsRegistering] = useState(false);

  const sampleArduinoCode = `/*
 * SoilSense AI - ESP32 Field Node Firmware
 * Target: ESP32-WROOM-32 / NodeMCU ESP32
 * Sends capacitive moisture & DS18B20 telemetry to SoilSense API
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ArduinoJson.h>

const char* ssid     = "UrbanGarden-WiFi";
const char* password = "CommunityCompost2026";
const char* serverUrl = "https://your-soilsense-url/api/devices/ESP32-001/readings";

#define MOISTURE_PIN 34    // Capacitive Soil Moisture
#define ONE_WIRE_BUS 4     // DS18B20 1-Wire Probe
#define RELAY_PUMP   23    // Submersible Pump Relay
#define RELAY_VALVE  22    // Solenoid Valve Relay

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature tempSensors(&oneWire);

void setup() {
  Serial.begin(115200);
  tempSensors.begin();
  pinMode(RELAY_PUMP, OUTPUT);
  pinMode(RELAY_VALVE, OUTPUT);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); }
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    int raw = analogRead(MOISTURE_PIN);
    float moisture = map(raw, 3200, 1400, 0, 100);
    tempSensors.requestTemperatures();
    float temp = tempSensors.getTempCByIndex(0);

    HTTPClient http;
    http.begin(serverUrl);
    http.addHeader("Content-Type", "application/json");

    StaticJsonDocument<256> doc;
    doc["deviceId"] = "ESP32-001";
    doc["moisture"] = constrain(moisture, 0.0, 100.0);
    doc["soilTemperature"] = temp;

    String body;
    serializeJson(doc, body);
    http.POST(body);
    http.end();
  }
  delay(15000);
}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(sampleArduinoCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeviceId) return;
    setIsRegistering(true);
    try {
      await api.registerDevice({
        id: newDeviceId,
        name: newDeviceName,
        type: 'NODE1_ENVIRONMENT',
        gardenId: 'garden-jecrc-01',
        bedId: 'bed-herbs-03'
      });
      onRefreshDevices();
      setNewDeviceId(`ESP32-00${devices.length + 2}`);
    } catch (err) {
      console.error('Registration failed:', err);
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">Connected Devices & Edge Controllers</h2>
        <p className="text-xs text-slate-500">
          Hardware status and device registry for JECRC Community Garden plots.
        </p>
      </div>

      {/* Primary Hardware Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* ESP32 Node */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <Cpu className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                ONLINE
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900">ESP32 Node 01</h3>
            <p className="text-xs text-slate-500 mt-0.5">Sensory Telemetry Probe</p>
            <p className="text-[11px] text-slate-600 mt-3 leading-relaxed">
              Acquires capacitive analog signal and DS18B20 digital 1-Wire temperature.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>Tomato Bed</span>
            <span>v2.4.1-edge</span>
          </div>
        </div>

        {/* ESP32-CAM */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
                <Camera className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                ONLINE
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900">ESP32-CAM</h3>
            <p className="text-xs text-slate-500 mt-0.5">Optical Canopy Sensor</p>
            <p className="text-[11px] text-slate-600 mt-3 leading-relaxed">
              Captures high-resolution canopy photos for visual nutrient deficiency analysis.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>Tomato Bed</span>
            <span>v1.2.3-ov2640</span>
          </div>
        </div>

        {/* Relay Controller */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                <Activity className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                READY
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900">Relay Controller</h3>
            <p className="text-xs text-slate-500 mt-0.5">12V Solenoid & Pump</p>
            <p className="text-[11px] text-slate-600 mt-3 leading-relaxed">
              Opto-isolated relay interface for autonomous drip irrigation line actuation.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>GPIO 22 / 23</span>
            <span>Standby</span>
          </div>
        </div>
      </div>

      {/* Firmware Code Snippet */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 shadow-md border border-slate-800">
        <div className="flex items-center justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Flashable ESP32 Firmware Source (Arduino C++)
            </h3>
          </div>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer"
          >
            {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedCode ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        <pre className="p-3.5 rounded-xl bg-slate-950 font-mono text-[11px] text-emerald-300/90 overflow-x-auto max-h-56 leading-relaxed">
          {sampleArduinoCode}
        </pre>
      </div>

      {/* Device Registration Form */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 mb-1">Pair New Sensor Node</h3>
        <p className="text-xs text-slate-500 mb-4">Register an additional ESP32 node to monitor a new plot bed.</p>

        <form onSubmit={handleRegister} className="flex flex-wrap items-center gap-3">
          <input
            type="text"
            value={newDeviceId}
            onChange={(e) => setNewDeviceId(e.target.value)}
            placeholder="Node ID"
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50"
          />
          <input
            type="text"
            value={newDeviceName}
            onChange={(e) => setNewDeviceName(e.target.value)}
            placeholder="Node Name"
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 min-w-[200px]"
          />
          <button
            type="submit"
            disabled={isRegistering}
            className="px-4 py-2 text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Register Node</span>
          </button>
        </form>
      </div>
    </div>
  );
};
