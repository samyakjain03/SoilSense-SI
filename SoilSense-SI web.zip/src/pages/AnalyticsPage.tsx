import React, { useState } from 'react';
import {
  Download,
  Calendar,
  Filter,
  TrendingUp,
  Droplets,
  Thermometer,
  Cloud,
  Sprout,
  Activity,
  BarChart3
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine
} from 'recharts';
import { SensorReading, IrrigationEvent } from '../types/index.js';

interface AnalyticsPageProps {
  history: SensorReading[];
  irrigationEvents: IrrigationEvent[];
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({
  history,
  irrigationEvents
}) => {
  const [timeFilter, setTimeFilter] = useState<'24h' | '7d' | '30d' | '90d'>('7d');

  // Filter history based on range
  const now = new Date();
  const filteredHistory = history.filter((r) => {
    const readingTime = new Date(r.timestamp).getTime();
    if (timeFilter === '24h') return now.getTime() - readingTime <= 24 * 60 * 60 * 1000;
    if (timeFilter === '7d') return now.getTime() - readingTime <= 7 * 24 * 60 * 60 * 1000;
    if (timeFilter === '30d') return now.getTime() - readingTime <= 30 * 24 * 60 * 60 * 1000;
    return true; // 90d / all
  });

  const chartData = filteredHistory.map((r) => {
    const d = new Date(r.timestamp);
    // Estimated soil health score from moisture & temp
    const moistureScore = Math.max(10, 100 - Math.abs(r.moisture - 45) * 2.2);
    const tempScore = Math.max(20, 100 - Math.abs(r.soilTemperature - 24) * 3);
    const healthScore = Math.min(98, Math.round(moistureScore * 0.6 + tempScore * 0.4));

    return {
      time: d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      moisture: r.moisture,
      temperature: r.soilTemperature,
      humidity: r.humidity,
      healthScore
    };
  });

  // Calculate estimated water usage: ~6 Liters per minute for 14.5m² drip line
  const totalWaterLiters = irrigationEvents.reduce((acc, ev) => acc + (ev.duration / 60) * 6.2, 0);

  // CSV export
  const handleExportCSV = () => {
    const headers = ['Timestamp', 'Moisture(%)', 'SoilTemp(C)', 'Humidity(%)', 'EstimatedScore', 'Source'];
    const rows = filteredHistory.map((r) => [
      r.timestamp,
      r.moisture,
      r.soilTemperature,
      r.humidity,
      Math.min(98, Math.round(100 - Math.abs(r.moisture - 45) * 1.5)),
      r.source
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `soilsense_analytics_${timeFilter}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Garden Analytics & Trends</h2>
          <p className="text-xs text-slate-500">
            Multi-week environmental trends, health scores, and water conservation metrics.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
            {(['24h', '7d', '30d', '90d'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setTimeFilter(filter)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer uppercase ${
                  timeFilter === filter
                    ? 'bg-white text-[#0B6B43] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Summary Stat Highlights */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Avg Soil Moisture</span>
          <p className="text-2xl font-black text-slate-900 mt-1">42.4%</p>
          <span className="text-[10px] text-emerald-600 font-semibold">Optimal Range</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Avg Soil Temp</span>
          <p className="text-2xl font-black text-slate-900 mt-1">26.8°C</p>
          <span className="text-[10px] text-slate-500">DS18B20 Root Depth</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Irrigation Cycles</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{irrigationEvents.length}</p>
          <span className="text-[10px] text-slate-500">Automated & Manual</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[10px] uppercase font-bold text-slate-400">Est. Water Used</span>
          <p className="text-2xl font-black text-blue-700 mt-1">{Math.round(totalWaterLiters)} L</p>
          <span className="text-[10px] text-emerald-600 font-semibold">Drip Conservation</span>
        </div>
      </div>

      {/* Chart 1: Soil Moisture & Soil Health Score */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Soil Moisture & Composite Health Score</h3>
            <p className="text-xs text-slate-400">Dual telemetry correlation</p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 font-semibold text-[#0B6B43]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#0B6B43]" />
              Moisture %
            </span>
            <span className="flex items-center gap-1.5 font-semibold text-purple-700">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
              Health Score / 100
            </span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="moistGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0B6B43" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#0B6B43" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7652B8" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#7652B8" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} />
              <Tooltip />
              <Area type="monotone" dataKey="moisture" stroke="#0B6B43" strokeWidth={2} fill="url(#moistGrad)" isAnimationActive={false} />
              <Area type="monotone" dataKey="healthScore" stroke="#7652B8" strokeWidth={2} fill="url(#scoreGrad)" isAnimationActive={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 2: Root Temperature vs Ambient Humidity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900">Root Temperature (°C)</h4>
            <span className="text-[10px] text-slate-400 font-mono">DS18B20</span>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} />
                <YAxis domain={[15, 40]} tick={{ fontSize: 9, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} unit="°C" />
                <Tooltip />
                <Area type="monotone" dataKey="temperature" stroke="#E88922" fill="#FDF3E7" strokeWidth={2} isAnimationActive={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900">Ambient Humidity (%)</h4>
            <span className="text-[10px] text-slate-400 font-mono">DHT22</span>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} />
                <YAxis domain={[20, 100]} tick={{ fontSize: 9, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} unit="%" />
                <Tooltip />
                <Area type="monotone" dataKey="humidity" stroke="#1769AA" fill="#EBF3FA" strokeWidth={2} isAnimationActive={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
