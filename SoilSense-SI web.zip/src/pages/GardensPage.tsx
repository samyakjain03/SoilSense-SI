import React, { useState } from 'react';
import {
  Layers,
  Sprout,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Droplets,
  Thermometer,
  Cpu,
  ChevronRight,
  ArrowLeft
} from 'lucide-react';
import { Garden, GardenBed } from '../types/index.js';

interface GardensPageProps {
  gardens: Garden[];
  beds: GardenBed[];
  selectedGarden: Garden | null;
  onSelectGarden: (g: Garden) => void;
  selectedBed: GardenBed | null;
  onSelectBed: (b: GardenBed) => void;
  onNavigateToDashboard: () => void;
}

export const GardensPage: React.FC<GardensPageProps> = ({
  gardens,
  beds,
  selectedGarden,
  onSelectGarden,
  selectedBed,
  onSelectBed,
  onNavigateToDashboard
}) => {
  const [activeGarden, setActiveGarden] = useState<Garden>(selectedGarden || gardens[0]);
  const [activeBedDetail, setActiveBedDetail] = useState<GardenBed | null>(null);

  const gardenBeds = beds.filter((b) => b.gardenId === activeGarden.id);

  const getStatusBadge = (status: GardenBed['status']) => {
    switch (status) {
      case 'HEALTHY':
        return {
          label: 'Healthy',
          color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
          dot: 'bg-emerald-500'
        };
      case 'ATTENTION':
        return {
          label: 'Needs Attention',
          color: 'text-amber-700 bg-amber-50 border-amber-200',
          dot: 'bg-amber-500'
        };
      case 'CRITICAL':
      default:
        return {
          label: 'Critical Low',
          color: 'text-rose-700 bg-rose-50 border-rose-200',
          dot: 'bg-rose-500'
        };
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Community Garden Plots</h2>
          <p className="text-xs text-slate-500">
            Monitor plot beds, crop varieties, and soil status across municipal community gardens.
          </p>
        </div>

        {activeBedDetail && (
          <button
            onClick={() => setActiveBedDetail(null)}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 bg-white cursor-pointer self-start sm:self-auto"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Bed List</span>
          </button>
        )}
      </div>

      {/* Garden Overview Cards */}
      {!activeBedDetail && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gardens.map((g) => {
            const isSelected = activeGarden.id === g.id;
            return (
              <div
                key={g.id}
                onClick={() => {
                  setActiveGarden(g);
                  onSelectGarden(g);
                }}
                className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-white border-[#0B6B43] shadow-md ring-2 ring-[#0B6B43]/10'
                    : 'bg-white border-slate-200/90 shadow-xs hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Community Garden
                    </span>
                    {isSelected && (
                      <span className="text-[11px] font-bold text-[#0B6B43] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        Active Station
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg font-bold text-slate-900">{g.name}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{g.location}</p>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-4 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-slate-50">
                    <span className="text-[10px] text-slate-400 font-semibold uppercase block">Beds</span>
                    <span className="text-sm font-black text-slate-800">{g.totalBeds}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-emerald-50/60 text-emerald-800">
                    <span className="text-[10px] font-semibold uppercase block">Healthy</span>
                    <span className="text-sm font-black">{g.healthyCount}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-amber-50/60 text-amber-800">
                    <span className="text-[10px] font-semibold uppercase block">Attention</span>
                    <span className="text-sm font-black">{g.attentionCount}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-rose-50/60 text-rose-800">
                    <span className="text-[10px] font-semibold uppercase block">Critical</span>
                    <span className="text-sm font-black">{g.criticalCount}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Bed Detail Drill-down */}
      {activeBedDetail ? (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-slate-400 uppercase">{activeGarden.name}</span>
                <span className="text-slate-300">·</span>
                <span className="text-xs font-bold text-[#0B6B43]">{activeBedDetail.name}</span>
              </div>
              <h3 className="text-xl font-black text-slate-900">{activeBedDetail.name}</h3>
              <p className="text-xs text-slate-600 mt-1">{activeBedDetail.cropType}</p>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${getStatusBadge(activeBedDetail.status).color}`}>
                {getStatusBadge(activeBedDetail.status).label}
              </span>
              <button
                onClick={() => {
                  onSelectBed(activeBedDetail);
                  onNavigateToDashboard();
                }}
                className="px-3 py-1.5 rounded-lg bg-[#0B6B43] text-white text-xs font-bold shadow-xs hover:bg-[#095736] transition-colors cursor-pointer"
              >
                Set as Primary Dashboard Bed &rarr;
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400">Current Moisture</span>
              <p className="text-xl font-black text-slate-900 mt-1">{activeBedDetail.currentMoisture}%</p>
              <span className="text-[10px] text-slate-500">Capacitive probe</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400">Soil Temperature</span>
              <p className="text-xl font-black text-slate-900 mt-1">{activeBedDetail.currentTemp}°C</p>
              <span className="text-[10px] text-slate-500">DS18B20 probe</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400">Bed Area</span>
              <p className="text-xl font-black text-slate-900 mt-1">{activeBedDetail.area}</p>
              <span className="text-[10px] text-slate-500">Raised bed</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400">Paired IoT Device</span>
              <p className="text-sm font-bold font-mono text-slate-900 mt-1.5">{activeBedDetail.deviceId}</p>
              <span className="text-[10px] text-emerald-600 font-semibold">Online</span>
            </div>
          </div>

          {activeBedDetail.notes && (
            <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100 text-xs text-slate-700">
              <span className="font-bold text-slate-900">Bed Notes: </span>
              {activeBedDetail.notes}
            </div>
          )}
        </div>
      ) : (
        /* Bed Grid */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Garden Beds in {activeGarden.name} ({gardenBeds.length})
            </h3>
            <span className="text-xs text-slate-500">Click any bed to view details</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {gardenBeds.map((bed) => {
              const badge = getStatusBadge(bed.status);
              const isSelected = selectedBed?.id === bed.id;
              return (
                <div
                  key={bed.id}
                  onClick={() => setActiveBedDetail(bed)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-emerald-50/40 border-emerald-400 shadow-xs'
                      : 'bg-white border-slate-200/90 shadow-xs hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-bold text-slate-900">{bed.name}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${badge.color}`}>
                        {badge.label}
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 line-clamp-1">{bed.cropType}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                    <span className="font-semibold">{bed.currentMoisture}% Moisture</span>
                    <span className="text-slate-400">{bed.currentTemp}°C</span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
