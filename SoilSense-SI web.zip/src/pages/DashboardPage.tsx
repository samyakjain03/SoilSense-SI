import React, { useState } from 'react';
import {
  Sprout,
  Droplets,
  Thermometer,
  CheckCircle2,
  AlertTriangle,
  Play,
  ArrowRight,
  Cpu,
  Camera,
  Activity,
  Layers,
  Clock,
  ExternalLink
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine
} from 'recharts';
import {
  SensorReading,
  SoilHealthReport,
  IrrigationRecommendation,
  IrrigationState,
  AlertItem,
  DeviceInfo,
  UserProfile,
  Garden,
  GardenBed
} from '../types/index.js';

interface DashboardPageProps {
  currentUser: UserProfile;
  selectedGarden: Garden | null;
  selectedBed: GardenBed | null;
  latestReading: SensorReading;
  soilHealthReport: SoilHealthReport;
  irrigationRecommendation: IrrigationRecommendation;
  irrigationState: IrrigationState;
  history: SensorReading[];
  alerts: AlertItem[];
  devices: DeviceInfo[];
  onTriggerIrrigate: () => void;
  onNavigate: (tab: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  currentUser,
  selectedGarden,
  selectedBed,
  latestReading,
  soilHealthReport,
  irrigationRecommendation,
  irrigationState,
  history,
  alerts,
  devices,
  onTriggerIrrigate,
  onNavigate
}) => {
  const [trendRange, setTrendRange] = useState<'24h' | '7d' | '30d'>('24h');

  // Filter history for trend chart
  const filteredHistory = history.slice(
    trendRange === '24h' ? -24 : trendRange === '7d' ? -35 : -40
  );

  const chartData = filteredHistory.map((r) => {
    const d = new Date(r.timestamp);
    return {
      time: d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      moisture: r.moisture,
      temperature: r.soilTemperature
    };
  });

  // Maximum 3 recent alerts
  const recentAlerts = alerts.slice(0, 3);

  // Time-aware greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const isHealthy = soilHealthReport.status === 'HEALTHY';
  const isPumping = irrigationState.isActive;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* 1. Header: Greeting, Garden, Bed */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200/80">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            {getGreeting()}, {currentUser.name.split(' ')[0]}
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 font-medium">
            <span className="text-[#0B6B43] font-semibold">{selectedGarden?.name || 'JECRC Community Garden'}</span>
            <span>·</span>
            <span className="text-slate-700 font-semibold">{selectedBed?.name || 'Tomato Bed'}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('gardens')}
            className="text-xs font-semibold text-slate-600 hover:text-[#0B6B43] px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Switch Bed / Garden
          </button>
        </div>
      </div>

      {/* 2. First Row: Key Metrics (3 Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: SOIL HEALTH */}
        <div 
          onClick={() => onNavigate('soil')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Soil Health</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#0B6B43] flex items-center justify-center">
              <Sprout className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 tracking-tight">
              {soilHealthReport.score} <span className="text-sm font-normal text-slate-400">/ 100</span>
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-bold text-[#0B6B43]">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>{soilHealthReport.status}</span>
            </div>
          </div>
        </div>

        {/* Metric 2: MOISTURE */}
        <div 
          onClick={() => onNavigate('sensors')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Moisture</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Droplets className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 tracking-tight">
              {latestReading.moisture.toFixed(0)}%
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-bold text-blue-700">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              <span>{soilHealthReport.moistureStatus.replace('_', ' ')}</span>
            </div>
          </div>
        </div>

        {/* Metric 3: TEMPERATURE */}
        <div 
          onClick={() => onNavigate('sensors')}
          className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Temperature</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Thermometer className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-black text-slate-900 tracking-tight">
              {latestReading.soilTemperature.toFixed(1)}°C
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs font-semibold text-slate-600">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>DS18B20 Root Probe</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Main Recommendation Block */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Main Recommendation</span>
            <span className="text-xs text-slate-300">·</span>
            <span className="text-xs font-semibold text-[#0B6B43]">Grounded Action</span>
          </div>

          <p className="text-base font-bold text-slate-900">
            {soilHealthReport.status === 'HEALTHY'
              ? 'Your soil is currently in good condition.'
              : soilHealthReport.status === 'DRY'
              ? 'Soil moisture is low. Irrigation is recommended.'
              : soilHealthReport.status === 'WATERLOGGED'
              ? 'Soil is saturated. Irrigation locked out.'
              : 'Soil is under thermal stress. Monitor moisture closely.'}
          </p>

          <p className="text-xs text-slate-600 leading-relaxed">
            {irrigationRecommendation.reason}
          </p>
        </div>

        <div className="flex flex-col sm:items-end gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">Action:</span>
            <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
              irrigationRecommendation.action === 'IRRIGATE_NOW'
                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                : 'bg-emerald-50 text-[#0B6B43] border border-emerald-200'
            }`}>
              {irrigationRecommendation.action === 'IRRIGATE_NOW' ? 'Water recommended' : 'No irrigation required'}
            </span>
          </div>

          {irrigationRecommendation.action === 'IRRIGATE_NOW' && !isPumping && (
            <button
              onClick={onTriggerIrrigate}
              className="mt-2 flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start Irrigation ({irrigationRecommendation.duration} min)</span>
            </button>
          )}

          {isPumping && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-800 border border-blue-200 text-xs font-bold animate-pulse">
              <span className="w-2 h-2 rounded-full bg-blue-600" />
              <span>Pumping ({Math.floor(irrigationState.remainingSeconds / 60)}m {irrigationState.remainingSeconds % 60}s)</span>
            </div>
          )}
        </div>
      </div>

      {/* 4. Optical Crop Health Scanner Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-[#0B6B43] to-emerald-900 rounded-2xl p-5 text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-white/15 backdrop-blur-md flex items-center justify-center shrink-0 border border-white/20">
            <Camera className="w-6 h-6 text-emerald-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-white/20 text-emerald-100">
                ESP32-CAM & Mobile Camera
              </span>
              <span className="text-xs text-emerald-200/80">Visual Diagnostics</span>
            </div>
            <h3 className="text-base font-bold text-white mt-0.5">
              Scan Leaf Health & Nutrient Deficiency
            </h3>
            <p className="text-xs text-emerald-100/90 leading-relaxed mt-0.5 max-w-xl">
              Capture or upload crop leaves to detect nitrogen/potassium deficiencies and correlate optical symptoms with ground capacitive moisture telemetry.
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('scan')}
          className="px-4 py-2.5 rounded-xl bg-white text-emerald-950 font-bold text-xs hover:bg-emerald-50 transition-all cursor-pointer flex items-center gap-2 shrink-0 shadow-md self-start sm:self-auto"
        >
          <Camera className="w-4 h-4 text-[#0B6B43]" />
          <span>Open Scanner Camera</span>
          <ArrowRight className="w-3.5 h-3.5 text-emerald-800" />
        </button>
      </div>

      {/* 5. Soil Trend (Single Clean Chart) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">Soil Moisture Trend</h3>
            <p className="text-xs text-slate-500">Capacitive telemetry over time</p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            {(['24h', '7d', '30d'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTrendRange(range)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  trendRange === range
                    ? 'bg-white text-[#0B6B43] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {range.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        <div className="h-60 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="moistureGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0B6B43" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#0B6B43" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748B' }} stroke="#CBD5E1" tickLine={false} unit="%" />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-xl text-xs shadow-md">
                        <div className="text-[10px] text-slate-400">{payload[0].payload.time}</div>
                        <div className="font-bold text-white text-sm mt-0.5">
                          {payload[0].value}% Moisture
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine y={30} stroke="#E88922" strokeDasharray="3 3" label={{ value: 'Dry (30%)', fill: '#E88922', fontSize: 10, position: 'insideBottomRight' }} />
              <ReferenceLine y={75} stroke="#94A3B8" strokeDasharray="3 3" label={{ value: 'Upper (75%)', fill: '#94A3B8', fontSize: 10, position: 'insideTopRight' }} />
              <Area type="monotone" dataKey="moisture" stroke="#0B6B43" strokeWidth={2.5} fillOpacity={1} fill="url(#moistureGradient)" isAnimationActive={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 5. Bottom Twin Cards: Recent Alerts & Device Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Alerts (Maximum 3) */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Recent Alerts</h3>
              <button
                onClick={() => onNavigate('alerts')}
                className="text-xs font-semibold text-[#0B6B43] hover:underline cursor-pointer"
              >
                View all &rarr;
              </button>
            </div>

            <div className="space-y-2.5">
              {recentAlerts.length > 0 ? (
                recentAlerts.map((a) => (
                  <div key={a.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-start gap-2.5">
                    <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                      a.severity === 'critical' ? 'bg-rose-500' : a.severity === 'warning' ? 'bg-amber-500' : 'bg-emerald-500'
                    }`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-slate-900 truncate">{a.title}</p>
                      <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">{a.message}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-6 text-center text-xs text-slate-400">
                  No active alerts.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Device Status */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Device Status</h3>
              <button
                onClick={() => onNavigate('devices')}
                className="text-xs font-semibold text-[#0B6B43] hover:underline cursor-pointer"
              >
                Hardware details &rarr;
              </button>
            </div>

            <div className="space-y-2.5">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Cpu className="w-4 h-4 text-emerald-700" />
                  <div>
                    <p className="text-xs font-bold text-slate-900">ESP32 Node 01</p>
                    <p className="text-[10px] text-slate-400">Sensory telemetry probe</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Online
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Camera className="w-4 h-4 text-emerald-700" />
                  <div>
                    <p className="text-xs font-bold text-slate-900">ESP32-CAM</p>
                    <p className="text-[10px] text-slate-400">Optical canopy lens</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  Online
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Activity className="w-4 h-4 text-blue-700" />
                  <div>
                    <p className="text-xs font-bold text-slate-900">Relay Controller</p>
                    <p className="text-[10px] text-slate-400">12V Solenoid & Pump</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-blue-700 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  Ready
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
