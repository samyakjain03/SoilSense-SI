import React, { useState } from 'react';
import { Sprout, ArrowRight, Lock, Mail, AlertCircle } from 'lucide-react';
import { api } from '../services/api.js';
import { UserProfile } from '../types/index.js';

interface LoginPageProps {
  onSuccess: (user: UserProfile) => void;
  onNavigate: (route: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccess, onNavigate }) => {
  const [email, setEmail] = useState('elena@soilsense.garden');
  const [password, setPassword] = useState('password123');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.login(email, password);
      onSuccess(res.user);
    } catch (err: any) {
      setError(err.message || 'Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7FAF8] flex flex-col justify-center">
      <div className="max-w-4xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[580px]">
          
          {/* Left Hero Branding (Desktop) */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#0B6B43] to-[#084D30] p-8 sm:p-10 text-white flex flex-col justify-between relative overflow-hidden">
            {/* Subtle organic background decoration */}
            <div className="absolute -bottom-12 -right-12 w-48 h-48 rounded-full bg-emerald-400/10 blur-2xl pointer-events-none" />
            <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-emerald-200/10 blur-2xl pointer-events-none" />

            <div>
              <div 
                className="flex items-center gap-2.5 cursor-pointer mb-8"
                onClick={() => onNavigate('/')}
              >
                <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center text-emerald-100 border border-white/20">
                  <Sprout className="w-5 h-5" />
                </div>
                <div>
                  <span className="font-extrabold text-xl tracking-tight">SoilSense</span>
                  <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-emerald-400/20 text-emerald-200 ml-1.5 border border-emerald-300/30">
                    AI
                  </span>
                </div>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black tracking-tight leading-snug">
                Smart Soil Today.<br />
                Greener Tomorrow.
              </h2>
              <p className="text-emerald-100/80 text-xs sm:text-sm mt-3 leading-relaxed">
                Your garden's soil intelligence, in one place.
              </p>
            </div>

            {/* Urban Garden Visual Preview */}
            <div className="my-6 p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-2">
              <div className="text-[10px] uppercase font-bold tracking-wider text-emerald-200">
                JECRC Community Garden
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-white/80">Tomato Bed Moisture</span>
                <span className="font-bold text-white">41% (Optimal)</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-white/80">Irrigation Actuator</span>
                <span className="font-bold text-emerald-300">Standby</span>
              </div>
            </div>

            <div className="text-[11px] text-emerald-100/60 flex items-center justify-between">
              <span>Multisensor Soil Monitoring</span>
              <button 
                onClick={() => onNavigate('/')}
                className="text-white font-semibold hover:underline cursor-pointer"
              >
                ← Back to Home
              </button>
            </div>
          </div>

          {/* Right Login Form */}
          <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-center">
            <div className="max-w-md w-full mx-auto space-y-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Welcome Back</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Sign in to monitor your community garden plots and soil conditions.
                </p>
              </div>

              {error && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@communitygarden.org"
                      className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 text-slate-900 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43] bg-slate-50/50"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-semibold text-slate-700">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => onNavigate('/forgot-password')}
                      className="text-xs font-semibold text-[#0B6B43] hover:underline cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border border-slate-200 text-slate-900 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43] bg-slate-50/50"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] shadow-md shadow-emerald-900/15 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>{loading ? 'Signing in...' : 'Sign In'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>

              {/* Demo Credentials Helper */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 text-[11px] text-slate-600 flex items-center justify-between">
                <span>Demo Account: <strong className="text-slate-800">elena@soilsense.garden</strong></span>
                <span className="text-slate-400">Pass: password123</span>
              </div>

              <div className="pt-2 text-center text-xs text-slate-500">
                Don't have an account yet?{' '}
                <button
                  type="button"
                  onClick={() => onNavigate('/register')}
                  className="font-bold text-[#0B6B43] hover:underline cursor-pointer ml-1"
                >
                  Create Account
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
