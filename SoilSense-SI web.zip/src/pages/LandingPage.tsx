import React from 'react';
import {
  Sprout,
  ArrowRight,
  Droplets,
  Thermometer,
  Cloud,
  Sun,
  CloudRain,
  Activity,
  Layers,
  Cpu,
  Bell,
  TrendingUp,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (route: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-[#F7FAF8] text-slate-800 antialiased">
      {/* Top Navigation */}
      <header className="border-b border-slate-200/80 bg-white/95 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onNavigate('/')}>
            <div className="w-9 h-9 rounded-xl bg-[#0B6B43] flex items-center justify-center text-white shadow-xs">
              <Sprout className="w-5 h-5 text-emerald-100" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900 text-lg tracking-tight">SoilSense</span>
              <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-emerald-50 text-[#0B6B43] border border-emerald-200/60 ml-1.5">
                SI
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('/login')}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => onNavigate('/register')}
              className="px-4 py-2 text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* SECTION 1: Hero */}
      <section className="px-6 py-12 sm:py-20 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-[#0B6B43] border border-emerald-200/70 text-xs font-semibold">
              <Sprout className="w-3.5 h-3.5" />
              <span>SOILSENSE AI</span>
            </div>

            <h1 className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]">
              Smart Soil Today.<br />
              <span className="text-[#0B6B43]">Greener Tomorrow.</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
              Multisensor soil intelligence for smarter irrigation and healthier urban gardens. Monitor soil conditions, understand what is happening, and take action at the right time.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('/register')}
                className="px-6 py-3 text-sm font-bold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-xl shadow-md shadow-emerald-900/15 transition-all cursor-pointer flex items-center gap-2"
              >
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onNavigate('/login')}
                className="px-6 py-3 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-all cursor-pointer"
              >
                Sign In
              </button>
            </div>

            <div className="flex items-center gap-6 pt-4 text-xs text-slate-500 font-medium">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Capacitive & Thermal Ground-Truth</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Autonomous Drip Valves</span>
              </div>
            </div>
          </div>

          {/* Right Column: Realistic Urban Community Garden with Overlays */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden border border-slate-200/90 shadow-xl bg-white">
              {/* Realistic Urban Garden Photography */}
              <div className="relative h-80 sm:h-96 w-full overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=800&auto=format&fit=crop&q=80"
                  alt="Raised community garden bed with lush tomato plants, dark loam soil, and irrigation tubing"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-slate-900/10 to-transparent" />
              </div>

              {/* Overlay Information Cards */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <div className="px-3 py-1.5 rounded-xl bg-white/95 backdrop-blur-md shadow-md border border-slate-200/80 text-xs font-bold text-slate-900 flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span>JECRC Community Garden · Tomato Bed</span>
                </div>
              </div>

              <div className="absolute bottom-4 left-4 right-4 grid grid-cols-3 gap-2">
                <div className="p-2.5 rounded-xl bg-white/95 backdrop-blur-md shadow-md border border-slate-200/80 text-center">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Soil Health</span>
                  <span className="text-base font-extrabold text-[#0B6B43]">82/100</span>
                </div>

                <div className="p-2.5 rounded-xl bg-white/95 backdrop-blur-md shadow-md border border-slate-200/80 text-center">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Moisture</span>
                  <span className="text-base font-extrabold text-blue-600">41%</span>
                </div>

                <div className="p-2.5 rounded-xl bg-white/95 backdrop-blur-md shadow-md border border-slate-200/80 text-center">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Irrigation</span>
                  <span className="text-xs font-bold text-slate-800 leading-tight block mt-0.5">Not Required</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: The Problem */}
      <section className="px-6 py-16 bg-white border-y border-slate-200/80">
        <div className="max-w-6xl mx-auto space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#0B6B43]">The Problem</span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Urban gardens still depend too much on guesswork.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-sm">
                01
              </div>
              <h3 className="text-base font-bold text-slate-900">OVERWATERING</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Water is used even when soil does not need it, causing root hypoxia and nutrient leaching in raised beds.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                02
              </div>
              <h3 className="text-base font-bold text-slate-900">UNDERWATERING</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Dry soil can go unnoticed until plants show visible stress and vegetative stunting during summer heat.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-sm">
                03
              </div>
              <h3 className="text-base font-bold text-slate-900">NO REAL-TIME INSIGHT</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Garden managers often lack continuous soil information between volunteer visits, resulting in erratic watering.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: How SoilSense Works */}
      <section className="px-6 py-16 max-w-6xl mx-auto space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#0B6B43]">Architecture</span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            From Soil Data to Action
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            A reliable pipeline converting environmental probe data into autonomous actions.
          </p>
        </div>

        {/* 4-Stage Horizontal/Vertical Flow */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          {/* Step 1: Sense */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-3">
                <Droplets className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Stage 01</span>
              <h3 className="text-base font-bold text-slate-900 mt-1">SENSE</h3>
              <ul className="text-xs text-slate-600 space-y-1.5 mt-3">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  <span>Moisture (Capacitive)</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>Temperature (DS18B20)</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
                  <span>Humidity & Light</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                  <span>Rain Sensor</span>
                </li>
              </ul>
            </div>
            <div className="text-[10px] text-slate-400 font-mono pt-3 border-t border-slate-100">
              ESP32 Node 01 Probe Layer
            </div>
          </div>

          {/* Step 2: Analyse */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#0B6B43] flex items-center justify-center mb-3">
                <Layers className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Stage 02</span>
              <h3 className="text-base font-bold text-slate-900 mt-1">ANALYSE</h3>
              <ul className="text-xs text-slate-600 space-y-1.5 mt-3">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0B6B43]" />
                  <span>Multisensor data fusion</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0B6B43]" />
                  <span>Soil health analysis</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0B6B43]" />
                  <span>Biological condition score</span>
                </li>
              </ul>
            </div>
            <div className="text-[10px] text-slate-400 font-mono pt-3 border-t border-slate-100">
              Soil Health Engine
            </div>
          </div>

          {/* Step 3: Decide */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center mb-3">
                <Activity className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Stage 03</span>
              <h3 className="text-base font-bold text-slate-900 mt-1">DECIDE</h3>
              <ul className="text-xs text-slate-600 space-y-1.5 mt-3">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                  <span>Irrigation recommendation</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                  <span>Thermal & drought risk</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                  <span>Precipitation hold rules</span>
                </li>
              </ul>
            </div>
            <div className="text-[10px] text-slate-400 font-mono pt-3 border-t border-slate-100">
              Irrigation Decision Engine
            </div>
          </div>

          {/* Step 4: Act */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-3">
                <Cpu className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Stage 04</span>
              <h3 className="text-base font-bold text-slate-900 mt-1">ACT</h3>
              <ul className="text-xs text-slate-600 space-y-1.5 mt-3">
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>Alert notifications</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>Submersible pump control</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  <span>12V Solenoid valve actuation</span>
                </li>
              </ul>
            </div>
            <div className="text-[10px] text-slate-400 font-mono pt-3 border-t border-slate-100">
              Relay Actuation Layer
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: Core Capabilities */}
      <section className="px-6 py-16 bg-white border-y border-slate-200/80">
        <div className="max-w-6xl mx-auto space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#0B6B43]">Features</span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Core Capabilities
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Soil Health Monitoring</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Understand whether soil is dry, optimal, wet or waterlogged with transparent calibration thresholds.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Smart Irrigation</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Get irrigation recommendations and control connected pumps and solenoid valves with automated timers.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Multisensor Intelligence</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Combine moisture, temperature, humidity, light and rainfall data for grounded agronomic decisions.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Edge-First Processing</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Support local processing and reduced cloud dependency so watering continues even during internet dropouts.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Alerts & Insights</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Know when soil or devices need attention with instant notifications on dry soil or heat stress.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
              <h3 className="text-sm font-bold text-slate-900">Garden Analytics</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Track soil health and irrigation trends over time with clean Recharts timelines and CSV exports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 5: Simple Workflow */}
      <section className="px-6 py-16 max-w-6xl mx-auto space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#0B6B43]">Workflow</span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            How Community Plots Run with SoilSense
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200 text-center space-y-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-[#0B6B43] flex items-center justify-center font-bold text-xs mx-auto">
              1
            </div>
            <h4 className="text-xs font-bold text-slate-900">Probes in Soil</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Place capacitive probe and DS18B20 probe 15cm deep into the crop root zone.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 text-center space-y-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-[#0B6B43] flex items-center justify-center font-bold text-xs mx-auto">
              2
            </div>
            <h4 className="text-xs font-bold text-slate-900">ESP32 Sampling</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Node samples data periodically with outlier filtering and edge evaluation.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 text-center space-y-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-[#0B6B43] flex items-center justify-center font-bold text-xs mx-auto">
              3
            </div>
            <h4 className="text-xs font-bold text-slate-900">Decision Engine</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              System determines if irrigation is required, checking rain lockout rules.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200 text-center space-y-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-[#0B6B43] flex items-center justify-center font-bold text-xs mx-auto">
              4
            </div>
            <h4 className="text-xs font-bold text-slate-900">Controlled Drip</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Relay opens solenoid valve for exact duration needed to recharge soil.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 6: Final CTA */}
      <section className="px-6 py-16 bg-gradient-to-br from-[#0B6B43] to-[#084D30] text-white text-center">
        <div className="max-w-2xl mx-auto space-y-6">
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight leading-snug">
            Know your soil.<br />
            Water smarter.<br />
            Grow greener.
          </h2>
          <p className="text-emerald-100/90 text-sm max-w-md mx-auto">
            Ready to optimize your community garden with multisensor soil telemetry?
          </p>
          <div className="pt-2">
            <button
              onClick={() => onNavigate('/login')}
              className="px-8 py-3.5 text-sm font-bold text-[#0B6B43] bg-white hover:bg-emerald-50 rounded-xl shadow-lg transition-all cursor-pointer inline-flex items-center gap-2"
            >
              <span>Open SoilSense</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Clean Footer */}
      <footer className="border-t border-slate-200 py-8 px-6 text-center text-xs text-slate-400 bg-white">
        <p className="font-semibold text-slate-600">SoilSense AI · Smart Soil Today. Greener Tomorrow.</p>
        <p className="mt-1">Multisensor Soil Health Monitoring & Action System for Urban Community Gardens.</p>
      </footer>
    </div>
  );
};
