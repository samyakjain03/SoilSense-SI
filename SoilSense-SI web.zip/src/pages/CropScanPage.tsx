import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Leaf,
  ShieldCheck,
  Video,
  X,
  Info,
  Droplets,
  Thermometer,
  RotateCcw,
  Check,
  Zap,
  HelpCircle
} from 'lucide-react';
import { api } from '../services/api.js';
import { CropScanResult, SensorReading } from '../types/index.js';

interface CropScanPageProps {
  latestReading: SensorReading;
}

interface SampleLeaf {
  id: string;
  name: string;
  crop: string;
  tag: string;
  description: string;
  url: string;
  type: string;
}

const SAMPLE_LEAVES: SampleLeaf[] = [
  {
    id: 'sample-healthy',
    name: 'Healthy Tomato Canopy',
    crop: 'Tomato',
    tag: 'Optimal Chlorophyll',
    description: 'Deep green foliage with upright petioles and normal vegetative turgor.',
    url: 'https://images.unsplash.com/photo-1592841200221-a6898f307baa?w=600&auto=format&fit=crop&q=80',
    type: 'healthy'
  },
  {
    id: 'sample-nitrogen',
    name: 'Nitrogen (N) Deficiency',
    crop: 'Tomato',
    tag: 'Basal Chlorosis',
    description: 'Yellowing of older lower leaves; veins pale while upper leaves stay smaller.',
    url: 'https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?w=600&auto=format&fit=crop&q=80',
    type: 'nitrogen'
  },
  {
    id: 'sample-potassium',
    name: 'Potassium (K) Stress',
    crop: 'Chilli',
    tag: 'Marginal Scorch',
    description: 'Browning along outer leaf margins and necrotic tip burn.',
    url: 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?w=600&auto=format&fit=crop&q=80',
    type: 'potassium'
  },
  {
    id: 'sample-drought',
    name: 'Moisture Deficit Wilt',
    crop: 'Tomato',
    tag: 'Cellular Turgor Loss',
    description: 'Pronounced stem drooping and curling from acute root moisture depletion.',
    url: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=600&auto=format&fit=crop&q=80',
    type: 'drought'
  }
];

export const CropScanPage: React.FC<CropScanPageProps> = ({ latestReading }) => {
  const [selectedCrop, setSelectedCrop] = useState('Tomato');
  const [selectedSampleId, setSelectedSampleId] = useState<string>('sample-healthy');
  const [imagePreview, setImagePreview] = useState<string | null>(SAMPLE_LEAVES[0].url);
  const [activeSampleType, setActiveSampleType] = useState<string>('healthy');
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [analyzing, setAnalyzing] = useState(false);
  const [scanResult, setScanResult] = useState<CropScanResult | null>(null);
  const [loggedToNotes, setLoggedToNotes] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop camera on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Start live camera stream
  const startCamera = async (mode: 'environment' | 'user' = facingMode) => {
    try {
      stopCamera();
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn('Camera access unavailable:', err);
      setIsCameraActive(false);
      alert('Camera access is not permitted or unavailable in this environment. You can select a sample photo or upload an image.');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const toggleFacingMode = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    startCamera(nextMode);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
      setSelectedSampleId('');
      setActiveSampleType('custom');
      stopCamera();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
        setSelectedSampleId('');
        setActiveSampleType('custom');
      };
      reader.readAsDataURL(file);
    }
  };

  const selectSample = (sample: SampleLeaf) => {
    stopCamera();
    setSelectedSampleId(sample.id);
    setImagePreview(sample.url);
    setSelectedCrop(sample.crop);
    setActiveSampleType(sample.type);
    setScanResult(null);
    setLoggedToNotes(false);
  };

  const runAnalysis = async () => {
    if (!imagePreview) return;
    setAnalyzing(true);
    setLoggedToNotes(false);
    try {
      const res = await api.scanCrop(imagePreview, selectedCrop, activeSampleType);
      setScanResult(res);
    } catch (err) {
      console.error('Scan error:', err);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#0B6B43] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200/70">
              ESP32-CAM · Optical Sensor Layer
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Visual Crop & Soil Health Scanner
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Capture leaves or bed canopies with camera to identify nutrient deficiencies and correlate with ground moisture sensors.
          </p>
        </div>

        {/* Live Ground Probe Telemetry Snapshot */}
        <div className="flex items-center gap-2.5 p-2 rounded-xl bg-white border border-slate-200/80 shadow-xs self-start sm:self-auto">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-blue-50 text-blue-800 text-xs font-bold">
            <Droplets className="w-3.5 h-3.5 text-blue-600" />
            <span>{latestReading.moisture.toFixed(0)}% Moisture</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-amber-50 text-amber-800 text-xs font-bold">
            <Thermometer className="w-3.5 h-3.5 text-amber-600" />
            <span>{latestReading.soilTemperature.toFixed(1)}°C Soil</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Camera Viewport / Sample Selection */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-[#0B6B43]" />
                <h2 className="text-sm font-bold text-slate-900">Crop Viewfinder</h2>
              </div>

              {/* Crop Selector */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-semibold text-slate-500">Crop:</span>
                <select
                  value={selectedCrop}
                  onChange={(e) => setSelectedCrop(e.target.value)}
                  className="text-xs font-bold px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#0B6B43]"
                >
                  <option value="Tomato">Tomato (Solanum lycopersicum)</option>
                  <option value="Chilli">Chilli / Pepper (Capsicum)</option>
                  <option value="Herbs">Culinary Herbs (Basil / Mint)</option>
                  <option value="Vegetable">Leafy Brassica (Kale / Spinach)</option>
                </select>
              </div>
            </div>

            {/* Camera Viewport or Image Preview */}
            <div className="relative aspect-4/3 rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 flex items-center justify-center">
              {isCameraActive ? (
                <div className="w-full h-full relative">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover"
                    autoPlay
                    playsInline
                    muted
                  />
                  
                  {/* Viewfinder Reticle Overlay */}
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                    <div className="w-48 h-48 border-2 border-white/40 border-dashed rounded-2xl flex items-center justify-center">
                      <div className="w-4 h-4 border-t-2 border-l-2 border-emerald-400 absolute top-2 left-2" />
                      <div className="w-4 h-4 border-t-2 border-r-2 border-emerald-400 absolute top-2 right-2" />
                      <div className="w-4 h-4 border-b-2 border-l-2 border-emerald-400 absolute bottom-2 left-2" />
                      <div className="w-4 h-4 border-b-2 border-r-2 border-emerald-400 absolute bottom-2 right-2" />
                      <span className="text-[10px] text-white/80 font-mono tracking-wider">FOCUS LEAF</span>
                    </div>
                  </div>

                  {/* Camera Control Overlays */}
                  <div className="absolute bottom-3 left-0 right-0 flex items-center justify-center gap-3 px-4">
                    <button
                      onClick={toggleFacingMode}
                      className="p-2.5 rounded-xl bg-black/60 backdrop-blur-md text-white hover:bg-black/80 transition-all cursor-pointer text-xs font-bold"
                      title="Flip Camera"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>

                    <button
                      onClick={capturePhoto}
                      className="px-5 py-2.5 rounded-xl bg-white text-slate-900 text-xs font-black shadow-xl hover:bg-slate-100 transition-all cursor-pointer flex items-center gap-2"
                    >
                      <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                      <span>Snap Frame</span>
                    </button>

                    <button
                      onClick={stopCamera}
                      className="p-2.5 rounded-xl bg-black/60 backdrop-blur-md text-white hover:bg-black/80 transition-all cursor-pointer"
                      title="Close Camera"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : imagePreview ? (
                <div className="w-full h-full relative group">
                  <img
                    src={imagePreview}
                    alt="Crop sample"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-2 left-2 right-2 p-2 rounded-xl bg-slate-950/70 backdrop-blur-md text-[11px] text-white flex items-center justify-between">
                    <span className="font-semibold truncate">
                      {selectedSampleId
                        ? SAMPLE_LEAVES.find((s) => s.id === selectedSampleId)?.name
                        : 'Custom Captured Frame'}
                    </span>
                    <span className="text-[10px] text-emerald-300 font-mono">Frame Ready</span>
                  </div>
                </div>
              ) : (
                <div className="text-center text-slate-400 p-6 space-y-2">
                  <Camera className="w-10 h-10 mx-auto text-slate-500" />
                  <p className="text-xs">Select a sample photo or open camera</p>
                </div>
              )}
            </div>

            {/* Input Options: Open Live Camera or Upload */}
            <div className="flex items-center gap-2 pt-1">
              {!isCameraActive ? (
                <button
                  onClick={() => startCamera('environment')}
                  className="flex-1 py-2.5 px-3 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Video className="w-3.5 h-3.5 text-[#0B6B43]" />
                  <span>Open Live Camera</span>
                </button>
              ) : (
                <button
                  onClick={stopCamera}
                  className="flex-1 py-2.5 px-3 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <X className="w-3.5 h-3.5 text-rose-600" />
                  <span>Close Camera</span>
                </button>
              )}

              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 py-2.5 px-3 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5 text-slate-600" />
                <span>Upload Leaf Photo</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            {/* Primary Action Button */}
            <button
              onClick={runAnalysis}
              disabled={analyzing || !imagePreview}
              className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-[#0B6B43] hover:bg-[#095736] shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {analyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Cross-Correlating Optical Scan & Telemetry...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-emerald-200" />
                  <span>Diagnose {selectedCrop} Health with Vision AI</span>
                </>
              )}
            </button>
          </div>

          {/* Sample Preset Leaf Cards for Quick Evaluation */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">Quick Test Samples:</span>
              <span className="text-[10px] text-slate-400">Click to load photo</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {SAMPLE_LEAVES.map((sample) => {
                const isSelected = selectedSampleId === sample.id;
                return (
                  <button
                    key={sample.id}
                    onClick={() => selectSample(sample)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                      isSelected
                        ? 'border-[#0B6B43] bg-emerald-50/50 shadow-xs ring-1 ring-[#0B6B43]'
                        : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100/70 hover:border-slate-300'
                    }`}
                  >
                    <img
                      src={sample.url}
                      alt={sample.name}
                      className="w-10 h-10 rounded-lg object-cover shrink-0 border border-slate-200"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-slate-900 truncate block">
                          {sample.name}
                        </span>
                        {isSelected && <Check className="w-3 h-3 text-[#0B6B43] shrink-0" />}
                      </div>
                      <span className="text-[9px] uppercase font-bold text-emerald-800 bg-emerald-100/70 px-1 py-0.2 rounded mt-0.5 inline-block">
                        {sample.tag}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Diagnostic Synthesis & Ground Truth */}
        <div className="lg:col-span-6 space-y-4">
          {scanResult ? (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-5 animate-in fade-in duration-300">
              {/* Diagnosis Header */}
              <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400">
                    Diagnostic Conclusion
                  </span>
                  <h3 className="text-lg font-black text-slate-900 mt-0.5">
                    {scanResult.suspectedDeficiency}
                  </h3>
                </div>

                <div className="text-right shrink-0">
                  <span
                    className={`inline-block px-3 py-1 rounded-xl text-xs font-bold border ${
                      scanResult.canopyCondition === 'HEALTHY'
                        ? 'bg-emerald-50 text-[#0B6B43] border-emerald-200'
                        : scanResult.canopyCondition === 'SEVERE_STRESS'
                        ? 'bg-rose-50 text-rose-700 border-rose-200'
                        : 'bg-amber-50 text-amber-800 border-amber-200'
                    }`}
                  >
                    {scanResult.canopyCondition.replace('_', ' ')}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">
                    Confidence: {scanResult.confidence}%
                  </div>
                </div>
              </div>

              {/* Visual Observations */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Leaf className="w-3.5 h-3.5 text-[#0B6B43]" />
                  <span>Optical Leaf Observations</span>
                </span>
                <ul className="text-xs text-slate-700 space-y-1.5 pl-1">
                  {scanResult.visualObservations.map((obs, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#0B6B43] mt-1.5 shrink-0" />
                      <span className="leading-relaxed">{obs}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Cross-Correlation with Physical In-Ground Sensor */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Droplets className="w-3.5 h-3.5 text-blue-600" />
                    <span>Ground Sensor Telemetry Correlation</span>
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white text-slate-600 border border-slate-200">
                    ESP32 Node 01
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {scanResult.soilCorrelation}
                </p>
                <div className="flex items-center gap-3 pt-1 text-[11px] font-mono text-slate-500 border-t border-slate-200/60 mt-2">
                  <span>Soil Moisture: <strong>{latestReading.moisture.toFixed(0)}%</strong></span>
                  <span>·</span>
                  <span>Temperature: <strong>{latestReading.soilTemperature.toFixed(1)}°C</strong></span>
                  <span>·</span>
                  <span>Precipitation: <strong>{latestReading.rain ? 'Rain' : 'Dry'}</strong></span>
                </div>
              </div>

              {/* Agronomic Recommendations */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Agronomic Recommendations for Plot</span>
                </span>
                <ul className="text-xs text-slate-700 space-y-2">
                  {scanResult.recommendations.map((rec, idx) => (
                    <li key={idx} className="p-2.5 rounded-xl bg-emerald-50/40 border border-emerald-100 flex items-start gap-2">
                      <Leaf className="w-3.5 h-3.5 text-[#0B6B43] shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Log Note Confirmation */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  onClick={() => setLoggedToNotes(true)}
                  disabled={loggedToNotes}
                  className="px-3.5 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 transition-colors cursor-pointer flex items-center gap-1.5 disabled:opacity-70"
                >
                  {loggedToNotes ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Saved to Plot Logs</span>
                    </>
                  ) : (
                    <span>Save to Garden Bed History</span>
                  )}
                </button>

                <button
                  onClick={() => setScanResult(null)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Clear Results
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-8 shadow-xs text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0B6B43] flex items-center justify-center mx-auto border border-emerald-100">
                <Camera className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">Visual Diagnosis Ready</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                  Capture a leaf photo or pick a sample above, then press <strong>"Diagnose Health with Vision AI"</strong> to cross-correlate optical canopy appearance with underground capacitive telemetry.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-left max-w-sm mx-auto space-y-1.5">
                <div className="text-[11px] font-bold text-slate-800 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>How it works:</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  1. Camera scans leaf pigment for chlorophyll fade (Nitrogen) or edge scorch (Potassium).
                </p>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  2. Reading is cross-checked against live soil moisture to confirm if symptoms are caused by underwatering or true mineral depletion.
                </p>
              </div>
            </div>
          )}

          {/* Prototype Calibration & Sensor Notice */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs text-slate-600 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-slate-900 text-xs">
              <Info className="w-3.5 h-3.5 text-slate-500" />
              <span>Multisensor Hardware Prototype Notice</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500">
              The ESP32-CAM module operates alongside ground capacitive sensors. Physical NPK probes are optional modular extensions — visual leaf screening provides non-invasive nitrogen & potassium deficiency detection during prototype field trials.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
