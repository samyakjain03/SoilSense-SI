import React, { useState } from 'react';
import { Download, Calendar, Filter, Table, TrendingUp, Droplets, Thermometer } from 'lucide-react';
import { SensorReading, IrrigationEvent } from '../types/index.js';
import { InteractiveCharts } from '../components/InteractiveCharts.js';

interface HistoryPageProps {
  history: SensorReading[];
  irrigationEvents: IrrigationEvent[];
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  history,
  irrigationEvents
}) => {
  const [timeFilter, setTimeFilter] = useState<'today' | '7d' | '30d' | 'all'>('7d');

  // Filter history based on range
  const now = new Date();
  const filteredHistory = history.filter((r) => {
    const readingTime = new Date(r.timestamp).getTime();
    if (timeFilter === 'today') {
      return now.getTime() - readingTime <= 24 * 60 * 60 * 1000;
    }
    if (timeFilter === '7d') {
      return now.getTime() - readingTime <= 7 * 24 * 60 * 60 * 1000;
    }
    if (timeFilter === '30d') {
      return now.getTime() - readingTime <= 30 * 24 * 60 * 60 * 1000;
    }
    return true;
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['Timestamp', 'Moisture(%)', 'SoilTemp(C)', 'Humidity(%)', 'Light(Lux)', 'Rain', 'SensorSource'];
    const rows = filteredHistory.map((r) => [
      r.timestamp,
      r.moisture,
      r.soilTemperature,
      r.humidity,
      r.light,
      r.rain ? 'TRUE' : 'FALSE',
      r.source
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `soilsense_history_${timeFilter}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Sensor Telemetry History & Audit</h2>
          <p className="text-xs text-slate-500">
            Exportable longitudinal logs of capacitive and microclimate probes.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Range tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
            {(['today', '7d', '30d', 'all'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setTimeFilter(filter)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer capitalize ${
                  timeFilter === filter
                    ? 'bg-white text-[#0B6B43] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {filter === 'today' ? 'Today' : filter === '7d' ? '7 Days' : filter === '30d' ? '30 Days' : 'All'}
              </button>
            ))}
          </div>

          {/* Export CSV button */}
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Interactive Charts Component */}
      <InteractiveCharts history={filteredHistory} />

      {/* Historical Telemetry Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">Granular Probe Telemetry Log</h3>
            <p className="text-xs text-slate-500">
              Showing {filteredHistory.length} recorded telemetry records.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-white border-b border-slate-200 text-slate-400 font-semibold z-10">
              <tr>
                <th className="pb-3">Timestamp</th>
                <th className="pb-3">Moisture</th>
                <th className="pb-3">Temperature</th>
                <th className="pb-3">Humidity</th>
                <th className="pb-3">Solar Light</th>
                <th className="pb-3">Rain Sensor</th>
                <th className="pb-3">NPK Status</th>
                <th className="pb-3">Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredHistory.slice().reverse().map((r) => {
                const d = new Date(r.timestamp);
                const dateStr = d.toLocaleDateString([], { month: 'short', day: 'numeric' });
                const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

                return (
                  <tr key={r.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 font-medium text-slate-900 whitespace-nowrap">
                      {dateStr} {timeStr}
                    </td>
                    <td className="py-2.5 font-bold text-slate-900">{r.moisture.toFixed(1)}%</td>
                    <td className="py-2.5 font-medium">{r.soilTemperature.toFixed(1)}°C</td>
                    <td className="py-2.5">{r.humidity.toFixed(0)}%</td>
                    <td className="py-2.5 font-mono">{r.light} lx</td>
                    <td className="py-2.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        r.rain ? 'bg-indigo-50 text-indigo-700' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {r.rain ? 'Active Rain' : 'Dry'}
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-400 italic">Unconnected</td>
                    <td className="py-2.5 font-mono text-[10px] text-slate-400">{r.source}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
