import {
  SensorReading,
  SoilHealthReport,
  IrrigationRecommendation,
  IrrigationState,
  IrrigationEvent,
  AlertItem,
  DeviceInfo,
  Garden,
  GardenBed,
  UserProfile,
  DemoScenario,
  CropScanResult
} from '../types/index.js';

class ApiService {
  private token: string | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('soilsense_token');
    }
  }

  public setToken(token: string | null) {
    this.token = token;
    if (typeof window !== 'undefined') {
      if (token) {
        localStorage.setItem('soilsense_token', token);
      } else {
        localStorage.removeItem('soilsense_token');
      }
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const authHeaders: Record<string, string> = {};
    if (this.token) {
      authHeaders['Authorization'] = `Bearer ${this.token}`;
    }

    const res = await fetch(endpoint, {
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders,
        ...options?.headers,
      },
      ...options,
    });

    if (!res.ok) {
      let errMsg = `HTTP Error ${res.status}`;
      try {
        const errorBody = await res.json();
        if (errorBody.error) errMsg = errorBody.error;
      } catch {
        // ignore json parse error
      }
      throw new Error(errMsg);
    }

    return res.json();
  }

  // Authentication
  public async login(email: string, password: string): Promise<{ user: UserProfile; token: string }> {
    const res = await this.request<{ success: boolean; data: { user: UserProfile; token: string } }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    this.setToken(res.data.token);
    return res.data;
  }

  public async register(name: string, email: string, password: string, confirmPassword: string): Promise<{ user: UserProfile; token: string }> {
    const res = await this.request<{ success: boolean; data: { user: UserProfile; token: string } }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password, confirmPassword })
    });
    this.setToken(res.data.token);
    return res.data;
  }

  public async forgotPassword(email: string): Promise<{ message: string; resetToken?: string }> {
    const res = await this.request<{ success: boolean; message: string; data?: { resetToken: string } }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
    return { message: res.message, resetToken: res.data?.resetToken };
  }

  public async resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
    const res = await this.request<{ success: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, newPassword })
    });
    return { message: res.message };
  }

  public async getCurrentUser(): Promise<UserProfile | null> {
    try {
      const res = await this.request<{ success: boolean; data: UserProfile }>('/api/auth/me');
      return res.data;
    } catch {
      return null;
    }
  }

  public async logout(): Promise<void> {
    try {
      await this.request('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    this.setToken(null);
  }

  // Health
  public async getHealth() {
    return this.request<{
      status: string;
      system: string;
      version: string;
      mode: string;
      scenario: string;
      timestamp: string;
      nodes: any[];
    }>('/api/health');
  }

  // Sensors & Latest State
  public async getLatestSensorData(bedId?: string): Promise<{
    reading: SensorReading;
    soilHealth: SoilHealthReport;
    irrigationRecommendation: IrrigationRecommendation;
    isDemo: boolean;
    activeScenario: DemoScenario;
    availableScenarios: string[];
  }> {
    const query = bedId ? `?bedId=${encodeURIComponent(bedId)}` : '';
    const res = await this.request<{ success: boolean; data: any }>(`/api/sensors/latest${query}`);
    return res.data;
  }

  // Sensor History
  public async getSensorHistory(bedId?: string, limit: number = 40): Promise<SensorReading[]> {
    const params = new URLSearchParams();
    if (bedId) params.append('bedId', bedId);
    params.append('limit', limit.toString());
    const res = await this.request<{ success: boolean; data: SensorReading[] }>(`/api/sensors/history?${params.toString()}`);
    return res.data;
  }

  // Trigger Demo Scenario
  public async setDemoScenario(scenario: DemoScenario, bedId?: string, isDemo?: boolean): Promise<{
    reading: SensorReading;
    soilHealth: SoilHealthReport;
    irrigationRecommendation: IrrigationRecommendation;
  }> {
    const res = await this.request<{ success: boolean; data: any }>('/api/sensors/demo', {
      method: 'POST',
      body: JSON.stringify({ scenario, isDemo, bedId })
    });
    return res.data;
  }

  // Toggle Demo Mode
  public async toggleDemoMode(isDemo: boolean): Promise<void> {
    await this.request('/api/sensors/demo', {
      method: 'POST',
      body: JSON.stringify({ isDemo })
    });
  }

  // Soil Health
  public async getSoilHealth(bedId?: string): Promise<SoilHealthReport> {
    const query = bedId ? `?bedId=${encodeURIComponent(bedId)}` : '';
    const res = await this.request<{ success: boolean; data: SoilHealthReport }>(`/api/soil-health/current${query}`);
    return res.data;
  }

  // Irrigation Status
  public async getIrrigationStatus(bedId?: string): Promise<IrrigationState & { currentMoisture: number; thresholdMoisture: number }> {
    const query = bedId ? `?bedId=${encodeURIComponent(bedId)}` : '';
    const res = await this.request<{ success: boolean; data: any }>(`/api/irrigation/status${query}`);
    return res.data;
  }

  // Start Irrigation
  public async startIrrigation(params: {
    durationMinutes: number;
    reason: string;
    mode?: 'AUTOMATED' | 'MANUAL';
    gardenId?: string;
    bedId?: string;
  }): Promise<{ success: boolean; message: string; state: IrrigationState }> {
    return this.request('/api/irrigation/start', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  }

  // Stop Irrigation
  public async stopIrrigation(gardenId?: string, bedId?: string): Promise<{ success: boolean; message: string; state: IrrigationState }> {
    return this.request('/api/irrigation/stop', {
      method: 'POST',
      body: JSON.stringify({ gardenId, bedId })
    });
  }

  // Irrigation History
  public async getIrrigationHistory(limit: number = 25): Promise<IrrigationEvent[]> {
    const res = await this.request<{ success: boolean; data: IrrigationEvent[] }>(`/api/irrigation/history?limit=${limit}`);
    return res.data;
  }

  // Alerts
  public async getAlerts(): Promise<AlertItem[]> {
    const res = await this.request<{ success: boolean; data: AlertItem[] }>('/api/alerts');
    return res.data;
  }

  public async markAlertRead(alertId: string): Promise<void> {
    await this.request(`/api/alerts/${encodeURIComponent(alertId)}/read`, { method: 'POST' });
  }

  public async markAllAlertsRead(): Promise<void> {
    // mark all alerts read
    const alerts = await this.getAlerts();
    for (const a of alerts) {
      if (a.status === 'active') {
        await this.markAlertRead(a.id);
      }
    }
  }

  public async clearAlert(alertId: string): Promise<void> {
    await this.request(`/api/alerts/${encodeURIComponent(alertId)}`, { method: 'DELETE' });
  }

  public async clearAllAlerts(): Promise<void> {
    await this.request('/api/alerts', { method: 'DELETE' });
  }

  // AI Soil Insight
  public async getAiSoilInsight(reading?: SensorReading, bedId?: string): Promise<{
    insight: string;
    source: 'GEMINI_AI' | 'RULE_BASED_ENGINE';
    actionTip: string;
  }> {
    const res = await this.request<{ success: boolean; data: any }>('/api/ai/soil-insight', {
      method: 'POST',
      body: JSON.stringify({ reading, bedId })
    });
    return res.data;
  }

  // Crop / Leaf Scanning
  public async scanCrop(image: string, cropName: string, sampleType?: string): Promise<CropScanResult> {
    const res = await this.request<{ success: boolean; data: CropScanResult }>('/api/ai/crop-scan', {
      method: 'POST',
      body: JSON.stringify({ image, cropName, sampleType })
    });
    return res.data;
  }

  // Gardens & Beds
  public async getGardens(): Promise<{ gardens: Garden[]; beds: GardenBed[] }> {
    const res = await this.request<{ success: boolean; data: { gardens: Garden[]; beds: GardenBed[] } }>('/api/gardens');
    return res.data;
  }

  // Devices
  public async getDevices(): Promise<DeviceInfo[]> {
    const res = await this.request<{ success: boolean; data: DeviceInfo[] }>('/api/devices');
    return res.data;
  }

  public async registerDevice(device: Partial<DeviceInfo>): Promise<DeviceInfo> {
    const res = await this.request<{ success: boolean; data: DeviceInfo }>('/api/devices/register', {
      method: 'POST',
      body: JSON.stringify(device)
    });
    return res.data;
  }

  public async postDeviceReading(deviceId: string, readingData: any): Promise<any> {
    return this.request(`/api/devices/${encodeURIComponent(deviceId)}/readings`, {
      method: 'POST',
      body: JSON.stringify(readingData)
    });
  }

  // Users
  public async getUsers(): Promise<UserProfile[]> {
    const res = await this.request<{ success: boolean; data: UserProfile[] }>('/api/gardens/users');
    return res.data;
  }
}

export const api = new ApiService();
