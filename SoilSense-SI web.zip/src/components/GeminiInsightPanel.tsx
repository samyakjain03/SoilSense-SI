import React, { useState } from 'react';
import { Sparkles, RefreshCw, CheckCircle, Info, Bot, Leaf } from 'lucide-react';
import { SensorReading, SoilHealthReport } from '../types/index.js';
import { api } from '../services/api.js';

interface GeminiInsightPanelProps {
  reading: SensorReading;
  report: SoilHealthReport;
}

export const GeminiInsightPanel: React.FC<GeminiInsightPanelProps> = ({
  reading,
  report
}) => {
  const [insight, setInsight] = useState<string>(
    'Soil conditions are optimal. Moisture and temperature remain within the ideal biological range for community garden crops.'
  );
  const [actionTip, setActionTip] = useState<string>(
    'No watering required today. Telemetry indicates healthy moisture retention.'
  );
  const [engineSource, setEngineSource] = useState<'GEMINI_AI' | 'RULE_BASED_ENGINE'>('RULE_BASED_ENGINE');
  const [loading, setLoading] = useState(false);

  const fetchInsight = async () => {
    setLoading(true);
    try {
      const res = await api.getAiSoilInsight(reading, reading.bedId);
      if (res && res.insight) {
        setInsight(res.insight);
        if (res.actionTip) setActionTip(res.actionTip);
        if (res.source) setEngineSource(res.source);
      }
    } catch (err) {
      console.warn('Failed to fetch AI insight:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-emerald-950/5 via-white to-slate-50 rounded-2xl border border-emerald-900/10 p-5 shadow-xs my-6">
      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-[#0B6B43] text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Gardener AI Synthesis</h3>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                engineSource === 'GEMINI_AI'
                  ? 'bg-purple-100 text-purple-800 border border-purple-200'
                  : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
              }`}>
                {engineSource === 'GEMINI_AI' ? 'Gemini 3.8 Flash' : 'Deterministic Agronomic Engine'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Plain-language synthesis converted from 6 raw telemetry vectors.
            </p>
          </div>
        </div>

        <button
          onClick={fetchInsight}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-xs transition-colors cursor-pointer"
          title="Regenerate agronomist evaluation"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#0B6B43]' : 'text-slate-400'}`} />
          <span className="hidden sm:inline">Refresh Insight</span>
        </button>
      </div>

      <div className="p-3.5 rounded-xl bg-white border border-slate-200/70 text-xs leading-relaxed text-slate-800 my-2">
        <p className="font-medium text-slate-800">
          "{insight}"
        </p>

        {actionTip && (
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-2 text-slate-600 text-[11px]">
            <Leaf className="w-3.5 h-3.5 text-[#0B6B43] shrink-0" />
            <span className="font-semibold text-slate-700">Action Tip: </span>
            <span>{actionTip}</span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 px-1">
        <span>Evaluates: Moisture · DS18B20 Temp · Humidity · Solar Irradiance · Rain Optical</span>
        <span>Zero API keys exposed in browser</span>
      </div>
    </div>
  );
};
