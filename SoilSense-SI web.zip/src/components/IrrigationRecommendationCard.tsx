import React from 'react';
import {
  Droplets,
  Clock,
  AlertTriangle,
  Play,
  CheckCircle2,
  Hourglass,
  ArrowRight
} from 'lucide-react';
import { IrrigationRecommendation, IrrigationState } from '../types/index.js';

interface IrrigationRecommendationCardProps {
  recommendation: IrrigationRecommendation;
  irrigationState: IrrigationState;
  onTriggerIrrigate: () => void;
  onStopIrrigate: () => void;
}

export const IrrigationRecommendationCard: React.FC<IrrigationRecommendationCardProps> = ({
  recommendation,
  irrigationState,
  onTriggerIrrigate,
  onStopIrrigate
}) => {
  const isPumping = irrigationState.isActive;

  const getActionBadge = () => {
    switch (recommendation.action) {
      case 'IRRIGATE_NOW':
        return {
          title: 'IRRIGATE NOW',
          color: 'bg-emerald-600 text-white',
          textColor: 'text-emerald-700',
          desc: 'Automated or manual valve open recommended immediately.',
          priorityColor: 'text-rose-600 bg-rose-50 border-rose-200'
        };
      case 'WAIT':
        return {
          title: 'WAIT / PRECIPITATION OBSERVED',
          color: 'bg-amber-600 text-white',
          textColor: 'text-amber-700',
          desc: 'Rain detected or recent irrigation still percolating.',
          priorityColor: 'text-amber-700 bg-amber-50 border-amber-200'
        };
      case 'CHECK_SOIL':
        return {
          title: 'INSPECT BED MULCH',
          color: 'bg-blue-600 text-white',
          textColor: 'text-blue-700',
          desc: 'Soil moisture on marginal boundary. Check root depth.',
          priorityColor: 'text-blue-700 bg-blue-50 border-blue-200'
        };
      case 'NO_IRRIGATION':
      default:
        return {
          title: 'NO IRRIGATION REQUIRED',
          color: 'bg-slate-800 text-white',
          textColor: 'text-slate-700',
          desc: 'Soil moisture level satisfies biological requirements.',
          priorityColor: 'text-slate-600 bg-slate-50 border-slate-200'
        };
    }
  };

  const badge = getActionBadge();

  return (
    <div className={`rounded-2xl border p-5 sm:p-6 shadow-xs flex flex-col justify-between transition-all ${
      isPumping
        ? 'bg-gradient-to-br from-emerald-50/80 via-blue-50/40 to-white border-emerald-400'
        : 'bg-white border-slate-200/90'
    }`}>
      <div>
        {/* Top Header */}
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
              isPumping ? 'bg-blue-600 text-white animate-pulse' : 'bg-blue-50 text-blue-700 border border-blue-200/60'
            }`}>
              <Droplets className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Action Engine
              </span>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">Smart Irrigation Decision</h2>
            </div>
          </div>

          {/* Priority Tag */}
          <div className="flex items-center gap-1.5 text-xs font-semibold">
            <span className="text-slate-500">Priority:</span>
            <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${badge.priorityColor}`}>
              {recommendation.priority}
            </span>
          </div>
        </div>

        {/* Current Recommendation Big Callout */}
        <div className="my-3 p-4 rounded-xl bg-slate-50/80 border border-slate-100 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Recommendation
            </span>
            <span className="text-xs font-medium text-slate-400">
              Confidence {recommendation.confidence}%
            </span>
          </div>

          <div className="text-lg font-black tracking-tight text-slate-900">
            {badge.title}
          </div>

          {/* Decision Reason */}
          <div className="text-xs text-slate-600 leading-relaxed pt-1">
            <span className="font-semibold text-slate-800">Why: </span>
            {recommendation.reason}
          </div>
        </div>

        {/* Duration & Valve Parameters */}
        <div className="grid grid-cols-2 gap-3 my-3">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Recommended Duration</span>
            </div>
            <p className="text-sm font-bold text-slate-900">
              {recommendation.duration > 0 ? `${recommendation.duration} minutes` : '0 min (Standby)'}
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mb-1">
              <Droplets className="w-3.5 h-3.5 text-blue-600" />
              <span>Solenoid Valve Mode</span>
            </div>
            <p className="text-sm font-bold text-slate-900 capitalize">
              {irrigationState.mode.toLowerCase()} (Submersible)
            </p>
          </div>
        </div>
      </div>

      {/* Action Button Row */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
        {isPumping ? (
          <div className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-emerald-100/60 p-3 rounded-xl border border-emerald-300">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-600"></span>
              </span>
              <div>
                <p className="text-xs font-bold text-slate-900">Irrigation Actuator Active</p>
                <p className="text-[11px] text-slate-600 font-mono">
                  {Math.floor(irrigationState.remainingSeconds / 60)}m {irrigationState.remainingSeconds % 60}s remaining
                </p>
              </div>
            </div>

            <button
              onClick={onStopIrrigate}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              Stop Actuator Now
            </button>
          </div>
        ) : (
          <>
            <div className="text-[11px] text-slate-500 leading-tight">
              {recommendation.action === 'IRRIGATE_NOW'
                ? 'Manual override or automatic valve command ready.'
                : 'Irrigation suspended based on soil moisture and weather.'}
            </div>

            <button
              onClick={onTriggerIrrigate}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold shadow-sm transition-all cursor-pointer shrink-0 ${
                recommendation.action === 'IRRIGATE_NOW'
                  ? 'bg-[#0B6B43] hover:bg-[#095736] text-white shadow-emerald-900/15'
                  : 'bg-slate-800 hover:bg-slate-900 text-white'
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start Irrigation</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};
