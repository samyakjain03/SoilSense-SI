import React, { useState } from 'react';
import {
  Sprout,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  CheckCircle,
  HelpCircle,
  Info,
  Droplets,
  Thermometer,
  ShieldAlert,
  Beaker
} from 'lucide-react';
import { SoilHealthReport } from '../types/index.js';

interface SoilHealthCardProps {
  report: SoilHealthReport;
  onExploreAnalysis?: () => void;
}

export const SoilHealthCard: React.FC<SoilHealthCardProps> = ({
  report,
  onExploreAnalysis
}) => {
  const [expandedWhy, setExpandedWhy] = useState(false);

  // Status visual attributes
  const getStatusBadge = () => {
    switch (report.status) {
      case 'HEALTHY':
        return {
          label: 'OPTIMAL HEALTH',
          subLabel: 'Good biological equilibrium',
          color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
          dot: 'bg-emerald-500'
        };
      case 'DRY':
        return {
          label: 'DRY SOIL',
          subLabel: 'Moisture depleted below 30%',
          color: 'text-amber-800 bg-amber-50 border-amber-200',
          dot: 'bg-amber-500'
        };
      case 'WATERLOGGED':
        return {
          label: 'WATERLOGGED',
          subLabel: 'Saturation exceeds 80%',
          color: 'text-blue-800 bg-blue-50 border-blue-200',
          dot: 'bg-blue-500'
        };
      case 'HOT & DRY':
        return {
          label: 'HOT & ARID STRESS',
          subLabel: 'Extreme heat & dry soil',
          color: 'text-rose-800 bg-rose-50 border-rose-200',
          dot: 'bg-rose-500'
        };
      case 'WATCH':
      default:
        return {
          label: 'WATCH / MARGINAL',
          subLabel: 'Sub-optimal moisture or temp',
          color: 'text-amber-700 bg-amber-50 border-amber-200',
          dot: 'bg-amber-400'
        };
    }
  };

  const statusMeta = getStatusBadge();

  // Score circular progress calculations
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (report.score / 100) * circumference;

  const getScoreColor = (score: number) => {
    if (score >= 75) return 'text-[#0B6B43] stroke-[#0B6B43]';
    if (score >= 50) return 'text-amber-600 stroke-amber-600';
    return 'text-rose-600 stroke-rose-600';
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs flex flex-col justify-between relative overflow-hidden">
      {/* Top Banner & Status Header */}
      <div>
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#0B6B43] flex items-center justify-center border border-emerald-200/60">
              <Sprout className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Diagnostic Index
              </span>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">Soil Health Status</h2>
            </div>
          </div>

          {/* Unboxed natural metadata */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className={`w-2 h-2 rounded-full ${statusMeta.dot}`} />
            <span className="font-semibold text-slate-800">{statusMeta.label}</span>
          </div>
        </div>

        {/* Center Score & Radial Gauge */}
        <div className="flex flex-col sm:flex-row items-center gap-6 py-2 my-1">
          {/* Radial progress ring */}
          <div className="relative flex items-center justify-center shrink-0">
            <svg className="w-28 h-28 transform -rotate-90" viewBox="0 0 96 96">
              <circle
                cx="48"
                cy="48"
                r={radius}
                className="stroke-slate-100"
                strokeWidth="7"
                fill="transparent"
              />
              <circle
                cx="48"
                cy="48"
                r={radius}
                className={`${getScoreColor(report.score)} transition-all duration-700 ease-out`}
                strokeWidth="7"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-extrabold text-slate-900 tracking-tight">{report.score}</span>
              <span className="text-[10px] uppercase font-semibold text-slate-400">/ 100</span>
            </div>
          </div>

          {/* Diagnostic Pillar Breakdown */}
          <div className="grid grid-cols-2 gap-3 w-full">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Droplets className="w-3 h-3 text-blue-600" /> Moisture
                </span>
                <span className="text-[10px] text-slate-400">Measured</span>
              </div>
              <p className="text-xs font-bold text-slate-800 capitalize">
                {report.moistureStatus.toLowerCase().replace('_', ' ')}
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Thermometer className="w-3 h-3 text-amber-600" /> Temperature
                </span>
                <span className="text-[10px] text-slate-400">DS18B20</span>
              </div>
              <p className="text-xs font-bold text-slate-800 capitalize">
                {report.temperatureStatus.toLowerCase()}
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-rose-500" /> Water Risk
                </span>
                <span className="text-[10px] text-slate-400">Estimated</span>
              </div>
              <p className="text-xs font-bold text-slate-800 capitalize">
                {report.waterRisk.toLowerCase()} Risk
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[11px] font-medium flex items-center gap-1">
                  <Beaker className="w-3 h-3 text-purple-600" /> Nutrient Signal
                </span>
                <span className="text-[10px] text-slate-400">Optional</span>
              </div>
              <p className="text-xs font-bold text-slate-800">
                {report.nutrientStatus === 'AVAILABLE' ? 'Available' : 'Not Connected'}
              </p>
            </div>
          </div>
        </div>

        {/* Explainability "Why?" Expandable Section */}
        <div className="mt-4 pt-3 border-t border-slate-100">
          <button
            onClick={() => setExpandedWhy(!expandedWhy)}
            className="w-full flex items-center justify-between text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors py-1"
          >
            <div className="flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#0B6B43]" />
              <span>Why is the soil in this condition?</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-slate-500 font-normal">
              <span>{expandedWhy ? 'Hide diagnostic factors' : 'Show diagnostic factors'}</span>
              {expandedWhy ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </div>
          </button>

          {expandedWhy && (
            <div className="mt-2.5 p-3 rounded-xl bg-slate-50 text-slate-700 space-y-1.5 border border-slate-100 text-xs animate-in fade-in duration-200">
              {report.reasons.map((reason, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0B6B43] mt-1.5 shrink-0" />
                  <span className="text-[11px] leading-relaxed text-slate-600">{reason}</span>
                </div>
              ))}
              <div className="pt-2 mt-2 border-t border-slate-200/60 text-[10px] text-slate-500">
                Decision engine rule evaluation: confidence {report.confidence}%
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Honest Prototype Calibration Disclaimer */}
      <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
        <span className="italic">{report.calibratedThresholdsNotice}</span>
        {onExploreAnalysis && (
          <button
            onClick={onExploreAnalysis}
            className="text-[#0B6B43] font-semibold hover:underline cursor-pointer ml-2 shrink-0"
          >
            Detailed analysis &rarr;
          </button>
        )}
      </div>
    </div>
  );
};
