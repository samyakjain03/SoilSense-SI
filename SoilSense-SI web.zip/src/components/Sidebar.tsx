import React from 'react';
import {
  LayoutDashboard,
  Sprout,
  Cpu,
  Droplets,
  TrendingUp,
  Bell,
  CpuIcon,
  Sliders,
  Layers,
  Camera,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { Garden, GardenBed } from '../types/index.js';

export type NavTab = 
  | 'dashboard' 
  | 'gardens' 
  | 'soil' 
  | 'irrigation' 
  | 'sensors' 
  | 'analytics' 
  | 'alerts' 
  | 'devices' 
  | 'settings'
  | 'scan';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  unreadAlertsCount: number;
  isIrrigating: boolean;
  selectedGarden: Garden | null;
  selectedBed: GardenBed | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  unreadAlertsCount,
  isIrrigating,
  selectedGarden,
  selectedBed
}) => {
  const mainNavItems = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'gardens' as NavTab, label: 'Gardens', icon: Layers },
    { id: 'soil' as NavTab, label: 'Soil Health', icon: Sprout },
    {
      id: 'irrigation' as NavTab,
      label: 'Irrigation',
      icon: Droplets,
      badge: isIrrigating ? 'Pumping' : undefined
    },
    { id: 'sensors' as NavTab, label: 'Sensors', icon: Cpu },
    { id: 'analytics' as NavTab, label: 'Analytics', icon: TrendingUp },
    {
      id: 'alerts' as NavTab,
      label: 'Alerts',
      icon: Bell,
      count: unreadAlertsCount > 0 ? unreadAlertsCount : undefined
    },
    { id: 'devices' as NavTab, label: 'Devices', icon: CpuIcon },
    { id: 'settings' as NavTab, label: 'Settings', icon: Sliders }
  ];

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-slate-200/80 p-4 shrink-0 min-h-[calc(100vh-61px)]">
      {/* Current Garden Station Card */}
      <div 
        onClick={() => onSelectTab('gardens')}
        className="mb-5 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70 hover:border-slate-300 transition-colors cursor-pointer"
      >
        <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold mb-1">
          <span className="uppercase tracking-wider">ACTIVE STATION</span>
          <span className="flex items-center gap-1 text-[#0B6B43] font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Online
          </span>
        </div>
        <p className="text-xs font-bold text-slate-900 truncate">
          {selectedGarden?.name || 'JECRC Community Garden'}
        </p>
        <p className="text-[11px] text-slate-500 truncate mt-0.5">
          {selectedBed?.name || 'Tomato Bed'}
        </p>
      </div>

      {/* Main Navigation (Section 44) */}
      <nav className="space-y-1 flex-1">
        {mainNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#0B6B43] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 animate-pulse">
                  {item.badge}
                </span>
              )}

              {item.count !== undefined && (
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                    isActive ? 'bg-white text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {item.count}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Garden Tools: Optical Crop Scanning Feature (Section 29) */}
      <div className="mt-auto pt-4 border-t border-slate-100 space-y-2">
        <button
          onClick={() => onSelectTab('scan')}
          className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'scan'
              ? 'bg-purple-100 text-purple-900 border border-purple-300'
              : 'bg-purple-50/70 text-purple-800 border border-purple-100 hover:bg-purple-100/70'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Camera className="w-4 h-4 text-purple-700" />
            <span>Crop Scanning Camera</span>
          </div>
          <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-white text-purple-700">
            Tool
          </span>
        </button>

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60 text-[11px] text-slate-500 leading-tight">
          SoilSense AI · Urban Community Garden Intelligence
        </div>
      </div>
    </aside>
  );
};
