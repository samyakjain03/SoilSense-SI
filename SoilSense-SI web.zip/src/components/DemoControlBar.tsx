import React from 'react';
import { Sparkles, Sun, Droplet, Flame, CloudRain, CheckCircle2 } from 'lucide-react';
import { DemoScenario } from '../types/index.js';

interface DemoControlBarProps {
  activeScenario: DemoScenario;
  onSelectScenario: (scenario: DemoScenario) => void;
  isLoading?: boolean;
}

export const DemoControlBar: React.FC<DemoControlBarProps> = ({
  activeScenario,
  onSelectScenario,
  isLoading = false
}) => {
  const scenarios: {
    id: DemoScenario;
    label: string;
    icon: React.ElementType;
    color: string;
    description: string;
  }[] = [
    {
      id: 'HEALTHY',
      label: 'Healthy Soil',
      icon: CheckCircle2,
      color: 'text-emerald-700 hover:border-emerald-500',
      description: '55–70% moisture, nominal temperature'
    },
    {
      id: 'DRY_SOIL',
      label: 'Dry Soil',
      icon: Droplet,
      color: 'text-amber-700 hover:border-amber-500',
      description: '15–30% moisture, irrigation required'
    },
    {
      id: 'WATERLOGGED',
      label: 'Waterlogged',
      icon: CloudRain,
      color: 'text-blue-700 hover:border-blue-500',
      description: '80–95% moisture, root hypoxia risk'
    },
    {
      id: 'HOT_DRY',
      label: 'Hot & Arid',
      icon: Flame,
      color: 'text-rose-700 hover:border-rose-500',
      description: '35–42°C heat stress, depleted moisture'
    },
    {
      id: 'RECENT_RAIN',
      label: 'Recent Rain',
      icon: CloudRain,
      color: 'text-indigo-700 hover:border-indigo-500',
      description: 'Rain sensor active, withhold watering'
    }
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-4 shadow-xs mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-emerald-100 flex items-center justify-center text-[#0B6B43]">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 tracking-tight">Interactive Simulation Scenarios</h3>
            <p className="text-[11px] text-slate-500">
              Instantly simulate real-world microclimate events to evaluate soil health and irrigation logic.
            </p>
          </div>
        </div>
        <div className="text-[11px] font-mono text-slate-400 sm:text-right">
          Active: <span className="font-semibold text-slate-700">{activeScenario.replace('_', ' ')}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {scenarios.map((sc) => {
          const Icon = sc.icon;
          const isActive = activeScenario === sc.id;
          return (
            <button
              key={sc.id}
              disabled={isLoading}
              onClick={() => onSelectScenario(sc.id)}
              className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                isActive
                  ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                  : 'bg-slate-50/70 hover:bg-white text-slate-700 border-slate-200/80 hover:shadow-xs'
              } ${isLoading ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'}`}
            >
              <div className="flex items-center justify-between w-full mb-1">
                <span className="text-xs font-semibold">{sc.label}</span>
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
              </div>
              <p className={`text-[10px] leading-tight ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                {sc.description}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
