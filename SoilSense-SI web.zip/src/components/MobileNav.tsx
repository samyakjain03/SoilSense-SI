import React, { useState } from 'react';
import {
  LayoutDashboard,
  Sprout,
  Droplets,
  Bell,
  MoreHorizontal,
  Layers,
  Cpu,
  TrendingUp,
  CpuIcon,
  Sliders,
  Camera,
  LogOut,
  X
} from 'lucide-react';
import { NavTab } from './Sidebar.js';

interface MobileNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  unreadAlertsCount: number;
  isIrrigating: boolean;
  onLogout: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  onSelectTab,
  unreadAlertsCount,
  isIrrigating,
  onLogout
}) => {
  const [moreDrawerOpen, setMoreDrawerOpen] = useState(false);

  const primaryTabs = [
    { id: 'dashboard' as NavTab, label: 'Home', icon: LayoutDashboard },
    { id: 'soil' as NavTab, label: 'Soil', icon: Sprout },
    { id: 'irrigation' as NavTab, label: 'Irrigation', icon: Droplets, isPumping: isIrrigating },
    { id: 'alerts' as NavTab, label: 'Alerts', icon: Bell, count: unreadAlertsCount }
  ];

  const moreItems = [
    { id: 'gardens' as NavTab, label: 'Gardens & Beds', icon: Layers },
    { id: 'sensors' as NavTab, label: 'Sensor Nodes', icon: Cpu },
    { id: 'analytics' as NavTab, label: 'Analytics & Trends', icon: TrendingUp },
    { id: 'devices' as NavTab, label: 'Device Hardware', icon: CpuIcon },
    { id: 'scan' as NavTab, label: 'Crop Scanning Camera', icon: Camera, highlight: true },
    { id: 'settings' as NavTab, label: 'Settings & Demo', icon: Sliders }
  ];

  return (
    <>
      {/* Mobile Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-3 py-1.5 shadow-lg">
        <div className="flex items-center justify-around">
          {primaryTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setMoreDrawerOpen(false);
                  onSelectTab(tab.id);
                }}
                className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg text-[10px] font-semibold transition-colors relative min-w-[50px] ${
                  isActive ? 'text-[#0B6B43] font-bold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'text-[#0B6B43]' : 'text-slate-400'}`} />
                  {tab.isPumping && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping" />
                  )}
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="absolute -top-1 -right-1.5 w-3.5 h-3.5 bg-amber-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                      {tab.count}
                    </span>
                  )}
                </div>
                <span>{tab.label}</span>
              </button>
            );
          })}

          {/* More Button */}
          <button
            onClick={() => setMoreDrawerOpen(true)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg text-[10px] font-semibold transition-colors relative min-w-[50px] ${
              moreDrawerOpen || ['gardens', 'sensors', 'analytics', 'devices', 'settings', 'scan'].includes(activeTab)
                ? 'text-[#0B6B43] font-bold'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <MoreHorizontal className="w-5 h-5 mb-0.5" />
            <span>More</span>
          </button>
        </div>
      </nav>

      {/* More Bottom Sheet Drawer */}
      {moreDrawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col justify-end">
          <div className="bg-white rounded-t-3xl p-5 border-t border-slate-200 shadow-2xl max-h-[80vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900">All Garden Sections</span>
              <button
                onClick={() => setMoreDrawerOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {moreItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectTab(item.id);
                      setMoreDrawerOpen(false);
                    }}
                    className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                      isActive
                        ? 'bg-[#0B6B43] text-white border-[#0B6B43]'
                        : item.highlight
                        ? 'bg-purple-50 text-purple-900 border-purple-200'
                        : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <Icon className={`w-5 h-5 mb-2 ${isActive ? 'text-white' : item.highlight ? 'text-purple-700' : 'text-slate-500'}`} />
                    <span className="text-xs font-bold">{item.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-slate-100">
              <button
                onClick={() => {
                  setMoreDrawerOpen(false);
                  onLogout();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of SoilSense</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
