import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine
} from 'recharts';
import { Droplets, Thermometer, Cloud, Maximize2 } from 'lucide-react';
import { SensorReading } from '../types/index.js';

interface InteractiveChartsProps {
  history: SensorReading[];
}

export const InteractiveCharts: React.FC<InteractiveChartsProps> = ({ history }) => {
  const [activeMetric, setActiveMetric] = useState<'moisture' | 'temperature' | 'humidity'>('moisture');

  // Format data for chart
  const chartData = history.map((r) => {
    const d = new Date(r.timestamp);
    const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return {
      time: timeStr,
      timestamp: r.timestamp,
      moisture: r.moisture,
      temperature: r.soilTemperature,
      humidity: r.humidity,
      light: r.light,
      rain: r.rain ? 1 : 0
    };
  });

  const getMetricConfig = () => {
    switch (activeMetric) {
      case 'temperature':
        return {
          title: 'Soil Temperature History (DS18B20)',
          dataKey: 'temperature',
          unit: '°C',
          stroke: '#E88922',
          fill: '#FDF3E7',
          domain: [10, 45],
          targetLow: 18,
          targetHigh: 28,
          labelLow: 'Optimal 18°C',
          labelHigh: 'Warm 28°C'
        };
      case 'humidity':
        return {
          title: 'Ambient Humidity History',
          dataKey: 'humidity',
          unit: '%',
          stroke: '#1769AA',
          fill: '#EBF3FA',
          domain: [15, 100],
          targetLow: 40,
          targetHigh: 80,
          labelLow: 'Low 40%',
          labelHigh: 'High 80%'
        };
      case 'moisture':
      default:
        return {
          title: 'Soil Moisture Dynamics vs Time',
          dataKey: 'moisture',
          unit: '%',
          stroke: '#0B6B43',
          fill: '#E8F5E9',
          domain: [0, 100],
          targetLow: 30,
          targetHigh: 75,
          labelLow: 'Dry Threshold 30%',
          labelHigh: 'Upper Bound 75%'
        };
    }
  };

  const currentConfig = getMetricConfig();

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs my-6">
      {/* Top Header with Metric Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">Real-Time Soil Conditions</h3>
          <p className="text-xs text-slate-500">
            Continuously recorded telemetry streamed from garden probe sensors.
          </p>
        </div>

        {/* Metric Segmented Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200/70 self-start sm:self-auto">
          <button
            onClick={() => setActiveMetric('moisture')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              activeMetric === 'moisture'
                ? 'bg-white text-[#0B6B43] shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Droplets className="w-3.5 h-3.5" />
            <span>Moisture</span>
          </button>

          <button
            onClick={() => setActiveMetric('temperature')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              activeMetric === 'temperature'
                ? 'bg-white text-[#E88922] shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Thermometer className="w-3.5 h-3.5" />
            <span>Temperature</span>
          </button>

          <button
            onClick={() => setActiveMetric('humidity')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              activeMetric === 'humidity'
                ? 'bg-white text-[#1769AA] shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>Humidity</span>
          </button>
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="h-72 w-full">
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="metricGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={currentConfig.stroke} stopOpacity={0.25} />
                  <stop offset="95%" stopColor={currentConfig.stroke} stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis
                dataKey="time"
                tick={{ fontSize: 11, fill: '#64748B' }}
                stroke="#CBD5E1"
                tickLine={false}
              />
              <YAxis
                domain={currentConfig.domain}
                tick={{ fontSize: 11, fill: '#64748B' }}
                stroke="#CBD5E1"
                tickLine={false}
                unit={currentConfig.unit}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-2.5 rounded-xl text-xs shadow-lg border border-slate-800">
                        <div className="text-[10px] text-slate-400 mb-1">{data.time}</div>
                        <div className="font-bold flex items-center gap-1.5">
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: currentConfig.stroke }}
                          />
                          <span>{currentConfig.dataKey.toUpperCase()}: </span>
                          <span className="text-white text-sm">
                            {payload[0].value} {currentConfig.unit}
                          </span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />

              {/* Target zone reference lines */}
              <ReferenceLine
                y={currentConfig.targetLow}
                stroke="#94A3B8"
                strokeDasharray="4 4"
                label={{
                  value: currentConfig.labelLow,
                  fill: '#64748B',
                  fontSize: 10,
                  position: 'insideBottomRight'
                }}
              />
              <ReferenceLine
                y={currentConfig.targetHigh}
                stroke="#94A3B8"
                strokeDasharray="4 4"
                label={{
                  value: currentConfig.labelHigh,
                  fill: '#64748B',
                  fontSize: 10,
                  position: 'insideTopRight'
                }}
              />

              <Area
                type="monotone"
                dataKey={currentConfig.dataKey}
                stroke={currentConfig.stroke}
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#metricGradient)"
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-full flex items-center justify-center text-slate-400 text-xs">
            Telemetry stream buffering...
          </div>
        )}
      </div>

      {/* Legend & Calibration Footer */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 gap-2">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-slate-400 border-dashed" />
            <span>Configured Decision Thresholds</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: currentConfig.stroke }} />
            <span>Live Rolling Series</span>
          </div>
        </div>

        <span className="text-[10px] text-slate-400 font-mono">
          Last 36 sensor points recorded
        </span>
      </div>
    </div>
  );
};
