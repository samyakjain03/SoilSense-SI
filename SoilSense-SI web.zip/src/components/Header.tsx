import React, { useState } from 'react';
import {
  Sprout,
  Wifi,
  Bell,
  ChevronDown,
  User,
  ShieldCheck,
  Eye,
  LogOut,
  Layers
} from 'lucide-react';
import { Garden, GardenBed, UserProfile, UserRole } from '../types/index.js';

interface HeaderProps {
  gardens: Garden[];
  selectedGarden: Garden | null;
  onSelectGarden: (garden: Garden) => void;
  beds: GardenBed[];
  selectedBed: GardenBed | null;
  onSelectBed: (bed: GardenBed) => void;
  currentUser: UserProfile;
  unreadAlertsCount: number;
  onOpenAlerts: () => void;
  onLogout: () => void;
  onNavigateHome: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  gardens,
  selectedGarden,
  onSelectGarden,
  beds,
  selectedBed,
  onSelectBed,
  currentUser,
  unreadAlertsCount,
  onOpenAlerts,
  onLogout,
  onNavigateHome
}) => {
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [gardenDropdownOpen, setGardenDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-3 transition-all">
      <div className="flex items-center justify-between gap-4">
        {/* Brand & Plot Selector */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={onNavigateHome}>
            <div className="w-9 h-9 rounded-xl bg-[#0B6B43] flex items-center justify-center text-white shadow-xs">
              <Sprout className="w-5 h-5 text-emerald-100" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-slate-900 text-base tracking-tight">SoilSense</span>
                <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-emerald-50 text-[#0B6B43] border border-emerald-200/60">
                  SI
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block font-medium">Smart Soil Today. Greener Tomorrow.</p>
            </div>
          </div>

          <div className="hidden lg:block h-6 w-px bg-slate-200 mx-1" />

          {/* Garden & Bed Selector Dropdown */}
          <div className="relative hidden md:block">
            <button
              onClick={() => setGardenDropdownOpen(!gardenDropdownOpen)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200/80 rounded-xl transition-colors cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-bold text-slate-900">{selectedGarden?.name || 'JECRC Community Garden'}</span>
              <span className="text-slate-400">/</span>
              <span className="text-slate-600 truncate max-w-[140px]">{selectedBed?.name || 'Tomato Bed'}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
            </button>

            {gardenDropdownOpen && (
              <div className="absolute left-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50">
                <div className="text-[10px] font-bold text-slate-400 px-2.5 py-1 uppercase tracking-wider">
                  Community Gardens
                </div>
                {gardens.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => {
                      onSelectGarden(g);
                      setGardenDropdownOpen(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded-xl text-xs transition-colors flex items-center justify-between cursor-pointer ${
                      selectedGarden?.id === g.id ? 'bg-emerald-50 text-[#0B6B43] font-bold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{g.name}</span>
                    {selectedGarden?.id === g.id && <span className="text-[10px] text-emerald-600 font-bold">Active</span>}
                  </button>
                ))}

                <div className="h-px bg-slate-100 my-1.5" />
                <div className="text-[10px] font-bold text-slate-400 px-2.5 py-1 uppercase tracking-wider">
                  Beds in {selectedGarden?.name.split(' ')[0]}
                </div>
                {beds.filter(b => b.gardenId === selectedGarden?.id).slice(0, 6).map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      onSelectBed(b);
                      setGardenDropdownOpen(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs transition-colors flex items-center justify-between cursor-pointer ${
                      selectedBed?.id === b.id ? 'bg-emerald-50 text-[#0B6B43] font-bold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="truncate">{b.name}</span>
                    <span className="text-[10px] text-slate-400">{b.cropType.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Section: Hardware status, Alerts, and Profile */}
        <div className="flex items-center gap-3">
          {/* Connection status */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-[11px] font-medium">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600" />
            </span>
            <span className="font-semibold text-slate-700">Nodes Connected</span>
          </div>

          {/* Alerts Bell */}
          <button
            onClick={onOpenAlerts}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            title="System Alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-amber-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                {unreadAlertsCount}
              </span>
            )}
          </button>

          {/* User Profile */}
          <div className="relative">
            <button
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200 cursor-pointer"
            >
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-emerald-600/30"
              />
              <div className="hidden sm:block text-left">
                <p className="text-xs font-bold text-slate-800 leading-tight">{currentUser.name}</p>
                <p className="text-[10px] text-slate-500">{currentUser.role.replace('_', ' ')}</p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {userDropdownOpen && (
              <div className="absolute right-0 mt-2 w-60 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50">
                <div className="px-3 py-2 border-b border-slate-100 mb-1">
                  <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                  <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                  <div className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold text-[#0B6B43] bg-emerald-50 px-2 py-0.5 rounded">
                    {currentUser.role.replace('_', ' ')}
                  </div>
                </div>

                <button
                  onClick={() => {
                    setUserDropdownOpen(false);
                    onLogout();
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
