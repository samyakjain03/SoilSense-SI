import React, { useState } from 'react';
import { Droplets, AlertTriangle, X, Play, Clock, ShieldCheck } from 'lucide-react';

interface IrrigationConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (durationMinutes: number, reason: string) => void;
  currentMoisture: number;
  recommendedDuration: number;
  bedName: string;
}

export const IrrigationConfirmModal: React.FC<IrrigationConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  currentMoisture,
  recommendedDuration,
  bedName
}) => {
  const [duration, setDuration] = useState<number>(recommendedDuration || 3);
  const [reason, setReason] = useState<string>('Moisture below threshold — manual cycle initiated');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-[#0B6B43] flex items-center justify-center">
              <Droplets className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Confirm Irrigation Cycle</h3>
              <p className="text-[11px] text-slate-500">{bedName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          {/* Telemetry Snapshot */}
          <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs">
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-semibold">Current Moisture</span>
              <p className="text-base font-bold text-slate-900 mt-0.5">{currentMoisture.toFixed(1)}%</p>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-semibold">Recommended</span>
              <p className="text-base font-bold text-[#0B6B43] mt-0.5">{recommendedDuration} Minutes</p>
            </div>
          </div>

          {/* Duration Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Cycle Duration (Minutes)
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 5, 8].map((min) => (
                <button
                  key={min}
                  type="button"
                  onClick={() => setDuration(min)}
                  className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                    duration === min
                      ? 'bg-[#0B6B43] text-white border-[#0B6B43] shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {min}m
                </button>
              ))}
            </div>
          </div>

          {/* Actuation Reason / Note */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Actuation Trigger Rationale
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 text-slate-800 focus:outline-hidden focus:border-[#0B6B43] focus:ring-1 focus:ring-[#0B6B43]"
            />
          </div>

          {/* Hardware notice */}
          <div className="flex items-start gap-2 p-3 rounded-xl bg-blue-50/60 border border-blue-100 text-blue-900 text-xs">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-blue-800">
              Triggering this cycle commands the ESP32 relay to engage the submersible pump and open the 12V solenoid valve.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirm(duration, reason);
              onClose();
            }}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#0B6B43] hover:bg-[#095736] rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Open Valve & Start</span>
          </button>
        </div>
      </div>
    </div>
  );
};
