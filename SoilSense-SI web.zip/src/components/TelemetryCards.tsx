import React from 'react';
import {
  Droplets,
  Thermometer,
  Cloud,
  Sun,
  CloudRain,
  Beaker,
  CheckCircle2,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { SensorReading } from '../types/index.js';

interface TelemetryCardsProps {
  reading: SensorReading;
  onSelectSensor?: (sensorType: string) => void;
}

export const TelemetryCards: React.FC<TelemetryCardsProps> = ({
  reading,
  onSelectSensor
}) => {
  const getMoistureStatus = (val: number) => {
    if (val < 30) return { label: 'Dry (Low)', color: 'text-amber-600', dot: 'bg-amber-500' };
    if (val > 80) return { label: 'Waterlogged', color: 'text-blue-600', dot: 'bg-blue-500' };
    return { label: 'Optimal', color: 'text-emerald-700', dot: 'bg-emerald-500' };
  };

  const getTempStatus = (val: number) => {
    if (val > 35) return { label: 'Heat Stress', color: 'text-rose-600', dot: 'bg-rose-500' };
    if (val < 15) return { label: 'Cold Soil', color: 'text-blue-500', dot: 'bg-blue-400' };
    return { label: 'Optimal', color: 'text-emerald-700', dot: 'bg-emerald-500' };
  };

  const moistureMeta = getMoistureStatus(reading.moisture);
  const tempMeta = getTempStatus(reading.soilTemperature);

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 my-6">
      {/* 1. Capacitive Moisture */}
      <div
        onClick={() => onSelectSensor && onSelectSensor('moisture')}
        className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Moisture</span>
            <div className="w-6 h-6 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Droplets className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 tracking-tight">
            {reading.moisture.toFixed(1)}<span className="text-sm font-normal text-slate-500 ml-0.5">%</span>
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono text-[10px]">Capacitive</span>
          <span className={`font-semibold flex items-center gap-1 ${moistureMeta.color}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${moistureMeta.dot}`} />
            {moistureMeta.label}
          </span>
        </div>
      </div>

      {/* 2. DS18B20 Soil Temperature */}
      <div
        onClick={() => onSelectSensor && onSelectSensor('temperature')}
        className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Temperature</span>
            <div className="w-6 h-6 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Thermometer className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 tracking-tight">
            {reading.soilTemperature.toFixed(1)}<span className="text-sm font-normal text-slate-500 ml-0.5">°C</span>
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono text-[10px]">DS18B20</span>
          <span className={`font-semibold flex items-center gap-1 ${tempMeta.color}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${tempMeta.dot}`} />
            {tempMeta.label}
          </span>
        </div>
      </div>

      {/* 3. Ambient Humidity */}
      <div
        onClick={() => onSelectSensor && onSelectSensor('humidity')}
        className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Humidity</span>
            <div className="w-6 h-6 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center">
              <Cloud className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 tracking-tight">
            {reading.humidity.toFixed(0)}<span className="text-sm font-normal text-slate-500 ml-0.5">%</span>
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono text-[10px]">Ambient</span>
          <span className="text-slate-700 font-medium">Relative</span>
        </div>
      </div>

      {/* 4. Ambient Solar Light */}
      <div
        onClick={() => onSelectSensor && onSelectSensor('light')}
        className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Solar Light</span>
            <div className="w-6 h-6 rounded-lg bg-yellow-50 text-yellow-600 flex items-center justify-center">
              <Sun className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 tracking-tight">
            {reading.light}<span className="text-sm font-normal text-slate-500 ml-0.5">lx</span>
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono text-[10px]">Photodiode</span>
          <span className="text-slate-700 font-medium">
            {reading.light > 800 ? 'Direct Sun' : reading.light > 200 ? 'Diffused' : 'Shaded'}
          </span>
        </div>
      </div>

      {/* 5. Rain Sensor */}
      <div
        onClick={() => onSelectSensor && onSelectSensor('rain')}
        className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Rainfall</span>
            <div className="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <CloudRain className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-black text-slate-900 tracking-tight pt-0.5">
            {reading.rain ? 'Precipitation' : 'No Rain'}
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
          <span className="text-slate-400 font-mono text-[10px]">Digital Probe</span>
          <span className={`font-semibold ${reading.rain ? 'text-indigo-600' : 'text-slate-500'}`}>
            {reading.rain ? 'Active' : 'Dry Surface'}
          </span>
        </div>
      </div>

      {/* 6. Optional NPK Sensor (With strict honesty) */}
      <div
        onClick={() => onSelectSensor && onSelectSensor('npk')}
        className="bg-slate-50/80 rounded-2xl border border-slate-200/80 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-purple-900/70">NPK Sensor</span>
            <div className="w-6 h-6 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <Beaker className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-sm font-bold text-slate-700 tracking-tight leading-snug">
            NPK sensor not connected
          </div>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-200/70 flex items-center justify-between text-[10px] text-slate-500">
          <span className="font-mono">RS485 Probe</span>
          <span className="text-purple-700 font-semibold bg-purple-50 px-1 rounded">Optional</span>
        </div>
      </div>
    </div>
  );
};
