import {
  SensorReading,
  SoilHealthReport,
  SoilHealthStatus,
  MoistureStatus,
  TemperatureStatus,
  WaterRiskLevel,
  NutrientSignalStatus
} from '../../src/types/index.js';

export class SoilHealthService {
  /**
   * Analyzes raw multi-sensor telemetry using rule-based explainable logic.
   * Note: Explicitly labeled as demo thresholds to be calibrated during field testing.
   */
  public analyzeReading(reading: SensorReading): SoilHealthReport {
    const reasons: string[] = [];
    let status: SoilHealthStatus = 'HEALTHY';
    let moistureStatus: MoistureStatus = 'OPTIMAL';
    let temperatureStatus: TemperatureStatus = 'OPTIMAL';
    let waterRisk: WaterRiskLevel = 'LOW';
    let nutrientStatus: NutrientSignalStatus = reading.npkConnected ? 'AVAILABLE' : 'OPTIONAL_UNCONNECTED';

    // Sub-scores
    let waterHealthScore = 90;
    let thermalScore = 90;
    let nutrientHealthScore = reading.npkConnected ? 85 : 70; // baseline if unmeasured

    // 1. Moisture Evaluation (Capacitive sensor: 0-100%)
    if (reading.moisture < 20) {
      moistureStatus = 'CRITICAL_LOW';
      waterRisk = 'CRITICAL';
      waterHealthScore = 25;
      reasons.push(`Moisture is critically low (${reading.moisture.toFixed(1)}% < 20%), creating acute root desiccation risk.`);
    } else if (reading.moisture < 30) {
      moistureStatus = 'LOW';
      waterRisk = 'HIGH';
      waterHealthScore = 45;
      reasons.push(`Moisture is below the demo threshold (${reading.moisture.toFixed(1)}% < 30%), indicating dry garden soil.`);
    } else if (reading.moisture > 80) {
      moistureStatus = 'WATERLOGGED';
      waterRisk = 'HIGH';
      waterHealthScore = 35;
      reasons.push(`Moisture exceeds saturation limit (${reading.moisture.toFixed(1)}% > 80%), creating root hypoxia risk.`);
    } else if (reading.moisture > 75) {
      moistureStatus = 'HIGH';
      waterRisk = 'MODERATE';
      waterHealthScore = 70;
      reasons.push(`Moisture is elevated (${reading.moisture.toFixed(1)}%), approaching upper saturation boundary.`);
    } else {
      moistureStatus = 'OPTIMAL';
      waterRisk = 'LOW';
      waterHealthScore = 95;
      reasons.push(`Soil moisture is within the optimal vegetative range (40% - 75%).`);
    }

    // 2. Temperature Evaluation (DS18B20 waterproof probe)
    if (reading.soilTemperature > 38) {
      temperatureStatus = 'HIGH';
      thermalScore = 35;
      reasons.push(`Soil temperature is dangerously elevated (${reading.soilTemperature.toFixed(1)}°C > 38°C), causing root heat stress.`);
    } else if (reading.soilTemperature > 32) {
      temperatureStatus = 'ELEVATED';
      thermalScore = 65;
      reasons.push(`Soil temperature is elevated (${reading.soilTemperature.toFixed(1)}°C), accelerating moisture evaporation.`);
    } else if (reading.soilTemperature < 12) {
      temperatureStatus = 'COLD';
      thermalScore = 60;
      reasons.push(`Soil temperature is low (${reading.soilTemperature.toFixed(1)}°C), slowing microbial nutrient cycling.`);
    } else {
      temperatureStatus = 'OPTIMAL';
      thermalScore = 95;
      reasons.push(`Soil temperature is in the biological sweet spot (18°C - 28°C).`);
    }

    // 3. Environmental Correlations: Rain & Light
    if (reading.rain) {
      reasons.push(`Active precipitation detected by optical/digital rain sensor. Moisture expected to recharge.`);
    }
    if (reading.light > 800) {
      reasons.push(`High ambient solar irradiance (${reading.light} Lux), peak daytime transpiration.`);
    }

    // 4. Determine Overall Soil Status
    if (reading.soilTemperature > 35 && reading.moisture < 35) {
      status = 'HOT & DRY';
    } else if (reading.moisture < 30) {
      status = 'DRY';
    } else if (reading.moisture > 80) {
      status = 'WATERLOGGED';
    } else if (reading.moisture < 38 || reading.soilTemperature > 32) {
      status = 'WATCH';
    } else {
      status = 'HEALTHY';
    }

    // 5. Total Composite Score (0 - 100)
    // Water health is weighted 50%, thermal 30%, nutrient/baseline 20%
    const compositeScore = Math.round(
      waterHealthScore * 0.50 +
      thermalScore * 0.30 +
      nutrientHealthScore * 0.20
    );

    // 6. Actionable Recommendation
    let recommendation = '';
    if (status === 'HOT & DRY') {
      recommendation = 'Urgent priority: Schedule deep evening/morning irrigation to combat heat and soil desiccation.';
    } else if (status === 'DRY') {
      recommendation = reading.rain
        ? 'Soil is currently dry, but rain is detected. Hold irrigation and observe infiltration.'
        : 'Irrigation recommended. Soil moisture is below threshold with no precipitation.';
    } else if (status === 'WATERLOGGED') {
      recommendation = 'Do NOT irrigate. Allow garden bed to drain to prevent root rot and anaerobic conditions.';
    } else if (status === 'WATCH') {
      recommendation = 'Soil condition is marginal. Monitor trend over next 2 hours before triggering irrigation.';
    } else {
      recommendation = 'Soil conditions are optimal. No irrigation or corrective soil intervention needed.';
    }

    // Honest calibration label
    const calibratedThresholdsNotice = 'Demo thresholds — to be calibrated during field testing with local soil texture.';

    return {
      id: `report-${Date.now()}`,
      gardenId: reading.gardenId,
      bedId: reading.bedId,
      timestamp: reading.timestamp || new Date().toISOString(),
      status,
      score: Math.min(100, Math.max(10, compositeScore)),
      moistureStatus,
      temperatureStatus,
      waterRisk,
      nutrientStatus,
      recommendation,
      confidence: 88, // rule-based confidence
      reasons,
      calibratedThresholdsNotice,
      waterHealthScore,
      nutrientHealthScore,
      thermalScore
    };
  }
}

export const soilHealthService = new SoilHealthService();
