import {
  SensorReading,
  SoilHealthStatus,
  IrrigationAction,
  IrrigationRecommendation,
  IrrigationEvent
} from '../../src/types/index.js';

export class IrrigationDecisionEngine {
  /**
   * Evaluates telemetry, recent irrigation history, and soil health to derive a clear actionable decision.
   */
  public evaluate(
    reading: SensorReading,
    soilStatus: SoilHealthStatus,
    recentEvents: IrrigationEvent[] = []
  ): IrrigationRecommendation {
    // Check if irrigated very recently (within past 45 minutes)
    const now = new Date();
    const lastIrrigation = recentEvents.length > 0 ? recentEvents[0] : null;
    let recentlyWatered = false;
    if (lastIrrigation) {
      const elapsedMs = now.getTime() - new Date(lastIrrigation.endedAt).getTime();
      if (elapsedMs < 45 * 60 * 1000) {
        recentlyWatered = true;
      }
    }

    // 1. Waterlogged check
    if (soilStatus === 'WATERLOGGED' || reading.moisture >= 80) {
      return {
        action: 'NO_IRRIGATION',
        duration: 0,
        priority: 'NONE',
        reason: `Soil moisture is saturated (${reading.moisture.toFixed(1)}% ≥ 80%). Further irrigation risks root rot and nutrient leaching.`,
        confidence: 96
      };
    }

    // 2. Active Rain or Recent Rain check
    if (reading.rain) {
      return {
        action: 'WAIT',
        duration: 0,
        priority: 'LOW',
        reason: 'Active rainfall detected by garden rain sensor. Natural precipitation will recharge the root zone.',
        confidence: 92
      };
    }

    // 3. Recently irrigated cooldown check
    if (recentlyWatered && reading.moisture < 35) {
      return {
        action: 'WAIT',
        duration: 0,
        priority: 'LOW',
        reason: 'Plot was irrigated within the last 45 minutes. Soil moisture is still percolating into the sensor depth zone.',
        confidence: 88
      };
    }

    // 4. Hot & Dry critical condition
    if (soilStatus === 'HOT & DRY' || (reading.soilTemperature > 34 && reading.moisture < 35)) {
      return {
        action: 'IRRIGATE_NOW',
        duration: 4, // 4 minutes
        priority: 'HIGH',
        reason: `High heat stress (${reading.soilTemperature.toFixed(1)}°C) combined with dry soil (${reading.moisture.toFixed(1)}%). Immediate irrigation required to prevent wilting.`,
        confidence: 94
      };
    }

    // 5. Dry soil without rain
    if (soilStatus === 'DRY' || reading.moisture < 30) {
      return {
        action: 'IRRIGATE_NOW',
        duration: 3, // 3 minutes standard
        priority: 'HIGH',
        reason: `Soil moisture (${reading.moisture.toFixed(1)}%) is below the configured 30% threshold and no rainfall is detected.`,
        confidence: 91
      };
    }

    // 6. Marginal soil (Watch)
    if (soilStatus === 'WATCH' || reading.moisture < 38) {
      return {
        action: 'CHECK_SOIL',
        duration: 2,
        priority: 'MEDIUM',
        reason: `Moisture is on the lower boundary (${reading.moisture.toFixed(1)}%). Check bed mulch layer; irrigation may be needed soon.`,
        confidence: 80
      };
    }

    // 7. Optimal / Healthy soil
    return {
      action: 'NO_IRRIGATION',
      duration: 0,
      priority: 'NONE',
      reason: `Soil moisture (${reading.moisture.toFixed(1)}%) and temperature (${reading.soilTemperature.toFixed(1)}°C) are well within the optimal range.`,
      confidence: 95
    };
  }
}

export const irrigationEngine = new IrrigationDecisionEngine();
