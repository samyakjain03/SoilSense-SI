import { dbService } from './dbService.js';
import { IrrigationState, IrrigationEvent } from '../../src/types/index.js';

export class IrrigationService {
  private state: IrrigationState = {
    pumpStatus: 'OFF',
    valveStatus: 'CLOSED',
    isActive: false,
    remainingSeconds: 0,
    durationMinutes: 3,
    startedAt: null,
    reason: 'Idle — ready for scheduled or manual command',
    mode: 'MANUAL',
    moistureBefore: 0
  };

  private timerInterval: NodeJS.Timeout | null = null;
  private currentEventId: string | null = null;

  public getStatus(): IrrigationState {
    return { ...this.state };
  }

  public startIrrigation(params: {
    durationMinutes?: number;
    reason?: string;
    mode?: 'AUTOMATED' | 'MANUAL';
    gardenId?: string;
    bedId?: string;
  }): { success: boolean; message: string; state: IrrigationState } {
    if (this.state.isActive) {
      return {
        success: false,
        message: 'Irrigation cycle is already in progress.',
        state: this.getStatus()
      };
    }

    const durationMinutes = params.durationMinutes || 3;
    const durationSeconds = durationMinutes * 60;
    const reason = params.reason || 'Manual gardener actuation';
    const mode = params.mode || 'MANUAL';
    const bedId = params.bedId || 'bed-tomatoes-01';
    const gardenId = params.gardenId || 'garden-highland-01';

    const latest = dbService.getLatestReading(bedId);
    const moistureBefore = latest ? latest.moisture : 28;

    this.state = {
      pumpStatus: 'ON',
      valveStatus: 'OPEN',
      isActive: true,
      remainingSeconds: durationSeconds,
      durationMinutes,
      startedAt: new Date().toISOString(),
      reason,
      mode,
      moistureBefore
    };

    this.currentEventId = `irrig-${Date.now()}`;

    // Add alert indicating irrigation started
    dbService.addAlert({
      id: `alert-irr-${Date.now()}`,
      severity: 'info',
      title: 'Irrigation Actuator Activated',
      message: `Solenoid valve opened & submersible pump ON for ${durationMinutes} min cycle. Reason: ${reason}.`,
      timestamp: new Date().toISOString(),
      status: 'active',
      gardenId,
      bedId
    });

    if (this.timerInterval) clearInterval(this.timerInterval);

    // Tick every 1 second
    this.timerInterval = setInterval(() => {
      if (this.state.remainingSeconds > 0) {
        this.state.remainingSeconds -= 1;
      } else {
        this.stopIrrigation(gardenId, bedId, true);
      }
    }, 1000);

    return {
      success: true,
      message: `Irrigation started successfully for ${durationMinutes} minutes.`,
      state: this.getStatus()
    };
  }

  public stopIrrigation(
    gardenId: string = 'garden-highland-01',
    bedId: string = 'bed-tomatoes-01',
    autoCompleted: boolean = false
  ): { success: boolean; message: string; state: IrrigationState } {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }

    if (!this.state.isActive && !this.state.startedAt) {
      return {
        success: true,
        message: 'Irrigation is not currently running.',
        state: this.getStatus()
      };
    }

    const startedTime = this.state.startedAt ? new Date(this.state.startedAt) : new Date();
    const endedTime = new Date();
    const actualDurationSec = Math.max(1, Math.round((endedTime.getTime() - startedTime.getTime()) / 1000));

    // Simulate moisture increase after watering: e.g. +20% to +35%
    const latestReading = dbService.getLatestReading(bedId);
    const beforeMoisture = this.state.moistureBefore || (latestReading ? latestReading.moisture : 28);
    const moistureBoost = Math.min(40, 22 + Math.random() * 8);
    const moistureAfter = Math.min(78, Math.round((beforeMoisture + moistureBoost) * 10) / 10);

    // Save event
    const event: IrrigationEvent = {
      id: this.currentEventId || `irrig-${Date.now()}`,
      gardenId,
      bedId,
      startedAt: startedTime.toISOString(),
      endedAt: endedTime.toISOString(),
      duration: actualDurationSec,
      trigger: this.state.mode === 'AUTOMATED' ? 'AUTOMATED_THRESHOLD' : 'MANUAL',
      moistureBefore: beforeMoisture,
      moistureAfter,
      mode: this.state.mode,
      pumpStatus: 'OFF',
      valveStatus: 'CLOSED'
    };
    dbService.addIrrigationEvent(event);

    // If there's a latest reading, simulate the moisture jump!
    if (latestReading) {
      const updatedReading = {
        ...latestReading,
        id: `reading-post-irr-${Date.now()}`,
        timestamp: new Date().toISOString(),
        moisture: moistureAfter,
        source: 'SIMULATED' as const
      };
      dbService.addSensorReading(updatedReading);
    }

    // Reset state
    this.state = {
      pumpStatus: 'OFF',
      valveStatus: 'CLOSED',
      isActive: false,
      remainingSeconds: 0,
      durationMinutes: 3,
      startedAt: null,
      reason: autoCompleted ? 'Cycle finished normally' : 'Manually stopped by operator',
      mode: 'MANUAL',
      moistureBefore: 0
    };
    this.currentEventId = null;

    // Alert
    dbService.addAlert({
      id: `alert-comp-${Date.now()}`,
      severity: 'success',
      title: 'Irrigation Cycle Complete',
      message: `Watering finished (${actualDurationSec}s elapsed). Soil moisture recharged to ${moistureAfter.toFixed(1)}%.`,
      timestamp: new Date().toISOString(),
      status: 'active',
      gardenId,
      bedId
    });

    return {
      success: true,
      message: `Irrigation stopped. Soil moisture recharged to ${moistureAfter.toFixed(1)}%.`,
      state: this.getStatus()
    };
  }
}

export const irrigationService = new IrrigationService();
