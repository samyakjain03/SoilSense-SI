import fs from 'fs';
import path from 'path';
import {
  UserProfile,
  Garden,
  GardenBed,
  DeviceInfo,
  SensorReading,
  SoilHealthReport,
  IrrigationEvent,
  AlertItem
} from '../../src/types/index.js';

interface DatabaseSchema {
  users: UserProfile[];
  gardens: Garden[];
  gardenBeds: GardenBed[];
  devices: DeviceInfo[];
  sensorReadings: SensorReading[];
  soilHealthReports: SoilHealthReport[];
  irrigationEvents: IrrigationEvent[];
  alerts: AlertItem[];
  systemSettings: {
    demoMode: boolean;
    activeScenario: string;
    autoIrrigationEnabled: boolean;
    moistureThreshold: number;
    lastTick: string;
  };
}

const DB_PATH = path.resolve(process.cwd(), 'data/db.json');

class DatabaseService {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadOrInit();
  }

  private loadOrInit(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed.gardens && parsed.gardens.length > 0 && parsed.gardens[0].name.includes('JECRC')) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn('[DB] Failed to read db.json, generating default seed:', err);
    }

    const seeded = this.generateSeedData();
    this.saveData(seeded);
    return seeded;
  }

  private saveData(dataToSave: DatabaseSchema = this.data): void {
    try {
      const dir = path.dirname(DB_PATH);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DB_PATH, JSON.stringify(dataToSave, null, 2), 'utf-8');
    } catch (err) {
      console.error('[DB] Error writing to db.json:', err);
    }
  }

  private generateSeedData(): DatabaseSchema {
    const now = new Date();
    const primaryGardenId = 'garden-jecrc-01';

    // 12 Beds for JECRC Community Garden: 9 Healthy, 2 Attention, 1 Critical
    const jecrcBeds: GardenBed[] = [
      {
        id: 'bed-tomatoes-01',
        gardenId: primaryGardenId,
        name: 'Tomato Bed',
        cropType: 'Heirloom Nightshades (Solanaceae)',
        area: '14.5 m²',
        deviceId: 'ESP32-001',
        status: 'HEALTHY',
        healthScore: 82,
        currentMoisture: 41.0,
        currentTemp: 27.4,
        notes: 'Capacitive probe nominal, drip lines active'
      },
      {
        id: 'bed-chilli-02',
        gardenId: primaryGardenId,
        name: 'Chilli Bed',
        cropType: 'Capsicum & Hot Peppers',
        area: '11.0 m²',
        deviceId: 'ESP32-001',
        status: 'HEALTHY',
        healthScore: 85,
        currentMoisture: 44.2,
        currentTemp: 26.8,
        notes: 'Optimal vegetative stage'
      },
      {
        id: 'bed-herbs-03',
        gardenId: primaryGardenId,
        name: 'Herb Bed',
        cropType: 'Basil, Mint & Rosemary',
        area: '8.5 m²',
        deviceId: 'ESP32-001',
        status: 'HEALTHY',
        healthScore: 88,
        currentMoisture: 48.0,
        currentTemp: 25.2,
        notes: 'Regular hand-pruned plot'
      },
      {
        id: 'bed-vegetable-04',
        gardenId: primaryGardenId,
        name: 'Vegetable Bed',
        cropType: 'Brassicas & Leafy Greens',
        area: '16.0 m²',
        deviceId: 'ESP32-002',
        status: 'ATTENTION',
        healthScore: 68,
        currentMoisture: 31.5,
        currentTemp: 29.5,
        notes: 'Moisture approaching dry threshold'
      },
      {
        id: 'bed-spinach-05',
        gardenId: primaryGardenId,
        name: 'Spinach & Chard Bed',
        cropType: 'Spinacia oleracea',
        area: '10.0 m²',
        deviceId: 'ESP32-002',
        status: 'HEALTHY',
        healthScore: 84,
        currentMoisture: 45.0,
        currentTemp: 26.1,
        notes: 'Healthy leaf canopy'
      },
      {
        id: 'bed-carrots-06',
        gardenId: primaryGardenId,
        name: 'Carrot & Root Bed',
        cropType: 'Daucus carota',
        area: '12.0 m²',
        deviceId: 'ESP32-002',
        status: 'HEALTHY',
        healthScore: 86,
        currentMoisture: 43.5,
        currentTemp: 25.8,
        notes: 'Deep root percolation tested'
      },
      {
        id: 'bed-onions-07',
        gardenId: primaryGardenId,
        name: 'Allium & Onion Bed',
        cropType: 'Allium cepa',
        area: '9.0 m²',
        deviceId: 'ESP32-002',
        status: 'HEALTHY',
        healthScore: 81,
        currentMoisture: 40.2,
        currentTemp: 27.0,
        notes: 'Low water requirement crop'
      },
      {
        id: 'bed-beans-08',
        gardenId: primaryGardenId,
        name: 'Legume & Bush Bean Bed',
        cropType: 'Phaseolus vulgaris',
        area: '13.0 m²',
        deviceId: 'ESP32-001',
        status: 'HEALTHY',
        healthScore: 83,
        currentMoisture: 42.0,
        currentTemp: 26.5,
        notes: 'Nitrogen-fixing cover crop'
      },
      {
        id: 'bed-cucumbers-09',
        gardenId: primaryGardenId,
        name: 'Cucumber Trellis Bed',
        cropType: 'Cucumis sativus',
        area: '15.0 m²',
        deviceId: 'ESP32-001',
        status: 'ATTENTION',
        healthScore: 65,
        currentMoisture: 32.0,
        currentTemp: 31.0,
        notes: 'High transpiration rate during midday'
      },
      {
        id: 'bed-berries-10',
        gardenId: primaryGardenId,
        name: 'Berry Patch Bed',
        cropType: 'Fragaria × ananassa',
        area: '7.5 m²',
        deviceId: 'ESP32-001',
        status: 'CRITICAL',
        healthScore: 42,
        currentMoisture: 21.0,
        currentTemp: 34.8,
        notes: 'Urgent watering needed; dry root zone'
      },
      {
        id: 'bed-marigolds-11',
        gardenId: primaryGardenId,
        name: 'Companion Flower Bed',
        cropType: 'Tagetes erecta',
        area: '6.0 m²',
        deviceId: 'ESP32-002',
        status: 'HEALTHY',
        healthScore: 89,
        currentMoisture: 46.5,
        currentTemp: 25.4,
        notes: 'Pest deterrent border'
      },
      {
        id: 'bed-nursery-12',
        gardenId: primaryGardenId,
        name: 'Seedling Nursery Bed',
        cropType: 'Microgreens & Starters',
        area: '5.0 m²',
        deviceId: 'ESP32-002',
        status: 'HEALTHY',
        healthScore: 91,
        currentMoisture: 52.0,
        currentTemp: 24.8,
        notes: 'Misted daily via secondary line'
      }
    ];

    // Historical readings for Tomato Bed (bed-tomatoes-01)
    const historicalReadings: SensorReading[] = [];
    for (let i = 36; i >= 0; i--) {
      const timePoint = new Date(now.getTime() - i * 60 * 60 * 1000);
      const hour = timePoint.getHours();
      const tempCycle = 24.5 + Math.sin((hour - 8) / 12 * Math.PI) * 4;
      const humidityCycle = 62 - Math.sin((hour - 8) / 12 * Math.PI) * 12;
      const moistureLevel = Math.max(35, 41 - (36 - i) * 0.12 + (Math.sin(i * 0.5) * 1.5));
      const lightLevel = (hour >= 6 && hour <= 19) ? Math.floor(Math.sin((hour - 6) / 13 * Math.PI) * 850) + 120 : 0;

      historicalReadings.push({
        id: `reading-seed-${36 - i}`,
        sensorId: 'ESP32-001',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01',
        timestamp: timePoint.toISOString(),
        moisture: Math.round(moistureLevel * 10) / 10,
        soilTemperature: Math.round(tempCycle * 10) / 10,
        humidity: Math.round(humidityCycle * 10) / 10,
        light: lightLevel,
        rain: false,
        npkNitrogen: null,
        npkPhosphorus: null,
        npkPotassium: null,
        npkConnected: false,
        source: 'SIMULATED'
      });
    }

    // Ensure latest reading matches Tomato Bed default
    historicalReadings.push({
      id: `reading-current`,
      sensorId: 'ESP32-001',
      gardenId: primaryGardenId,
      bedId: 'bed-tomatoes-01',
      timestamp: now.toISOString(),
      moisture: 41.0,
      soilTemperature: 27.4,
      humidity: 61.0,
      light: 720,
      rain: false,
      npkNitrogen: null,
      npkPhosphorus: null,
      npkPotassium: null,
      npkConnected: false,
      source: 'SIMULATED'
    });

    const initialUsers: UserProfile[] = [
      {
        id: 'usr-admin-01',
        name: 'Elena Rostova',
        email: 'elena@soilsense.garden',
        password: 'password123',
        role: 'ADMIN',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        createdAt: new Date(now.getTime() - 90 * 86400000).toISOString()
      },
      {
        id: 'usr-mgr-02',
        name: 'Marcus Vance',
        email: 'marcus@soilsense.garden',
        password: 'password123',
        role: 'GARDEN_MANAGER',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        createdAt: new Date(now.getTime() - 45 * 86400000).toISOString()
      }
    ];

    const initialGardens: Garden[] = [
      {
        id: primaryGardenId,
        name: 'JECRC Community Garden',
        location: 'Block C Plots, Urban Ecological Zone',
        createdAt: new Date(now.getTime() - 180 * 86400000).toISOString(),
        status: 'ACTIVE',
        totalBeds: 12,
        healthyCount: 9,
        attentionCount: 2,
        criticalCount: 1
      },
      {
        id: 'garden-riverside-02',
        name: 'Riverside Community Plots',
        location: 'East Greenway Sector 4',
        createdAt: new Date(now.getTime() - 90 * 86400000).toISOString(),
        status: 'ACTIVE',
        totalBeds: 8,
        healthyCount: 7,
        attentionCount: 1,
        criticalCount: 0
      }
    ];

    const initialDevices: DeviceInfo[] = [
      {
        id: 'ESP32-001',
        name: 'ESP32 Node 01 (Sensory Telemetry)',
        type: 'NODE1_ENVIRONMENT',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01',
        status: 'ONLINE',
        lastSeen: now.toISOString(),
        firmwareVersion: 'v2.4.1-edge',
        batteryLevel: 94
      },
      {
        id: 'ESP32-CAM-01',
        name: 'ESP32-CAM (Optical Canopy Sensor)',
        type: 'CAM_NUTRIENT',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01',
        status: 'ONLINE',
        lastSeen: now.toISOString(),
        firmwareVersion: 'v1.2.3-ov2640'
      },
      {
        id: 'ESP32-RELAY-01',
        name: 'Relay Controller (12V Pump & Valve)',
        type: 'NODE2_EDGE_ML',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01',
        status: 'ONLINE',
        lastSeen: now.toISOString(),
        firmwareVersion: 'v2.1.0-actuator'
      }
    ];

    const initialIrrigationEvents: IrrigationEvent[] = [
      {
        id: 'irrig-01',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01',
        startedAt: new Date(now.getTime() - 28 * 60 * 60 * 1000).toISOString(),
        endedAt: new Date(now.getTime() - 28 * 60 * 60 * 1000 + 180000).toISOString(),
        duration: 180,
        trigger: 'AUTOMATED_THRESHOLD',
        moistureBefore: 31.2,
        moistureAfter: 48.5,
        mode: 'AUTOMATED',
        pumpStatus: 'OFF',
        valveStatus: 'CLOSED'
      }
    ];

    const initialAlerts: AlertItem[] = [
      {
        id: 'alert-01',
        severity: 'info',
        title: 'Tomato Bed Telemetry Online',
        message: 'ESP32 Node 01 reporting nominal moisture (41%) and temperature (27.4°C).',
        timestamp: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(),
        status: 'active',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01'
      },
      {
        id: 'alert-02',
        severity: 'warning',
        title: 'Berry Patch Bed Moisture Low',
        message: 'Berry Patch Bed moisture is at 21%, below the 30% threshold. Attention required.',
        timestamp: new Date(now.getTime() - 4 * 60 * 60 * 1000).toISOString(),
        status: 'active',
        gardenId: primaryGardenId,
        bedId: 'bed-berries-10'
      },
      {
        id: 'alert-03',
        severity: 'success',
        title: 'Scheduled Irrigation Completed',
        message: '6-minute drip cycle completed for Tomato Bed. Pump returned to standby.',
        timestamp: new Date(now.getTime() - 28 * 60 * 60 * 1000).toISOString(),
        status: 'read',
        gardenId: primaryGardenId,
        bedId: 'bed-tomatoes-01'
      }
    ];

    return {
      users: initialUsers,
      gardens: initialGardens,
      gardenBeds: jecrcBeds,
      devices: initialDevices,
      sensorReadings: historicalReadings,
      soilHealthReports: [],
      irrigationEvents: initialIrrigationEvents,
      alerts: initialAlerts,
      systemSettings: {
        demoMode: true,
        activeScenario: 'HEALTHY',
        autoIrrigationEnabled: true,
        moistureThreshold: 35,
        lastTick: now.toISOString()
      }
    };
  }

  // Users & Auth
  public getUsers(): UserProfile[] { return this.data.users; }

  public findUserByEmail(email: string): UserProfile | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(userData: { name: string; email: string; password?: string; role?: 'GARDEN_MANAGER' | 'VIEWER' }): UserProfile {
    const newUser: UserProfile = {
      id: `usr-${Date.now()}`,
      name: userData.name,
      email: userData.email,
      password: userData.password || 'password123',
      role: 'GARDEN_MANAGER', // Security: regular signups are strictly GARDEN_MANAGER, not ADMIN
      avatar: `https://images.unsplash.com/photo-${1534528741775 + (this.data.users.length % 5)}?w=150&auto=format&fit=crop&q=80`,
      createdAt: new Date().toISOString()
    };
    this.data.users.push(newUser);
    this.saveData();
    return newUser;
  }

  public setResetToken(email: string, token: string): boolean {
    const user = this.findUserByEmail(email);
    if (!user) return false;
    user.resetToken = token;
    user.resetExpires = new Date(Date.now() + 3600000).toISOString(); // 1 hour
    this.saveData();
    return true;
  }

  public resetPassword(token: string, newPassword: string): boolean {
    const user = this.data.users.find(u => u.resetToken === token && u.resetExpires && new Date(u.resetExpires) > new Date());
    if (!user) return false;
    user.password = newPassword;
    user.resetToken = undefined;
    user.resetExpires = undefined;
    this.saveData();
    return true;
  }

  // Getters
  public getGardens(): Garden[] { return this.data.gardens; }
  public getGardenBeds(gardenId?: string): GardenBed[] {
    return gardenId ? this.data.gardenBeds.filter(b => b.gardenId === gardenId) : this.data.gardenBeds;
  }
  public getDevices(): DeviceInfo[] { return this.data.devices; }
  
  public getLatestReading(bedId?: string): SensorReading | null {
    const list = bedId ? this.data.sensorReadings.filter(r => r.bedId === bedId) : this.data.sensorReadings;
    if (list.length === 0) return null;
    return list[list.length - 1];
  }

  public getReadingHistory(bedId?: string, limit: number = 50): SensorReading[] {
    const list = bedId ? this.data.sensorReadings.filter(r => r.bedId === bedId) : this.data.sensorReadings;
    return list.slice(-limit);
  }

  public addSensorReading(reading: SensorReading): void {
    this.data.sensorReadings.push(reading);
    if (this.data.sensorReadings.length > 500) {
      this.data.sensorReadings = this.data.sensorReadings.slice(-300);
    }
    this.saveData();
  }

  public getSoilHealthReports(limit: number = 20): SoilHealthReport[] {
    return this.data.soilHealthReports.slice(-limit);
  }

  public addSoilHealthReport(report: SoilHealthReport): void {
    this.data.soilHealthReports.push(report);
    if (this.data.soilHealthReports.length > 100) {
      this.data.soilHealthReports = this.data.soilHealthReports.slice(-50);
    }
    this.saveData();
  }

  public getIrrigationEvents(limit: number = 30): IrrigationEvent[] {
    return this.data.irrigationEvents.slice(-limit).reverse();
  }

  public addIrrigationEvent(event: IrrigationEvent): void {
    this.data.irrigationEvents.push(event);
    this.saveData();
  }

  public getAlerts(): AlertItem[] {
    return this.data.alerts;
  }

  public addAlert(alert: AlertItem): void {
    this.data.alerts.unshift(alert);
    if (this.data.alerts.length > 50) {
      this.data.alerts = this.data.alerts.slice(0, 50);
    }
    this.saveData();
  }

  public markAlertAsRead(alertId: string): boolean {
    const item = this.data.alerts.find(a => a.id === alertId);
    if (item) {
      item.status = 'read';
      this.saveData();
      return true;
    }
    return false;
  }

  public markAllAlertsAsRead(): void {
    this.data.alerts.forEach(a => { a.status = 'read'; });
    this.saveData();
  }

  public clearAlert(alertId: string): boolean {
    const idx = this.data.alerts.findIndex(a => a.id === alertId);
    if (idx !== -1) {
      this.data.alerts.splice(idx, 1);
      this.saveData();
      return true;
    }
    return false;
  }

  public clearAllAlerts(): void {
    this.data.alerts = [];
    this.saveData();
  }

  public getSystemSettings() {
    return this.data.systemSettings;
  }

  public updateSystemSettings(partial: Partial<DatabaseSchema['systemSettings']>): void {
    this.data.systemSettings = { ...this.data.systemSettings, ...partial };
    this.saveData();
  }

  public registerDevice(device: DeviceInfo): void {
    const existingIdx = this.data.devices.findIndex(d => d.id === device.id);
    if (existingIdx !== -1) {
      this.data.devices[existingIdx] = { ...this.data.devices[existingIdx], ...device, lastSeen: new Date().toISOString() };
    } else {
      this.data.devices.push(device);
    }
    this.saveData();
  }
}

export const dbService = new DatabaseService();
