import { dbService } from './dbService.js';
import { soilHealthService } from './soilHealthService.js';
import { irrigationEngine } from './irrigationEngine.js';
import { irrigationService } from './irrigationService.js';
import { SensorReading, DemoScenario, DemoScenarioConfig } from '../../src/types/index.js';

export const SCENARIO_CONFIGS: Record<DemoScenario, DemoScenarioConfig> = {
  HEALTHY: {
    name: 'HEALTHY',
    label: 'Healthy Soil',
    description: 'Optimal vegetative conditions: balanced moisture, moderate temperature, and steady humidity.',
    moistureRange: [58, 68],
    temperatureRange: [22, 26],
    humidityRange: [55, 70],
    lightRange: [450, 750],
    rain: false,
    npkConnected: false
  },
  DRY_SOIL: {
    name: 'DRY_SOIL',
    label: 'Dry Soil (Depleted)',
    description: 'Moisture depleted below 30% threshold with clear skies. Roots require irrigation.',
    moistureRange: [18, 28],
    temperatureRange: [29, 34],
    humidityRange: [30, 45],
    lightRange: [800, 1100],
    rain: false,
    npkConnected: false
  },
  WATERLOGGED: {
    name: 'WATERLOGGED',
    label: 'Waterlogged Soil',
    description: 'Saturation > 80% following intense saturation. High hypoxia danger, zero irrigation.',
    moistureRange: [83, 94],
    temperatureRange: [19, 23],
    humidityRange: [80, 95],
    lightRange: [150, 350],
    rain: true,
    npkConnected: false
  },
  HOT_DRY: {
    name: 'HOT_DRY',
    label: 'Hot & Arid Stress',
    description: 'Heat wave conditions (36-41°C) with desiccated soil (< 30%). Critical water stress.',
    moistureRange: [16, 26],
    temperatureRange: [36, 41],
    humidityRange: [22, 38],
    lightRange: [950, 1300],
    rain: false,
    npkConnected: false
  },
  RECENT_RAIN: {
    name: 'RECENT_RAIN',
    label: 'Recent Precipitation',
    description: 'Digital rain sensor triggered; surface moisture elevating. Irrigation should hold.',
    moistureRange: [65, 76],
    temperatureRange: [18, 22],
    humidityRange: [82, 94],
    lightRange: [200, 420],
    rain: true,
    npkConnected: false
  },
  SENSOR_FAILURE: {
    name: 'SENSOR_FAILURE',
    label: 'Sensor Disconnect / Error',
    description: 'Analog signal disconnected or probe open-circuit error. Alerts triggered immediately.',
    moistureRange: [0, 5],
    temperatureRange: [-5, 0],
    humidityRange: [0, 10],
    lightRange: [0, 10],
    rain: false,
    npkConnected: false
  }
};

export class SensorService {
  private activeScenario: DemoScenario = 'HEALTHY';
  private isDemoMode: boolean = true;
  private tickInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.startPeriodicTick();
  }

  public getActiveScenario(): DemoScenario {
    return this.activeScenario;
  }

  public isDemo(): boolean {
    return this.isDemoMode;
  }

  public setMode(isDemo: boolean): void {
    this.isDemoMode = isDemo;
    dbService.updateSystemSettings({ demoMode: isDemo });
  }

  public applyScenario(scenario: DemoScenario, gardenId = 'garden-highland-01', bedId = 'bed-tomatoes-01'): SensorReading {
    this.activeScenario = scenario;
    const config = SCENARIO_CONFIGS[scenario] || SCENARIO_CONFIGS.HEALTHY;

    // Pick random within ranges
    const moisture = this.randomInRange(config.moistureRange[0], config.moistureRange[1]);
    const soilTemperature = this.randomInRange(config.temperatureRange[0], config.temperatureRange[1]);
    const humidity = this.randomInRange(config.humidityRange[0], config.humidityRange[1]);
    const light = Math.round(this.randomInRange(config.lightRange[0], config.lightRange[1]));

    const reading: SensorReading = {
      id: `reading-${Date.now()}`,
      sensorId: 'ESP32-001',
      gardenId,
      bedId,
      timestamp: new Date().toISOString(),
      moisture: Math.round(moisture * 10) / 10,
      soilTemperature: Math.round(soilTemperature * 10) / 10,
      humidity: Math.round(humidity * 10) / 10,
      light,
      rain: config.rain,
      npkNitrogen: null,
      npkPhosphorus: null,
      npkPotassium: null,
      npkConnected: false, // Honesty: NPK hardware is optional/not connected
      source: 'SIMULATED'
    };

    dbService.addSensorReading(reading);
    dbService.updateSystemSettings({ activeScenario: scenario, lastTick: reading.timestamp });

    // Run soil health analysis
    const report = soilHealthService.analyzeReading(reading);
    dbService.addSoilHealthReport(report);

    // Auto alert generation based on scenario
    if (scenario === 'DRY_SOIL') {
      dbService.addAlert({
        id: `alert-${Date.now()}`,
        severity: 'warning',
        title: 'Soil Moisture Below Target',
        message: `Plot ${bedId} moisture dropped to ${reading.moisture.toFixed(1)}%. Irrigation recommendation generated.`,
        timestamp: new Date().toISOString(),
        status: 'active',
        gardenId,
        bedId
      });
    } else if (scenario === 'HOT_DRY') {
      dbService.addAlert({
        id: `alert-${Date.now()}`,
        severity: 'critical',
        title: 'Extreme Heat & Drought Warning',
        message: `High thermal stress (${reading.soilTemperature.toFixed(1)}°C) and desiccated soil (${reading.moisture.toFixed(1)}%). Urgent watering recommended.`,
        timestamp: new Date().toISOString(),
        status: 'active',
        gardenId,
        bedId
      });
    } else if (scenario === 'WATERLOGGED') {
      dbService.addAlert({
        id: `alert-${Date.now()}`,
        severity: 'warning',
        title: 'Root Hypoxia Risk (Waterlogged)',
        message: `Soil saturation reached ${reading.moisture.toFixed(1)}%. All automated irrigation suspended. Check bed drainage.`,
        timestamp: new Date().toISOString(),
        status: 'active',
        gardenId,
        bedId
      });
    } else if (scenario === 'RECENT_RAIN') {
      dbService.addAlert({
        id: `alert-${Date.now()}`,
        severity: 'info',
        title: 'Precipitation Inflow Detected',
        message: 'Optical rain sensor triggered. Skipping scheduled irrigation cycles.',
        timestamp: new Date().toISOString(),
        status: 'active',
        gardenId,
        bedId
      });
    } else if (scenario === 'SENSOR_FAILURE') {
      dbService.addAlert({
        id: `alert-${Date.now()}`,
        severity: 'critical',
        title: 'Sensor Disconnected / Error Code 0xFD',
        message: 'Capacitive analog probe disconnected or open circuit detected on ESP32 GPIO 34. Check physical wiring.',
        timestamp: new Date().toISOString(),
        status: 'active',
        gardenId,
        bedId
      });
    }

    return reading;
  }

  /**
   * Background tick simulates natural sensor jitter every few seconds
   */
  private startPeriodicTick(): void {
    if (this.tickInterval) clearInterval(this.tickInterval);

    this.tickInterval = setInterval(() => {
      if (!this.isDemoMode) return;

      const latest = dbService.getLatestReading();
      if (!latest) return;

      const irrigState = irrigationService.getStatus();

      // If irrigation is active, moisture climbs!
      let newMoisture = latest.moisture;
      if (irrigState.isActive) {
        newMoisture = Math.min(80, newMoisture + 0.8 + Math.random() * 0.4);
      } else {
        // Natural micro jitter (-0.2 to +0.2)
        const jitter = (Math.random() - 0.5) * 0.3;
        const config = SCENARIO_CONFIGS[this.activeScenario] || SCENARIO_CONFIGS.HEALTHY;
        newMoisture = Math.min(config.moistureRange[1] + 2, Math.max(config.moistureRange[0] - 2, newMoisture + jitter));
      }

      const tempJitter = (Math.random() - 0.5) * 0.2;
      const humJitter = (Math.random() - 0.5) * 0.4;
      const lightJitter = Math.floor((Math.random() - 0.5) * 15);

      const updated: SensorReading = {
        id: `reading-tick-${Date.now()}`,
        sensorId: 'ESP32-001',
        gardenId: latest.gardenId,
        bedId: latest.bedId,
        timestamp: new Date().toISOString(),
        moisture: Math.round(newMoisture * 10) / 10,
        soilTemperature: Math.round((latest.soilTemperature + tempJitter) * 10) / 10,
        humidity: Math.round((latest.humidity + humJitter) * 10) / 10,
        light: Math.max(0, latest.light + lightJitter),
        rain: latest.rain,
        npkNitrogen: null,
        npkPhosphorus: null,
        npkPotassium: null,
        npkConnected: false,
        source: 'SIMULATED'
      };

      dbService.addSensorReading(updated);
    }, 5000);
  }

  private randomInRange(min: number, max: number): number {
    return min + Math.random() * (max - min);
  }
}

export const sensorService = new SensorService();
