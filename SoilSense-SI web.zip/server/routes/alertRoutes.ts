import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';

export const alertRouter = Router();

// GET /api/alerts
alertRouter.get('/', (_req: Request, res: Response) => {
  try {
    const alerts = dbService.getAlerts();
    res.json({
      success: true,
      count: alerts.length,
      data: alerts
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching alerts' });
  }
});

// POST /api/alerts/:id/read
alertRouter.post('/:id/read', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const ok = dbService.markAlertAsRead(id);
    if (!ok) {
      res.status(404).json({ success: false, error: 'Alert not found' });
      return;
    }
    res.json({ success: true, message: 'Alert marked as read' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error updating alert' });
  }
});

// DELETE /api/alerts/:id
alertRouter.delete('/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const ok = dbService.clearAlert(id);
    if (!ok) {
      res.status(404).json({ success: false, error: 'Alert not found' });
      return;
    }
    res.json({ success: true, message: 'Alert removed' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error deleting alert' });
  }
});

// DELETE /api/alerts (clear all)
alertRouter.delete('/', (_req: Request, res: Response) => {
  try {
    dbService.clearAllAlerts();
    res.json({ success: true, message: 'All alerts cleared' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error clearing alerts' });
  }
});
