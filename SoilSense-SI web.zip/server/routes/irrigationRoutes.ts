import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';
import { irrigationService } from '../services/irrigationService.js';

export const irrigationRouter = Router();

// GET /api/irrigation/status
irrigationRouter.get('/status', (req: Request, res: Response) => {
  try {
    const status = irrigationService.getStatus();
    const bedId = (req.query.bedId as string) || 'bed-tomatoes-01';
    const latest = dbService.getLatestReading(bedId);

    res.json({
      success: true,
      data: {
        ...status,
        currentMoisture: latest ? latest.moisture : 32.5,
        thresholdMoisture: 35
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching irrigation status' });
  }
});

// POST /api/irrigation/start
irrigationRouter.post('/start', (req: Request, res: Response) => {
  try {
    const { durationMinutes, reason, mode, gardenId, bedId } = req.body;
    const result = irrigationService.startIrrigation({
      durationMinutes: durationMinutes ? Number(durationMinutes) : 3,
      reason: reason || 'Triggered via dashboard manual command',
      mode: mode || 'MANUAL',
      gardenId,
      bedId
    });

    if (!result.success) {
      res.status(409).json(result);
      return;
    }

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error starting irrigation' });
  }
});

// POST /api/irrigation/stop
irrigationRouter.post('/stop', (req: Request, res: Response) => {
  try {
    const { gardenId, bedId } = req.body;
    const result = irrigationService.stopIrrigation(gardenId, bedId, false);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error stopping irrigation' });
  }
});

// GET /api/irrigation/history
irrigationRouter.get('/history', (req: Request, res: Response) => {
  try {
    const limit = parseInt((req.query.limit as string) || '30', 10);
    const events = dbService.getIrrigationEvents(limit);
    res.json({ success: true, count: events.length, data: events });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching irrigation history' });
  }
});
