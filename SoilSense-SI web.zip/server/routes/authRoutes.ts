import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';

export const authRouter = Router();

// POST /api/auth/login
authRouter.post('/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ success: false, error: 'Email and password are required' });
      return;
    }

    const user = dbService.findUserByEmail(email);
    if (!user) {
      res.status(401).json({ success: false, error: 'Invalid email or password' });
      return;
    }

    // Check password (accept default password123 or whatever user set)
    if (user.password && user.password !== password) {
      res.status(401).json({ success: false, error: 'Invalid email or password' });
      return;
    }

    // Return safe user profile (without password)
    const { password: _, resetToken: __, resetExpires: ___, ...safeUser } = user;
    const token = `token-${user.id}-${Date.now()}`;

    res.json({
      success: true,
      message: 'Logged in successfully',
      data: {
        user: safeUser,
        token
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Login failed' });
  }
});

// POST /api/auth/register
authRouter.post('/register', (req: Request, res: Response) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ success: false, error: 'All fields are required' });
      return;
    }

    if (password !== confirmPassword) {
      res.status(400).json({ success: false, error: 'Passwords do not match' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ success: false, error: 'Password must be at least 6 characters' });
      return;
    }

    const existing = dbService.findUserByEmail(email);
    if (existing) {
      res.status(409).json({ success: false, error: 'An account with this email already exists' });
      return;
    }

    // Role is strictly GARDEN_MANAGER for public sign-ups (Admin cannot be self-assigned)
    const newUser = dbService.createUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password,
      role: 'GARDEN_MANAGER'
    });

    const { password: _, resetToken: __, resetExpires: ___, ...safeUser } = newUser;
    const token = `token-${newUser.id}-${Date.now()}`;

    // Add welcome alert
    dbService.addAlert({
      id: `alert-welcome-${Date.now()}`,
      severity: 'info',
      title: 'Welcome to SoilSense AI',
      message: `${safeUser.name} registered as Garden Manager for JECRC Community Garden plots.`,
      timestamp: new Date().toISOString(),
      status: 'active'
    });

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      data: {
        user: safeUser,
        token
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Registration failed' });
  }
});

// POST /api/auth/forgot-password
authRouter.post('/forgot-password', (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ success: false, error: 'Email is required' });
      return;
    }

    const user = dbService.findUserByEmail(email);
    if (!user) {
      // Don't leak user existence in production, but confirm email instruction sent
      res.json({
        success: true,
        message: 'If an account exists with this email, password reset instructions have been dispatched.'
      });
      return;
    }

    const resetToken = `reset-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
    dbService.setResetToken(email, resetToken);

    res.json({
      success: true,
      message: 'Password reset instructions have been generated.',
      data: {
        resetToken // returned for easy developer/evaluator testing
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Password reset request failed' });
  }
});

// POST /api/auth/reset-password
authRouter.post('/reset-password', (req: Request, res: Response) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) {
      res.status(400).json({ success: false, error: 'Reset token and new password are required' });
      return;
    }

    if (newPassword.length < 6) {
      res.status(400).json({ success: false, error: 'Password must be at least 6 characters' });
      return;
    }

    const success = dbService.resetPassword(token, newPassword);
    if (!success) {
      res.status(400).json({ success: false, error: 'Invalid or expired password reset token' });
      return;
    }

    res.json({
      success: true,
      message: 'Your password has been successfully reset. You can now log in.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Password reset failed' });
  }
});

// GET /api/auth/me
authRouter.get('/me', (req: Request, res: Response) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // If no header, return the primary seeded admin for preview if available or 401
      const users = dbService.getUsers();
      if (users.length > 0) {
        const { password: _, resetToken: __, resetExpires: ___, ...safeUser } = users[0];
        res.json({ success: true, data: safeUser });
        return;
      }
      res.status(401).json({ success: false, error: 'Unauthorized' });
      return;
    }

    const token = authHeader.replace('Bearer ', '');
    const userId = token.split('-')[1];
    const users = dbService.getUsers();
    const user = users.find(u => u.id === userId) || users[0];

    const { password: _, resetToken: __, resetExpires: ___, ...safeUser } = user;
    res.json({ success: true, data: safeUser });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching user' });
  }
});

// POST /api/auth/logout
authRouter.post('/logout', (_req: Request, res: Response) => {
  res.json({ success: true, message: 'Logged out successfully' });
});
