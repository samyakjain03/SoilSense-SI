import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';

export const gardenRouter = Router();

// GET /api/gardens
gardenRouter.get('/', (_req: Request, res: Response) => {
  try {
    const gardens = dbService.getGardens();
    const beds = dbService.getGardenBeds();
    res.json({
      success: true,
      data: {
        gardens,
        beds
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching gardens' });
  }
});

// GET /api/users
gardenRouter.get('/users', (_req: Request, res: Response) => {
  try {
    const users = dbService.getUsers();
    res.json({ success: true, data: users });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching users' });
  }
});
