import { Router, Request, Response } from 'express';
import { geminiService } from '../services/geminiService.js';
import { dbService } from '../services/dbService.js';
import { soilHealthService } from '../services/soilHealthService.js';

export const aiRouter = Router();

// POST /api/ai/soil-insight
aiRouter.post('/soil-insight', async (req: Request, res: Response) => {
  try {
    let reading = req.body.reading;
    const bedId = req.body.bedId || 'bed-tomatoes-01';

    if (!reading) {
      reading = dbService.getLatestReading(bedId);
    }

    if (!reading) {
      res.status(400).json({ success: false, error: 'No sensor reading available for insight generation' });
      return;
    }

    const report = soilHealthService.analyzeReading(reading);
    const insightData = await geminiService.getSoilInsight(reading, report);

    res.json({
      success: true,
      data: insightData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error generating AI soil insight' });
  }
});

// POST /api/ai/crop-scan
aiRouter.post('/crop-scan', async (req: Request, res: Response) => {
  try {
    const { image, cropName, sampleType } = req.body;
    if (!image) {
      res.status(400).json({ success: false, error: 'No image data provided for crop scan' });
      return;
    }

    const scanResult = await geminiService.analyzeCropImage(image, cropName || 'Tomato', sampleType);
    res.json({
      success: true,
      data: scanResult
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error running crop scan' });
  }
});
