import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';
import { soilHealthService } from '../services/soilHealthService.js';
import { irrigationEngine } from '../services/irrigationEngine.js';
import { irrigationService } from '../services/irrigationService.js';
import { DeviceInfo, SensorReading } from '../../src/types/index.js';

export const deviceRouter = Router();

// GET /api/devices
deviceRouter.get('/', (_req: Request, res: Response) => {
  try {
    const devices = dbService.getDevices();
    res.json({ success: true, count: devices.length, data: devices });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error listing devices' });
  }
});

// POST /api/devices/register
deviceRouter.post('/register', (req: Request, res: Response) => {
  try {
    const { deviceId, name, type, gardenId, bedId, firmwareVersion } = req.body;

    if (!deviceId) {
      res.status(400).json({ success: false, error: 'deviceId is required' });
      return;
    }

    const device: DeviceInfo = {
      id: deviceId,
      name: name || `ESP32 Node (${deviceId})`,
      type: type || 'NODE1_ENVIRONMENT',
      gardenId: gardenId || 'garden-highland-01',
      bedId: bedId || 'bed-tomatoes-01',
      status: 'ONLINE',
      lastSeen: new Date().toISOString(),
      firmwareVersion: firmwareVersion || 'v1.0.0-esp-idf',
      batteryLevel: 100
    };

    dbService.registerDevice(device);

    res.json({
      success: true,
      message: `Device ${deviceId} registered successfully`,
      data: device
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error registering device' });
  }
});

// POST /api/devices/:deviceId/readings
deviceRouter.post('/:deviceId/readings', (req: Request, res: Response) => {
  try {
    const { deviceId } = req.params;
    const {
      moisture,
      temperature,
      soilTemperature,
      humidity,
      light,
      rain,
      timestamp,
      npkNitrogen,
      npkPhosphorus,
      npkPotassium,
      npkConnected
    } = req.body;

    // Validation
    if (typeof moisture !== 'number') {
      res.status(400).json({ success: false, error: 'Valid numeric "moisture" percentage is required' });
      return;
    }

    const tempVal = typeof soilTemperature === 'number' ? soilTemperature : (typeof temperature === 'number' ? temperature : 24);

    const reading: SensorReading = {
      id: `reading-esp32-${Date.now()}`,
      sensorId: deviceId,
      gardenId: req.body.gardenId || 'garden-highland-01',
      bedId: req.body.bedId || 'bed-tomatoes-01',
      timestamp: timestamp || new Date().toISOString(),
      moisture: Math.max(0, Math.min(100, moisture)),
      soilTemperature: tempVal,
      humidity: typeof humidity === 'number' ? humidity : 55,
      light: typeof light === 'number' ? light : 500,
      rain: Boolean(rain),
      npkNitrogen: typeof npkNitrogen === 'number' ? npkNitrogen : null,
      npkPhosphorus: typeof npkPhosphorus === 'number' ? npkPhosphorus : null,
      npkPotassium: typeof npkPotassium === 'number' ? npkPotassium : null,
      npkConnected: Boolean(npkConnected),
      source: 'ESP32_HARDWARE'
    };

    dbService.addSensorReading(reading);

    // Update device lastSeen
    dbService.registerDevice({
      id: deviceId,
      name: `ESP32 (${deviceId})`,
      type: 'NODE1_ENVIRONMENT',
      gardenId: reading.gardenId,
      bedId: reading.bedId,
      status: 'ONLINE',
      lastSeen: reading.timestamp,
      firmwareVersion: 'v2.4.1-edge'
    });

    // Run soil health engine and evaluate irrigation
    const report = soilHealthService.analyzeReading(reading);
    dbService.addSoilHealthReport(report);
    const recentIrrigations = dbService.getIrrigationEvents(5);
    const rec = irrigationEngine.evaluate(reading, report.status, recentIrrigations);

    res.json({
      success: true,
      message: 'Hardware telemetry recorded',
      data: {
        reading,
        soilStatus: report.status,
        score: report.score,
        irrigationAction: rec.action,
        recommendedDuration: rec.duration
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error processing hardware telemetry' });
  }
});

// GET /api/devices/:deviceId/status
deviceRouter.get('/:deviceId/status', (req: Request, res: Response) => {
  try {
    const { deviceId } = req.params;
    const devices = dbService.getDevices();
    const device = devices.find(d => d.id === deviceId);

    if (!device) {
      res.status(404).json({ success: false, error: `Device ${deviceId} not found` });
      return;
    }

    const latest = dbService.getLatestReading(device.bedId);
    const irrigStatus = irrigationService.getStatus();

    res.json({
      success: true,
      data: {
        device,
        latestReading: latest,
        actuatorState: {
          pump: irrigStatus.pumpStatus,
          valve: irrigStatus.valveStatus,
          isActive: irrigStatus.isActive
        }
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error getting device status' });
  }
});

// POST /api/devices/:deviceId/irrigation
deviceRouter.post('/:deviceId/irrigation', (req: Request, res: Response) => {
  try {
    const { deviceId } = req.params;
    const { action, durationMinutes, reason } = req.body;

    if (action === 'STOP') {
      const resStop = irrigationService.stopIrrigation('garden-highland-01', 'bed-tomatoes-01', false);
      res.json({ ...resStop, message: 'Relay pump STOP command dispatched to ESP32 node' });
      return;
    }

    const resStart = irrigationService.startIrrigation({
      durationMinutes: durationMinutes || 3,
      reason: reason || `Actuated via edge device ${deviceId}`,
      mode: 'AUTOMATED'
    });

    res.json({
      success: resStart.success,
      message: resStart.message,
      data: resStart.state
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error controlling device irrigation' });
  }
});
