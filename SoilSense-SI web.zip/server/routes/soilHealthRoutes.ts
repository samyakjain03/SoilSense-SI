import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';
import { soilHealthService } from '../services/soilHealthService.js';
import { SensorReading } from '../../src/types/index.js';

export const soilHealthRouter = Router();

// GET /api/soil-health/current
soilHealthRouter.get('/current', (req: Request, res: Response) => {
  try {
    const bedId = (req.query.bedId as string) || 'bed-tomatoes-01';
    const latestReading = dbService.getLatestReading(bedId);

    if (!latestReading) {
      res.status(404).json({ success: false, error: 'No sensor telemetry available' });
      return;
    }

    const report = soilHealthService.analyzeReading(latestReading);
    res.json({ success: true, data: report });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error generating soil health report' });
  }
});

// GET /api/soil-health/history
soilHealthRouter.get('/history', (req: Request, res: Response) => {
  try {
    const limit = parseInt((req.query.limit as string) || '20', 10);
    const reports = dbService.getSoilHealthReports(limit);
    res.json({ success: true, count: reports.length, data: reports });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching report history' });
  }
});

// POST /api/soil-health/analyze
soilHealthRouter.post('/analyze', (req: Request, res: Response) => {
  try {
    const reading: SensorReading = req.body;
    if (typeof reading.moisture !== 'number' || typeof reading.soilTemperature !== 'number') {
      res.status(400).json({ success: false, error: 'Missing moisture or soilTemperature in request body' });
      return;
    }

    const report = soilHealthService.analyzeReading(reading);
    res.json({ success: true, data: report });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error analyzing reading' });
  }
});
