import { Router, Request, Response } from 'express';
import { dbService } from '../services/dbService.js';
import { sensorService, SCENARIO_CONFIGS } from '../services/sensorService.js';
import { soilHealthService } from '../services/soilHealthService.js';
import { irrigationEngine } from '../services/irrigationEngine.js';
import { DemoScenario } from '../../src/types/index.js';

export const sensorRouter = Router();

// GET /api/sensors/latest
sensorRouter.get('/latest', (req: Request, res: Response) => {
  try {
    const bedId = (req.query.bedId as string) || 'bed-tomatoes-01';
    let latest = dbService.getLatestReading(bedId);

    if (!latest) {
      // Seed an initial reading if empty
      latest = sensorService.applyScenario('HEALTHY', 'garden-highland-01', bedId);
    }

    const report = soilHealthService.analyzeReading(latest);
    const recentIrrigations = dbService.getIrrigationEvents(5);
    const irrigationRec = irrigationEngine.evaluate(latest, report.status, recentIrrigations);

    res.json({
      success: true,
      data: {
        reading: latest,
        soilHealth: report,
        irrigationRecommendation: irrigationRec,
        isDemo: sensorService.isDemo(),
        activeScenario: sensorService.getActiveScenario(),
        availableScenarios: Object.keys(SCENARIO_CONFIGS)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching latest reading' });
  }
});

// GET /api/sensors/history
sensorRouter.get('/history', (req: Request, res: Response) => {
  try {
    const bedId = req.query.bedId as string;
    const limit = parseInt((req.query.limit as string) || '50', 10);
    const history = dbService.getReadingHistory(bedId, limit);
    res.json({ success: true, count: history.length, data: history });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error fetching history' });
  }
});

// POST /api/sensors/demo
sensorRouter.post('/demo', (req: Request, res: Response) => {
  try {
    const { scenario, isDemo, bedId, gardenId } = req.body;

    if (typeof isDemo === 'boolean') {
      sensorService.setMode(isDemo);
    }

    if (scenario) {
      const validScenarios: DemoScenario[] = ['HEALTHY', 'DRY_SOIL', 'WATERLOGGED', 'HOT_DRY', 'RECENT_RAIN', 'SENSOR_FAILURE'];
      if (!validScenarios.includes(scenario)) {
        res.status(400).json({
          success: false,
          error: `Invalid scenario. Allowed: ${validScenarios.join(', ')}`
        });
        return;
      }

      const reading = sensorService.applyScenario(
        scenario as DemoScenario,
        gardenId || 'garden-jecrc-01',
        bedId || 'bed-tomatoes-01'
      );

      const report = soilHealthService.analyzeReading(reading);
      const recentIrrigations = dbService.getIrrigationEvents(5);
      const irrigationRec = irrigationEngine.evaluate(reading, report.status, recentIrrigations);

      res.json({
        success: true,
        message: `Scenario ${scenario} applied successfully`,
        data: {
          reading,
          soilHealth: report,
          irrigationRecommendation: irrigationRec,
          scenarioInfo: SCENARIO_CONFIGS[scenario as DemoScenario]
        }
      });
      return;
    }

    res.json({
      success: true,
      message: 'Demo configuration updated',
      data: {
        isDemo: sensorService.isDemo(),
        activeScenario: sensorService.getActiveScenario()
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error updating demo mode' });
  }
});
