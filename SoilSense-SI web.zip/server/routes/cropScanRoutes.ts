import { Router, Request, Response } from 'express';
import { geminiService } from '../services/geminiService.js';
import { CropScanResult } from '../../src/types/index.js';

export const cropScanRouter = Router();

// POST /api/ai/crop-scan
cropScanRouter.post('/crop-scan', async (req: Request, res: Response) => {
  try {
    const { image, cropName } = req.body;

    if (!image) {
      res.status(400).json({ success: false, error: 'Image data is required' });
      return;
    }

    const diagnosis = await geminiService.analyzeCropImage(image, cropName || 'Tomato');

    const result: CropScanResult = {
      id: `scan-${Date.now()}`,
      timestamp: new Date().toISOString(),
      cropName: cropName || 'Tomato',
      canopyCondition: diagnosis.canopyCondition,
      suspectedDeficiency: diagnosis.suspectedDeficiency,
      confidence: diagnosis.confidence,
      visualObservations: diagnosis.visualObservations,
      soilCorrelation: diagnosis.soilCorrelation,
      recommendations: diagnosis.recommendations,
      imageUrl: image.startsWith('data:') ? image.substring(0, 100) + '...' : undefined // avoid bloated json in response
    };

    res.json({
      success: true,
      message: 'Crop canopy analyzed successfully',
      data: result
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Error processing crop scan' });
  }
});
